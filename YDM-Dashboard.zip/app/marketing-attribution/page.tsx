"use client"

import { useState } from "react"
import Link from "next/link"
import { BarChart3, ChevronRight, Clock, FileText, Flag, LineChart, MousePointerClick, Share2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"
import { AttributionModelInsights } from "@/components/attribution-model-insights"

export default function MarketingAttributionPage() {
  const [selectedModel, setSelectedModel] = useState("single-touch")
  const [touchpointCount, setTouchpointCount] = useState(5)
  const [decayRate, setDecayRate] = useState(0.5)
  const [positionWeight, setPositionWeight] = useState(0.4)

  // Generate touchpoints based on count
  const generateTouchpoints = (count: number) => {
    return Array.from({ length: count }, (_, i) => ({
      id: i + 1,
      name: `Touchpoint ${i + 1}`,
      channel: getChannelForIndex(i),
      date: getDateForIndex(i, count),
      value: 0,
    }))
  }

  const getChannelForIndex = (index: number) => {
    const channels = ["Google Ads", "Facebook", "Email", "Organic Search", "Direct", "Referral", "Instagram"]
    return channels[index % channels.length]
  }

  const getDateForIndex = (index: number, total: number) => {
    const today = new Date()
    const daysBefore = Math.floor(((total - index - 1) / (total - 1)) * 30)
    const date = new Date(today)
    date.setDate(today.getDate() - daysBefore)
    return date.toLocaleDateString()
  }

  const touchpoints = generateTouchpoints(touchpointCount)

  // Calculate attribution values based on selected model
  const calculateAttributionValues = () => {
    let values = [...touchpoints].map((tp) => ({ ...tp }))

    switch (selectedModel) {
      case "single-touch-first":
        values = values.map((tp, i) => ({
          ...tp,
          value: i === 0 ? 100 : 0,
        }))
        break
      case "single-touch-last":
        values = values.map((tp, i) => ({
          ...tp,
          value: i === values.length - 1 ? 100 : 0,
        }))
        break
      case "linear":
        const equalValue = 100 / values.length
        values = values.map((tp) => ({
          ...tp,
          value: equalValue,
        }))
        break
      case "time-decay":
        const total = values.reduce((sum, _, i) => sum + Math.pow(1 - decayRate, i), 0)
        values = values.map((tp, i) => ({
          ...tp,
          value: (Math.pow(1 - decayRate, values.length - i - 1) / total) * 100,
        }))
        break
      case "position-based":
        const middleWeight = (1 - positionWeight * 2) / (values.length - 2)
        values = values.map((tp, i) => {
          if (i === 0 || i === values.length - 1) {
            return { ...tp, value: positionWeight * 100 }
          } else {
            return { ...tp, value: middleWeight * 100 }
          }
        })
        break
    }

    return values
  }

  const attributedValues = calculateAttributionValues()

  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-10 bg-background border-b">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <Link href="/marketing" className="text-muted-foreground hover:text-foreground transition-colors">
              Marketing
            </Link>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
            <span>Marketing Attribution</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm">
              <FileText className="mr-2 h-4 w-4" />
              Export Report
            </Button>
            <Button size="sm">
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container py-6">
        <div className="grid gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight text-black">Marketing Attribution</h1>
            <p className="text-muted-foreground">
              Compare different attribution models to understand how marketing touchpoints contribute to conversions.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Single-Touch</CardTitle>
                <CardDescription>First or last touchpoint</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Flag className="h-4 w-4 text-primary" />
                    <MousePointerClick className="h-4 w-4 text-primary" />
                  </div>
                  <Button
                    variant={selectedModel.startsWith("single-touch") ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedModel("single-touch-last")}
                  >
                    Select
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Linear</CardTitle>
                <CardDescription>Equal credit to all touchpoints</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="h-4 w-1 bg-primary rounded-full" />
                    ))}
                  </div>
                  <Button
                    variant={selectedModel === "linear" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedModel("linear")}
                  >
                    Select
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Time-Decay</CardTitle>
                <CardDescription>More credit to recent touchpoints</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <LineChart className="h-4 w-4 text-primary" />
                  </div>
                  <Button
                    variant={selectedModel === "time-decay" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedModel("time-decay")}
                  >
                    Select
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Position-Based</CardTitle>
                <CardDescription>More credit to first & last</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <div className="h-4 w-2 bg-primary rounded-full" />
                    <div className="h-2 w-1 bg-primary/50 rounded-full" />
                    <div className="h-2 w-1 bg-primary/50 rounded-full" />
                    <div className="h-4 w-2 bg-primary rounded-full" />
                  </div>
                  <Button
                    variant={selectedModel === "position-based" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedModel("position-based")}
                  >
                    Select
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 md:grid-cols-12">
            <Card className="md:col-span-8">
              <CardHeader>
                <CardTitle>Attribution Model Comparison</CardTitle>
                <CardDescription>Visualize how different models attribute conversion credit</CardDescription>
                <Tabs defaultValue={selectedModel} onValueChange={setSelectedModel} className="w-full">
                  <TabsList className="grid grid-cols-5 w-full">
                    <TabsTrigger value="single-touch-first">First Touch</TabsTrigger>
                    <TabsTrigger value="single-touch-last">Last Touch</TabsTrigger>
                    <TabsTrigger value="linear">Linear</TabsTrigger>
                    <TabsTrigger value="time-decay">Time-Decay</TabsTrigger>
                    <TabsTrigger value="position-based">Position-Based</TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Customer Journey Timeline</div>
                    <div className="relative h-8">
                      {attributedValues.map((tp, i) => (
                        <div
                          key={tp.id}
                          className="absolute top-0 transform -translate-x-1/2 flex flex-col items-center"
                          style={{ left: `${(i / (attributedValues.length - 1)) * 100}%` }}
                        >
                          <div className={`h-3 w-3 rounded-full ${tp.value > 0 ? "bg-primary" : "bg-muted"}`} />
                          <div className="h-4 w-px bg-muted-foreground/30" />
                        </div>
                      ))}
                      <div className="absolute top-4 left-0 right-0 h-px bg-muted-foreground/30" />
                    </div>
                  </div>

                  <div className="space-y-4">
                    {attributedValues.map((tp) => (
                      <div key={tp.id} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{tp.name}</span>
                            <span className="text-xs text-muted-foreground">({tp.channel})</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">{tp.date}</span>
                            <span className="font-medium">{tp.value.toFixed(1)}%</span>
                          </div>
                        </div>
                        <Progress value={tp.value} className="h-2" />
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="md:col-span-4 space-y-6">
              <Card className="md:col-span-4">
                <CardHeader>
                  <CardTitle>Model Settings</CardTitle>
                  <CardDescription>Customize parameters for the selected attribution model</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">Number of Touchpoints</label>
                      <span className="text-sm text-muted-foreground">{touchpointCount}</span>
                    </div>
                    <Slider
                      value={[touchpointCount]}
                      min={2}
                      max={10}
                      step={1}
                      onValueChange={(value) => setTouchpointCount(value[0])}
                    />
                  </div>

                  {selectedModel === "time-decay" && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Decay Rate</label>
                        <span className="text-sm text-muted-foreground">{decayRate.toFixed(2)}</span>
                      </div>
                      <Slider
                        value={[decayRate]}
                        min={0.1}
                        max={0.9}
                        step={0.05}
                        onValueChange={(value) => setDecayRate(value[0])}
                      />
                      <p className="text-xs text-muted-foreground">
                        Higher values give more weight to recent touchpoints
                      </p>
                    </div>
                  )}

                  {selectedModel === "position-based" && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">First/Last Weight</label>
                        <span className="text-sm text-muted-foreground">{(positionWeight * 100).toFixed(0)}%</span>
                      </div>
                      <Slider
                        value={[positionWeight]}
                        min={0.1}
                        max={0.45}
                        step={0.05}
                        onValueChange={(value) => setPositionWeight(value[0])}
                      />
                      <p className="text-xs text-muted-foreground">
                        Percentage of credit given to first and last touchpoints
                      </p>
                    </div>
                  )}

                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Model Description</h3>
                    <div className="text-sm text-muted-foreground">
                      {selectedModel.startsWith("single-touch-first") && (
                        <p>
                          First-touch attribution gives 100% of the credit to the first touchpoint in the customer
                          journey.
                        </p>
                      )}
                      {selectedModel.startsWith("single-touch-last") && (
                        <p>
                          Last-touch attribution gives 100% of the credit to the final touchpoint before conversion.
                        </p>
                      )}
                      {selectedModel === "linear" && (
                        <p>
                          Linear attribution distributes credit equally across all touchpoints in the customer journey.
                        </p>
                      )}
                      {selectedModel === "time-decay" && (
                        <p>
                          Time-decay attribution gives more credit to touchpoints closer to conversion, with credit
                          decreasing exponentially as you move backward in time.
                        </p>
                      )}
                      {selectedModel === "position-based" && (
                        <p>
                          Position-based attribution gives more credit to the first and last touchpoints, with the
                          remaining credit distributed among middle touchpoints.
                        </p>
                      )}
                    </div>
                  </div>

                  <Button className="w-full">
                    <BarChart3 className="mr-2 h-4 w-4" />
                    Apply to Campaign Data
                  </Button>
                </CardContent>
              </Card>

              <AttributionModelInsights />
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Attribution Model Comparison</CardTitle>
              <CardDescription>See how different attribution models affect channel performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-6 gap-4 text-sm font-medium border-b pb-2">
                  <div>Channel</div>
                  <div className="text-right">First Touch</div>
                  <div className="text-right">Last Touch</div>
                  <div className="text-right">Linear</div>
                  <div className="text-right">Time-Decay</div>
                  <div className="text-right">Position-Based</div>
                </div>

                {["Google Ads", "Facebook", "Email", "Organic Search", "Direct"].map((channel) => {
                  // Calculate random but consistent values for each channel across models
                  const seed = channel.charCodeAt(0) + channel.length
                  const getRandomValue = (offset: number) => {
                    return ((seed * 17 + offset * 13) % 30) + 5
                  }

                  return (
                    <div key={channel} className="grid grid-cols-6 gap-4 text-sm py-2 border-b border-muted">
                      <div className="font-medium">{channel}</div>
                      <div className="text-right">{getRandomValue(1).toFixed(1)}%</div>
                      <div className="text-right">{getRandomValue(2).toFixed(1)}%</div>
                      <div className="text-right">{getRandomValue(3).toFixed(1)}%</div>
                      <div className="text-right">{getRandomValue(4).toFixed(1)}%</div>
                      <div className="text-right">{getRandomValue(5).toFixed(1)}%</div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

