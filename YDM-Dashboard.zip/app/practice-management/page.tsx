"use client"

import { useState } from "react"
import {
  DollarSign,
  Users,
  Calendar,
  FileText,
  TrendingUp,
  Shield,
  BarChart2,
  Plus,
  Download,
  Search,
  Filter,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"

// Sample data for charts
const financialData = [
  { month: "Jan", revenue: 42000, expenses: 28000, profit: 14000 },
  { month: "Feb", revenue: 45000, expenses: 29000, profit: 16000 },
  { month: "Mar", revenue: 48000, expenses: 30000, profit: 18000 },
  { month: "Apr", revenue: 51000, expenses: 31000, profit: 20000 },
  { month: "May", revenue: 53000, expenses: 32000, profit: 21000 },
  { month: "Jun", revenue: 56000, expenses: 33000, profit: 23000 },
]

const staffPerformanceData = [
  { name: "Dr. Smith", patients: 120, procedures: 180, satisfaction: 92 },
  { name: "Dr. Johnson", patients: 110, procedures: 165, satisfaction: 88 },
  { name: "Dr. Williams", patients: 95, procedures: 140, satisfaction: 90 },
  { name: "Hygienist A", patients: 85, procedures: 85, satisfaction: 94 },
  { name: "Hygienist B", patients: 80, procedures: 80, satisfaction: 91 },
]

const patientMetricsData = [
  { month: "Jan", newPatients: 45, returningPatients: 120 },
  { month: "Feb", newPatients: 52, returningPatients: 125 },
  { month: "Mar", newPatients: 48, returningPatients: 130 },
  { month: "Apr", newPatients: 61, returningPatients: 135 },
  { month: "May", newPatients: 55, returningPatients: 140 },
  { month: "Jun", newPatients: 67, returningPatients: 145 },
]

const insuranceClaimsData = [
  { status: "Submitted", value: 45 },
  { status: "In Progress", value: 30 },
  { status: "Approved", value: 65 },
  { status: "Denied", value: 15 },
  { status: "Resubmitted", value: 20 },
]

const marketingChannelsData = [
  { channel: "Website", leads: 120 },
  { channel: "Social Media", leads: 85 },
  { channel: "Referrals", leads: 65 },
  { channel: "Local Events", leads: 40 },
  { channel: "Email", leads: 55 },
]

export default function PracticeManagementPage() {
  const [activeTab, setActiveTab] = useState("financial")

  return (
    <div className="flex-1 space-y-6 p-6 md:p-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Practice Management</h1>
          <p className="text-muted-foreground">Comprehensive tools to manage and optimize your dental practice</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm">
            <Plus className="mr-2 h-4 w-4" />
            New Task
          </Button>
        </div>
      </div>

      <Tabs defaultValue="financial" className="space-y-4" onValueChange={setActiveTab}>
        <div className="flex justify-between">
          <TabsList>
            <TabsTrigger value="financial" className="text-xs sm:text-sm">
              <DollarSign className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Financial</span>
            </TabsTrigger>
            <TabsTrigger value="staff" className="text-xs sm:text-sm">
              <Users className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Staff</span>
            </TabsTrigger>
            <TabsTrigger value="patients" className="text-xs sm:text-sm">
              <Calendar className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Patients</span>
            </TabsTrigger>
            <TabsTrigger value="billing" className="text-xs sm:text-sm">
              <FileText className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Billing</span>
            </TabsTrigger>
            <TabsTrigger value="marketing" className="text-xs sm:text-sm">
              <TrendingUp className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Marketing</span>
            </TabsTrigger>
            <TabsTrigger value="compliance" className="text-xs sm:text-sm">
              <Shield className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Compliance</span>
            </TabsTrigger>
            <TabsTrigger value="improvement" className="text-xs sm:text-sm">
              <BarChart2 className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Improvement</span>
            </TabsTrigger>
          </TabsList>

          <div className="flex items-center gap-2">
            <div className="relative w-[180px] md:w-[240px]">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <input
                type="search"
                placeholder={`Search ${activeTab}...`}
                className="w-full rounded-md border border-input bg-background py-2 pl-8 pr-3 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Financial Management Tab */}
        <TabsContent value="financial" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$295,400</div>
                <p className="text-xs text-muted-foreground">+12.5% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Expenses</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$183,200</div>
                <p className="text-xs text-muted-foreground">+5.2% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$112,200</div>
                <p className="text-xs text-muted-foreground">+18.7% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Profit Margin</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">38%</div>
                <p className="text-xs text-muted-foreground">+2.3% from last month</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Financial Overview</CardTitle>
                <CardDescription>Revenue, expenses, and profit over the last 6 months</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={financialData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="revenue" stroke="#8884d8" name="Revenue" />
                      <Line type="monotone" dataKey="expenses" stroke="#82ca9d" name="Expenses" />
                      <Line type="monotone" dataKey="profit" stroke="#ff7300" name="Profit" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Budget Allocation</CardTitle>
                <CardDescription>Current budget allocation by category</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="font-medium">Staff Salaries</div>
                      <div>45%</div>
                    </div>
                    <Progress value={45} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="font-medium">Equipment & Supplies</div>
                      <div>25%</div>
                    </div>
                    <Progress value={25} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="font-medium">Rent & Utilities</div>
                      <div>15%</div>
                    </div>
                    <Progress value={15} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="font-medium">Marketing</div>
                      <div>8%</div>
                    </div>
                    <Progress value={8} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="font-medium">Software & IT</div>
                      <div>5%</div>
                    </div>
                    <Progress value={5} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="font-medium">Other</div>
                      <div>2%</div>
                    </div>
                    <Progress value={2} className="h-2" />
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  <Download className="mr-2 h-4 w-4" />
                  Download Budget Report
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        {/* Staff Management Tab */}
        <TabsContent value="staff" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Staff</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">24</div>
                <p className="text-xs text-muted-foreground">+2 from last quarter</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Dentists</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">5</div>
                <p className="text-xs text-muted-foreground">+1 from last quarter</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Hygienists</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8</div>
                <p className="text-xs text-muted-foreground">No change</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Support Staff</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">11</div>
                <p className="text-xs text-muted-foreground">+1 from last quarter</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Staff Performance</CardTitle>
                <CardDescription>Patient load and procedures by staff member</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={staffPerformanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="patients" fill="#8884d8" name="Patients" />
                      <Bar dataKey="procedures" fill="#82ca9d" name="Procedures" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Staff Satisfaction</CardTitle>
                <CardDescription>Patient satisfaction ratings by staff member (%)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {staffPerformanceData.map((staff) => (
                    <div key={staff.name} className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <div className="font-medium">{staff.name}</div>
                        <div>{staff.satisfaction}%</div>
                      </div>
                      <Progress value={staff.satisfaction} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  <Plus className="mr-2 h-4 w-4" />
                  Schedule Training Session
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        {/* Patient Management Tab */}
        <TabsContent value="patients" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3,842</div>
                <p className="text-xs text-muted-foreground">+328 from last year</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">New Patients (MTD)</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">67</div>
                <p className="text-xs text-muted-foreground">+12 from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Appointments (Today)</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">28</div>
                <p className="text-xs text-muted-foreground">2 cancellations</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Recall Rate</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">78%</div>
                <p className="text-xs text-muted-foreground">+3% from last quarter</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Patient Metrics</CardTitle>
                <CardDescription>New and returning patients over time</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={patientMetricsData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="newPatients" stroke="#8884d8" name="New Patients" />
                      <Line type="monotone" dataKey="returningPatients" stroke="#82ca9d" name="Returning Patients" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Patient Communication</CardTitle>
                <CardDescription>Upcoming patient reminders and notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="font-medium">Appointment Reminders</div>
                    <div className="text-sm text-muted-foreground mt-1">42 reminders scheduled for next week</div>
                    <div className="mt-3 flex items-center gap-2">
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-3 w-3" />
                        Export
                      </Button>
                      <Button size="sm">
                        <Plus className="mr-2 h-3 w-3" />
                        Send Now
                      </Button>
                    </div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="font-medium">Recall Notifications</div>
                    <div className="text-sm text-muted-foreground mt-1">128 patients due for recall</div>
                    <div className="mt-3 flex items-center gap-2">
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-3 w-3" />
                        Export
                      </Button>
                      <Button size="sm">
                        <Plus className="mr-2 h-3 w-3" />
                        Send Now
                      </Button>
                    </div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="font-medium">Treatment Plan Follow-ups</div>
                    <div className="text-sm text-muted-foreground mt-1">36 pending treatment plans</div>
                    <div className="mt-3 flex items-center gap-2">
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-3 w-3" />
                        Export
                      </Button>
                      <Button size="sm">
                        <Plus className="mr-2 h-3 w-3" />
                        Send Now
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Billing and Insurance Tab */}
        <TabsContent value="billing" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Outstanding Claims</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$87,450</div>
                <p className="text-xs text-muted-foreground">175 claims pending</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Claims Approved (MTD)</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$42,380</div>
                <p className="text-xs text-muted-foreground">65 claims</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Claims Denied (MTD)</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$8,750</div>
                <p className="text-xs text-muted-foreground">15 claims</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Claim Success Rate</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">92%</div>
                <p className="text-xs text-muted-foreground">+2% from last month</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Insurance Claims Status</CardTitle>
                <CardDescription>Current status of all insurance claims</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={insuranceClaimsData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="status" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="value" fill="#8884d8" name="Claims" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Recent Claims</CardTitle>
                <CardDescription>Recently submitted insurance claims</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Claim #38291</div>
                      <div className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">In Progress</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Patient: John Smith</div>
                    <div className="text-sm text-muted-foreground">Amount: $1,250.00</div>
                    <div className="text-sm text-muted-foreground">Submitted: 06/15/2023</div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Claim #38290</div>
                      <div className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Approved</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Patient: Sarah Johnson</div>
                    <div className="text-sm text-muted-foreground">Amount: $850.00</div>
                    <div className="text-sm text-muted-foreground">Submitted: 06/14/2023</div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Claim #38289</div>
                      <div className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full">Denied</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Patient: Michael Brown</div>
                    <div className="text-sm text-muted-foreground">Amount: $1,875.00</div>
                    <div className="text-sm text-muted-foreground">Submitted: 06/14/2023</div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  <Plus className="mr-2 h-4 w-4" />
                  Submit New Claim
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        {/* Marketing Tab */}
        <TabsContent value="marketing" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Marketing Budget</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$24,500</div>
                <p className="text-xs text-muted-foreground">Annual budget</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">New Leads (MTD)</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">85</div>
                <p className="text-xs text-muted-foreground">+15% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">32%</div>
                <p className="text-xs text-muted-foreground">+5% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Cost Per Acquisition</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$125</div>
                <p className="text-xs text-muted-foreground">-8% from last month</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Marketing Channels Performance</CardTitle>
                <CardDescription>Lead generation by marketing channel</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={marketingChannelsData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="channel" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="leads" fill="#8884d8" name="Leads Generated" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Marketing Campaigns</CardTitle>
                <CardDescription>Active and upcoming marketing campaigns</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Summer Smile Special</div>
                      <div className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Active</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Budget: $5,000</div>
                    <div className="text-sm text-muted-foreground">Leads: 42</div>
                    <div className="text-sm text-muted-foreground">Ends: 08/31/2023</div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Back to School Checkups</div>
                      <div className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Upcoming</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Budget: $3,500</div>
                    <div className="text-sm text-muted-foreground">Starts: 08/01/2023</div>
                    <div className="text-sm text-muted-foreground">Ends: 09/15/2023</div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Invisalign Promotion</div>
                      <div className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Active</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Budget: $7,500</div>
                    <div className="text-sm text-muted-foreground">Leads: 28</div>
                    <div className="text-sm text-muted-foreground">Ends: 07/31/2023</div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  <Plus className="mr-2 h-4 w-4" />
                  Create New Campaign
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        {/* Compliance Tab */}
        <TabsContent value="compliance" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Compliance Score</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">94%</div>
                <p className="text-xs text-muted-foreground">+2% from last audit</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">HIPAA Training</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">100%</div>
                <p className="text-xs text-muted-foreground">All staff certified</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">OSHA Compliance</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">92%</div>
                <p className="text-xs text-muted-foreground">2 items need attention</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Security Incidents</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">0</div>
                <p className="text-xs text-muted-foreground">Last 12 months</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Compliance Tasks</CardTitle>
                <CardDescription>Upcoming and overdue compliance tasks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">OSHA Safety Inspection</div>
                      <div className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">Due in 7 days</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Assigned to: Dr. Johnson</div>
                    <div className="text-sm text-muted-foreground">Due: 07/15/2023</div>
                    <div className="mt-3 flex items-center gap-2">
                      <Button size="sm">
                        <Plus className="mr-2 h-3 w-3" />
                        Mark Complete
                      </Button>
                    </div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">HIPAA Quarterly Audit</div>
                      <div className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Completed</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Completed by: Office Manager</div>
                    <div className="text-sm text-muted-foreground">Date: 06/01/2023</div>
                    <div className="mt-3 flex items-center gap-2">
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-3 w-3" />
                        View Report
                      </Button>
                    </div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Staff HIPAA Training</div>
                      <div className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Upcoming</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Assigned to: All Staff</div>
                    <div className="text-sm text-muted-foreground">Due: 08/15/2023</div>
                    <div className="mt-3 flex items-center gap-2">
                      <Button size="sm">
                        <Plus className="mr-2 h-3 w-3" />
                        Schedule Training
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Compliance Documents</CardTitle>
                <CardDescription>Important compliance documentation</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">HIPAA Privacy Policy</div>
                      <div className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Current</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Last Updated: 01/15/2023</div>
                    <div className="text-sm text-muted-foreground">Next Review: 01/15/2024</div>
                    <div className="mt-3 flex items-center gap-2">
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-3 w-3" />
                        Download
                      </Button>
                    </div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">OSHA Safety Manual</div>
                      <div className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Current</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Last Updated: 03/10/2023</div>
                    <div className="text-sm text-muted-foreground">Next Review: 03/10/2024</div>
                    <div className="mt-3 flex items-center gap-2">
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-3 w-3" />
                        Download
                      </Button>
                    </div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Emergency Procedures</div>
                      <div className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">Review Needed</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Last Updated: 06/05/2022</div>
                    <div className="text-sm text-muted-foreground">Next Review: 06/05/2023</div>
                    <div className="mt-3 flex items-center gap-2">
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-3 w-3" />
                        Download
                      </Button>
                      <Button size="sm">
                        <Plus className="mr-2 h-3 w-3" />
                        Update
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Practice Improvement Tab */}
        <TabsContent value="improvement" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Patient Satisfaction</CardTitle>
                <BarChart2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">92%</div>
                <p className="text-xs text-muted-foreground">+3% from last quarter</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Wait Time (Avg)</CardTitle>
                <BarChart2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8 min</div>
                <p className="text-xs text-muted-foreground">-2 min from last quarter</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Treatment Acceptance</CardTitle>
                <BarChart2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">78%</div>
                <p className="text-xs text-muted-foreground">+5% from last quarter</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Improvement Projects</CardTitle>
                <BarChart2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4</div>
                <p className="text-xs text-muted-foreground">2 completed, 2 in progress</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Improvement Projects</CardTitle>
                <CardDescription>Current practice improvement initiatives</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Digital Check-in System</div>
                      <div className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">In Progress</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Lead: Office Manager</div>
                    <div className="text-sm text-muted-foreground">Target Completion: 08/31/2023</div>
                    <div className="mt-2">
                      <div className="text-xs text-muted-foreground mb-1">Progress: 65%</div>
                      <Progress value={65} className="h-2" />
                    </div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Patient Communication Overhaul</div>
                      <div className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">In Progress</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Lead: Dr. Smith</div>
                    <div className="text-sm text-muted-foreground">Target Completion: 09/30/2023</div>
                    <div className="mt-2">
                      <div className="text-xs text-muted-foreground mb-1">Progress: 40%</div>
                      <Progress value={40} className="h-2" />
                    </div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Staff Training Program</div>
                      <div className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Completed</div>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Lead: HR Manager</div>
                    <div className="text-sm text-muted-foreground">Completed: 06/15/2023</div>
                    <div className="mt-2">
                      <div className="text-xs text-muted-foreground mb-1">Progress: 100%</div>
                      <Progress value={100} className="h-2" />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  <Plus className="mr-2 h-4 w-4" />
                  New Improvement Project
                </Button>
              </CardFooter>
            </Card>

            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Patient Feedback</CardTitle>
                <CardDescription>Recent patient feedback and suggestions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="flex items-center gap-2">
                      <div className="bg-blue-100 text-blue-800 p-1 rounded-full">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                        </svg>
                      </div>
                      <div className="font-medium">Sarah J.</div>
                      <div className="text-xs text-muted-foreground">06/28/2023</div>
                    </div>
                    <div className="text-sm mt-2">
                      "The staff was incredibly friendly and professional. Dr. Smith took the time to explain everything
                      in detail. Would recommend!"
                    </div>
                    <div className="flex items-center gap-1 mt-2">
                      <div className="text-yellow-500">★★★★★</div>
                      <div className="text-xs text-muted-foreground">(5.0)</div>
                    </div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center gap-2">
                      <div className="bg-blue-100 text-blue-800 p-1 rounded-full">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                        </svg>
                      </div>
                      <div className="font-medium">Michael T.</div>
                      <div className="text-xs text-muted-foreground">06/25/2023</div>
                    </div>
                    <div className="text-sm mt-2">
                      "Great experience overall. The only suggestion would be to improve the waiting room with more
                      comfortable seating and updated magazines."
                    </div>
                    <div className="flex items-center gap-1 mt-2">
                      <div className="text-yellow-500">★★★★☆</div>
                      <div className="text-xs text-muted-foreground">(4.0)</div>
                    </div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center gap-2">
                      <div className="bg-blue-100 text-blue-800 p-1 rounded-full">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                        </svg>
                      </div>
                      <div className="font-medium">Jennifer L.</div>
                      <div className="text-xs text-muted-foreground">06/22/2023</div>
                    </div>
                    <div className="text-sm mt-2">
                      "I appreciate the text reminders for appointments. The hygienist was thorough and gentle. Will
                      definitely be back!"
                    </div>
                    <div className="flex items-center gap-1 mt-2">
                      <div className="text-yellow-500">★★★★★</div>
                      <div className="text-xs text-muted-foreground">(5.0)</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

