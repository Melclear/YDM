"use client"

import { useState, useEffect } from "react"
import {
  Search,
  Mail,
  Bell,
  ChevronLeft,
  Plus,
  Filter,
  MoreHorizontal,
  ArrowUpRight,
  Edit,
  Trash2,
  Eye,
  FileText,
  MessageSquare,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useInView } from "../hooks/use-in-view"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import CampaignPerformanceChart from "../components/campaign-performance-chart"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

// Sample campaign data
const campaignData = [
  {
    id: 1,
    name: "Spring Dental Checkup Promotion",
    status: "active",
    type: "email",
    startDate: "2024-03-15",
    endDate: "2024-05-30",
    budget: 2500,
    spent: 1200,
    leads: 124,
    conversions: 42,
    roi: 320,
  },
  {
    id: 2,
    name: "Teeth Whitening Special",
    status: "active",
    type: "social",
    startDate: "2024-04-01",
    endDate: "2024-06-15",
    budget: 3000,
    spent: 1800,
    leads: 156,
    conversions: 58,
    roi: 280,
  },
  {
    id: 3,
    name: "Family Dental Plan",
    status: "scheduled",
    type: "email",
    startDate: "2024-06-01",
    endDate: "2024-08-31",
    budget: 4000,
    spent: 0,
    leads: 0,
    conversions: 0,
    roi: 0,
  },
  {
    id: 4,
    name: "Invisalign Awareness",
    status: "active",
    type: "ppc",
    startDate: "2024-02-15",
    endDate: "2024-05-15",
    budget: 5000,
    spent: 3200,
    leads: 210,
    conversions: 68,
    roi: 310,
  },
  {
    id: 5,
    name: "Dental Implant Education",
    status: "draft",
    type: "content",
    startDate: "",
    endDate: "",
    budget: 2000,
    spent: 0,
    leads: 0,
    conversions: 0,
    roi: 0,
  },
  {
    id: 6,
    name: "Back to School Checkups",
    status: "completed",
    type: "social",
    startDate: "2024-01-15",
    endDate: "2024-03-15",
    budget: 1800,
    spent: 1800,
    leads: 98,
    conversions: 32,
    roi: 240,
  },
]

export default function CampaignsPage() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [profileMenuOpen, setProfileMenuOpen] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [selectedCampaign, setSelectedCampaign] = useState(null)
  const chartRef = useInView()
  const pathname = usePathname()

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed)
  }

  // Filter campaigns based on active tab and search query
  const filteredCampaigns = campaignData.filter((campaign) => {
    const matchesTab = activeTab === "all" || campaign.status === activeTab
    const matchesSearch = campaign.name.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesTab && matchesSearch
  })

  // Get campaign status badge color
  const getStatusColor = (status) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "draft":
        return "bg-gray-100 text-gray-800"
      case "completed":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Get campaign type badge color
  const getTypeColor = (type) => {
    switch (type) {
      case "email":
        return "bg-indigo-100 text-indigo-800"
      case "social":
        return "bg-blue-100 text-blue-800"
      case "ppc":
        return "bg-orange-100 text-orange-800"
      case "content":
        return "bg-teal-100 text-teal-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return "—"
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
  }

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileMenuOpen && !event.target.closest(".profile-dropdown")) {
        setProfileMenuOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [profileMenuOpen])

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <div
        className={`${isSidebarCollapsed ? "w-20" : "w-56"} bg-white border-r border-gray-200 p-6 flex flex-col transition-all duration-300 ease-in-out fixed md:relative z-30 h-full ${
          isMobileMenuOpen ? "left-0" : "-left-full md:left-0"
        }`}
      >
        {/* Sidebar Logo */}
        <div className="flex items-center justify-center mb-10">
          {!isSidebarCollapsed ? (
            <div className="flex items-center w-full">
              <div className="flex-1">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Frame%203-r6JD4ntf4G66J4BjdY49D53jAjg40f.png"
                  alt="YDM Logo"
                  width={132}
                  height={42}
                  className="h-11 w-auto"
                />
              </div>
              <button onClick={toggleSidebar} className="text-gray-500 hover:text-[#007CD3] transition-colors">
                <ChevronLeft size={20} />
              </button>
            </div>
          ) : (
            <button
              onClick={toggleSidebar}
              className="flex items-center justify-center hover:opacity-80 transition-opacity"
            >
              <Image src="/images/ydm-icon.png" alt="YDM Icon" width={32} height={32} className="w-8 h-auto" />
            </button>
          )}
        </div>

        <nav className="space-y-2 mb-8">
          <Link
            href="/"
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-layout-grid"
            >
              <rect width="7" height="7" x="3" y="3" rx="1" />
              <rect width="7" height="7" x="14" y="3" rx="1" />
              <rect width="7" height="7" x="14" y="14" rx="1" />
              <rect width="7" height="7" x="3" y="14" rx="1" />
            </svg>
            {!isSidebarCollapsed && <span className="font-medium">Dashboard</span>}
          </Link>

          <Link
            href="/tasks"
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-check-circle"
            >
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
            {!isSidebarCollapsed && (
              <>
                <span>Tasks</span>
                <span className="ml-auto bg-[#007CD3] text-white text-xs px-1.5 py-0.5 rounded">09</span>
              </>
            )}
            {isSidebarCollapsed && (
              <span className="absolute right-1 top-1 bg-[#007CD3] text-white text-xs px-1.5 py-0.5 rounded">09</span>
            )}
          </Link>

          <div className="relative group">
            <Link
              href="/marketing"
              className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-calendar"
              >
                <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
                <line x1="16" x2="16" y1="2" y2="6" />
                <line x1="8" x2="8" y1="2" y2="6" />
                <line x1="3" x2="21" y1="10" y2="10" />
              </svg>
              {!isSidebarCollapsed && (
                <>
                  <span>Marketing</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-auto"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </>
              )}
            </Link>

            {/* Submenu */}
            {!isSidebarCollapsed && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  href="/marketing"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Overview</span>
                </Link>
                <Link
                  href="/campaigns"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-[#007CD3] font-medium hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-[#007CD3] rounded-full"></span>
                  <span>Campaign Manager</span>
                </Link>
                <Link
                  href="/promotions"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Promotions Manager</span>
                </Link>
                <Link
                  href="/competitor-benchmarking"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Competitor Benchmarking</span>
                </Link>
              </div>
            )}
          </div>

          <div className="relative group">
            <Link
              href="/analytics"
              className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-bar-chart"
              >
                <line x1="12" x2="12" y1="20" y2="10" />
                <line x1="18" x2="18" y1="20" y2="4" />
                <line x1="6" x2="6" y1="20" y2="16" />
              </svg>
              {!isSidebarCollapsed && (
                <>
                  <span>Analytics</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-auto"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </>
              )}
            </Link>

            {/* Submenu */}
            {!isSidebarCollapsed && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  href="/analytics"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Overview</span>
                </Link>
                <Link
                  href="/seo-ppc-analytics"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>SEO & PPC Analytics</span>
                </Link>
              </div>
            )}
          </div>

          <Link
            href="/patient"
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-users"
            >
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
            {!isSidebarCollapsed && <span>Patient</span>}
          </Link>

          {/* Submenu */}
          {!isSidebarCollapsed && (
            <div className="pl-8 mt-1 space-y-1">
              <Link
                href="/patient"
                className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
              >
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                <span>Overview</span>
              </Link>
              <Link
                href="/reputation-management"
                className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
              >
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                <span>Reputation Management</span>
              </Link>
              <Link
                href="/patient-loyalty"
                className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
              >
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                <span>Patient Loyalty</span>
              </Link>
            </div>
          )}

          <Link
            href="/reputation-management"
            className={cn(
              `flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`,
              pathname === "/reputation-management" && "bg-muted text-primary",
            )}
          >
            <MessageSquare className="h-5 w-5" />
            {!isSidebarCollapsed && <span>Reputation Management</span>}
          </Link>
        </nav>

        <div className="mt-2 border-t border-gray-100 pt-4"></div>

        <nav className="space-y-2 mb-auto">
          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-settings"
            >
              <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
            {!isSidebarCollapsed && <span>Settings</span>}
          </div>

          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-help-circle"
            >
              <circle cx="12" cy="12" r="10" />
              <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
              <path d="M12 17h.01" />
            </svg>
            {!isSidebarCollapsed && <span>Help</span>}
          </div>

          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-log-out"
            >
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" />
              <line x1="21" x2="9" y1="12" y2="12" />
            </svg>
            {!isSidebarCollapsed && <span>Logout</span>}
          </div>
        </nav>

        {!isSidebarCollapsed && (
          <div className="mt-6 bg-[#007CD3] text-white p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-6 w-6 bg-white rounded-full flex items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-[#007CD3]"
                >
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </div>
              <span className="font-bold">Download our Mobile App</span>
            </div>
            <p className="text-xs mb-4">Get easy to access on your phone</p>
            <button className="w-full bg-[#0065AB] hover:bg-[#00589A] py-2 rounded text-sm font-medium">
              Download
            </button>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 p-4 sm:p-6 md:ml-0">
        {/* Header */}
        <header className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4">
          <div className="relative w-full sm:w-96">
            <input
              type="text"
              placeholder="Search campaigns..."
              className="w-full pl-10 pr-4 py-2 bg-white rounded-md border border-gray-200"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>

          <div className="flex items-center gap-6">
            <button className="text-gray-500">
              <Mail size={20} />
            </button>
            <button className="text-gray-500">
              <Bell size={20} />
            </button>
            <div className="flex items-center relative profile-dropdown">
              <button
                onClick={() => setProfileMenuOpen(!profileMenuOpen)}
                className="h-10 w-10 rounded-full overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <Image src="/images/mcleary.png" alt="Profile" width={40} height={40} className="object-cover" />
              </button>

              {/* Profile Dropdown Menu */}
              {profileMenuOpen && (
                <div className="absolute right-0 top-12 w-56 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200">
                  <div className="px-4 py-3 border-b border-gray-100">
                    <p className="text-sm font-medium">Hi, Melissa</p>
                    <p className="text-xs text-gray-500 truncate">melissa@yourdentalrecruiter.com</p>
                  </div>

                  <div className="py-1">
                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                      >
                        <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                        <circle cx="12" cy="12" r="3" />
                      </svg>
                      Settings
                    </button>

                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                      >
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <path d="M12 17h.01" />
                      </svg>
                      Help
                    </button>
                  </div>

                  <div className="py-1 border-t border-gray-100">
                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                      >
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                        <polyline points="16 17 21 12 16 7" />
                        <line x1="21" x2="9" y1="12" y2="12" />
                      </svg>
                      Logout
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Mobile Menu Trigger */}
        <div className="md:hidden fixed bottom-6 right-6 z-40">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="bg-[#007CD3] text-white p-3 rounded-full shadow-lg"
          >
            {isMobileMenuOpen ? (
              <ChevronLeft size={24} />
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="3" y1="12" x2="21" y2="12" />
                <line x1="3" y1="6" x2="21" y2="6" />
                <line x1="3" y1="18" x2="21" y2="18" />
              </svg>
            )}
          </button>
        </div>

        {/* Dashboard Title */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold mb-1 text-black">Campaign Manager</h1>
            <Link href="/content-generator">
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white font-medium px-6 py-2 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center gap-2"
              >
                <FileText className="w-5 h-5" />
                Content Generator
              </Button>
            </Link>
          </div>
          <p className="text-gray-500">Create, manage, and track your marketing campaigns in one place.</p>
        </div>

        {/* Campaign Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-sm text-gray-500">Active Campaigns</p>
                  <p className="text-3xl font-bold">3</p>
                </div>
                <div className="h-10 w-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-green-600">+1 from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-sm text-gray-500">Total Budget</p>
                  <p className="text-3xl font-bold">$18,300</p>
                </div>
                <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <circle cx="12" cy="12" r="10" />
                    <path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8" />
                    <path d="M12 18V6" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-blue-600">$8,000 allocated this quarter</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-sm text-gray-500">Total Leads</p>
                  <p className="text-3xl font-bold">588</p>
                </div>
                <div className="h-10 w-10 bg-purple-100 rounded-full flex items-center justify-center text-purple-600">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-purple-600">+124 from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-sm text-gray-500">Average ROI</p>
                  <p className="text-3xl font-bold">287%</p>
                </div>
                <div className="h-10 w-10 bg-orange-100 rounded-full flex items-center justify-center text-orange-600">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7Z" />
                    <path d="M5 20a2 2 0 1 0 4 0a2 2 0 1 0-4 0Z" />
                    <path d="M15 20a2 2 0 1 0 4 0a2 2 0 1 0-4 0Z" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-orange-600">+15% from last quarter</p>
            </CardContent>
          </Card>
        </div>

        {/* Campaign Performance Chart */}
        <div ref={chartRef.ref} className="mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-headline">Campaign Performance</CardTitle>
              <CardDescription>Track leads, conversions, and ROI across all campaigns</CardDescription>
            </CardHeader>
            <CardContent>
              <CampaignPerformanceChart isInView={chartRef.isInView} showInsights={true} />
            </CardContent>
          </Card>
        </div>

        {/* Campaign List */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
              <TabsList>
                <TabsTrigger value="all">All Campaigns</TabsTrigger>
                <TabsTrigger value="active">Active</TabsTrigger>
                <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
                <TabsTrigger value="draft">Drafts</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="flex gap-3">
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
              <Link href="/content-generator">
                <Button variant="outline" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  Generate Content
                </Button>
              </Link>
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Create Campaign
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px]">
                  <DialogHeader>
                    <DialogTitle>Create New Campaign</DialogTitle>
                    <DialogDescription>Fill in the details below to create a new marketing campaign.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="name" className="text-right">
                        Name
                      </Label>
                      <Input id="name" placeholder="Campaign name" className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="type" className="text-right">
                        Type
                      </Label>
                      <Select>
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select campaign type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="email">Email</SelectItem>
                          <SelectItem value="social">Social Media</SelectItem>
                          <SelectItem value="ppc">PPC</SelectItem>
                          <SelectItem value="content">Content</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="startDate" className="text-right">
                        Start Date
                      </Label>
                      <Input id="startDate" type="date" className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="endDate" className="text-right">
                        End Date
                      </Label>
                      <Input id="endDate" type="date" className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="budget" className="text-right">
                        Budget
                      </Label>
                      <Input id="budget" type="number" placeholder="0.00" className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="description" className="text-right">
                        Description
                      </Label>
                      <Textarea id="description" placeholder="Campaign description" className="col-span-3" />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit">Create Campaign</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Campaign
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Dates
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Budget
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Performance
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredCampaigns.map((campaign) => (
                    <tr key={campaign.id} className="hover:bg-gray-50">
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900">{campaign.name}</div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(campaign.status)}`}>
                          {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full ${getTypeColor(campaign.type)}`}>
                          {campaign.type.charAt(0).toUpperCase() + campaign.type.slice(1)}
                        </span>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {formatDate(campaign.startDate)} - {formatDate(campaign.endDate)}
                        </div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">${campaign.budget.toLocaleString()}</div>
                        {campaign.spent > 0 && (
                          <div className="text-xs text-gray-500">
                            Spent: ${campaign.spent.toLocaleString()} (
                            {Math.round((campaign.spent / campaign.budget) * 100)}%)
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        {campaign.status === "active" || campaign.status === "completed" ? (
                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs text-gray-500">Leads: {campaign.leads}</span>
                              <span className="text-xs text-gray-500">ROI: {campaign.roi}%</span>
                            </div>
                            <Progress value={Math.min(campaign.roi / 4, 100)} className="h-1.5" />
                          </div>
                        ) : (
                          <span className="text-xs text-gray-500">—</span>
                        )}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <ArrowUpRight className="h-4 w-4 mr-2" />
                              View Analytics
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600">
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {filteredCampaigns.length === 0 && (
              <div className="py-8 text-center">
                <p className="text-gray-500">No campaigns found matching your criteria.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

