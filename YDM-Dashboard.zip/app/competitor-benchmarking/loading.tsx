export default function CompetitorBenchmarkingLoading() {
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="h-8 w-64 bg-gray-200 rounded-md mb-2 animate-pulse"></div>
      <div className="h-4 w-96 bg-gray-200 rounded-md mb-8 animate-pulse"></div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
        <div className="col-span-1 md:col-span-2 lg:col-span-6 bg-white p-6 rounded-lg border border-gray-200">
          <div className="h-6 w-40 bg-gray-200 rounded-md mb-4 animate-pulse"></div>
          <div className="h-64 bg-gray-100 rounded-md animate-pulse"></div>
        </div>

        <div className="col-span-1 md:col-span-2 lg:col-span-6 bg-white p-6 rounded-lg border border-gray-200">
          <div className="h-6 w-48 bg-gray-200 rounded-md mb-4 animate-pulse"></div>
          <div className="h-64 bg-gray-100 rounded-md animate-pulse"></div>
        </div>

        <div className="col-span-1 md:col-span-2 lg:col-span-12 bg-white p-6 rounded-lg border border-gray-200">
          <div className="h-6 w-64 bg-gray-200 rounded-md mb-4 animate-pulse"></div>
          <div className="h-80 bg-gray-100 rounded-md animate-pulse"></div>
        </div>

        <div className="col-span-1 md:col-span-2 lg:col-span-12 bg-white p-6 rounded-lg border border-gray-200">
          <div className="h-6 w-36 bg-gray-200 rounded-md mb-4 animate-pulse"></div>
          <div className="h-80 bg-gray-100 rounded-md animate-pulse"></div>
        </div>

        <div className="col-span-1 md:col-span-2 lg:col-span-4 bg-white p-6 rounded-lg border border-gray-200">
          <div className="h-6 w-32 bg-gray-200 rounded-md mb-4 animate-pulse"></div>
          <div className="h-24 bg-gray-100 rounded-md mb-4 animate-pulse"></div>
          <div className="h-20 bg-gray-100 rounded-md animate-pulse"></div>
        </div>

        <div className="col-span-1 md:col-span-2 lg:col-span-4 bg-white p-6 rounded-lg border border-gray-200">
          <div className="h-6 w-40 bg-gray-200 rounded-md mb-4 animate-pulse"></div>
          <div className="h-24 bg-gray-100 rounded-md mb-4 animate-pulse"></div>
          <div className="h-20 bg-gray-100 rounded-md animate-pulse"></div>
        </div>

        <div className="col-span-1 md:col-span-2 lg:col-span-4 bg-white p-6 rounded-lg border border-gray-200">
          <div className="h-6 w-36 bg-gray-200 rounded-md mb-4 animate-pulse"></div>
          <div className="h-24 bg-gray-100 rounded-md mb-4 animate-pulse"></div>
          <div className="h-20 bg-gray-100 rounded-md animate-pulse"></div>
        </div>
      </div>
    </div>
  )
}

