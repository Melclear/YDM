"use client"

import { useState, useEffect } from "react"
import { Search, Mail, Bell, ChevronRight, Plus, ChevronLeft } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { usePathname } from "next/navigation"

export default function PatientPage() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [profileMenuOpen, setProfileMenuOpen] = useState(false)

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed)
  }

  const pathname = usePathname()

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileMenuOpen && !event.target.closest(".profile-dropdown")) {
        setProfileMenuOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [profileMenuOpen])

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <div
        className={`${isSidebarCollapsed ? "w-20" : "w-56"} bg-white border-r border-gray-200 p-6 flex flex-col transition-all duration-300 ease-in-out`}
      >
        {/* Sidebar Logo */}
        <div className="flex items-center justify-center mb-10">
          {!isSidebarCollapsed ? (
            <div className="flex items-center w-full">
              <div className="flex-1">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Frame%203-r6JD4ntf4G66J4BjdY49D53jAjg40f.png"
                  alt="YDM Logo"
                  width={132}
                  height={42}
                  className="h-11 w-auto"
                />
              </div>
              <button onClick={toggleSidebar} className="text-gray-500 hover:text-[#007CD3] transition-colors">
                <ChevronLeft size={20} />
              </button>
            </div>
          ) : (
            <button
              onClick={toggleSidebar}
              className="flex items-center justify-center hover:opacity-80 transition-opacity"
            >
              <Image src="/images/ydm-icon.png" alt="YDM Icon" width={32} height={32} className="w-8 h-auto" />
            </button>
          )}
        </div>

        <nav className="space-y-2 mb-8">
          <Link
            href="/"
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-layout-grid"
            >
              <rect width="7" height="7" x="3" y="3" rx="1" />
              <rect width="7" height="7" x="14" y="3" rx="1" />
              <rect width="7" height="7" x="14" y="14" rx="1" />
              <rect width="7" height="7" x="3" y="14" rx="1" />
            </svg>
            {!isSidebarCollapsed && <span className="font-medium">Dashboard</span>}
          </Link>

          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-check-circle"
            >
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
            {!isSidebarCollapsed && (
              <>
                <span>Tasks</span>
                <span className="ml-auto bg-[#007CD3] text-white text-xs px-1.5 py-0.5 rounded">09</span>
              </>
            )}
            {isSidebarCollapsed && (
              <span className="absolute right-1 top-1 bg-[#007CD3] text-white text-xs px-1.5 py-0.5 rounded">09</span>
            )}
          </div>

          <div className="relative group">
            <Link
              href="/marketing"
              className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-calendar"
              >
                <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
                <line x1="16" x2="16" y1="2" y2="6" />
                <line x1="8" x2="8" y1="2" y2="6" />
                <line x1="3" x2="21" y1="10" y2="10" />
              </svg>
              {!isSidebarCollapsed && (
                <>
                  <span>Marketing</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-auto"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </>
              )}
            </Link>

            {/* Submenu */}
            {!isSidebarCollapsed && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  href="/marketing"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Overview</span>
                </Link>
                <Link
                  href="/campaigns"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Campaign Manager</span>
                </Link>
                <Link
                  href="/promotions"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Promotions Manager</span>
                </Link>
                <Link
                  href="/competitor-benchmarking"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Competitor Benchmarking</span>
                </Link>
              </div>
            )}
          </div>

          <div className="relative group">
            <Link
              href="/analytics"
              className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="12" x2="12" y1="20" y2="10" />
                <line x1="18" x2="18" y1="20" y2="4" />
                <line x1="6" x2="6" y1="20" y2="16" />
              </svg>
              {!isSidebarCollapsed && (
                <>
                  <span>Analytics</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-auto"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </>
              )}
            </Link>

            {/* Submenu */}
            {!isSidebarCollapsed && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  href="/analytics"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Overview</span>
                </Link>
                <Link
                  href="/seo-ppc-analytics"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>SEO & PPC Analytics</span>
                </Link>
              </div>
            )}
          </div>

          <div className="relative group">
            <Link
              href="/patient"
              className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} bg-blue-50 text-[#007CD3] rounded-md border-l-4 border-[#007CD3]`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-users"
              >
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
              {!isSidebarCollapsed && (
                <>
                  <span>Patient</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-auto"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </>
              )}
            </Link>

            {/* Submenu */}
            {!isSidebarCollapsed && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  href="/patient"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm bg-blue-50 text-[#007CD3] rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-[#007CD3] rounded-full"></span>
                  <span>Overview</span>
                </Link>
                <Link
                  href="/reputation-management"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Reputation Management</span>
                </Link>
                <Link
                  href="/patient-loyalty"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Patient Loyalty</span>
                </Link>
                <Link
                  href="/practice-management"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Practice Management</span>
                </Link>
              </div>
            )}
          </div>
        </nav>

        <div className="mt-2 border-t border-gray-100 pt-4"></div>

        <nav className="space-y-2 mb-auto">
          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-settings"
            >
              <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
            {!isSidebarCollapsed && <span>Settings</span>}
          </div>

          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-help-circle"
            >
              <circle cx="12" cy="12" r="10" />
              <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
              <path d="M12 17h.01" />
            </svg>
            {!isSidebarCollapsed && <span>Help</span>}
          </div>

          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-log-out"
            >
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" />
              <line x1="21" x2="9" y1="12" y2="12" />
            </svg>
            {!isSidebarCollapsed && <span>Logout</span>}
          </div>
        </nav>

        {!isSidebarCollapsed && (
          <div className="mt-6 bg-[#007CD3] text-white p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-6 w-6 bg-white rounded-full flex items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-[#007CD3]"
                >
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </div>
              <span className="font-bold">Download our Mobile App</span>
            </div>
            <p className="text-xs mb-4">Get easy to access on your phone</p>
            <button className="w-full bg-[#0065AB] hover:bg-[#00589A] py-2 rounded text-sm font-medium">
              Download
            </button>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 p-6">
        {/* Header */}
        <header className="flex items-center justify-between mb-8">
          <div className="relative w-96">
            <input
              type="text"
              placeholder="Search"
              className="w-full pl-10 pr-4 py-2 bg-white rounded-md border border-gray-200"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 bg-gray-200 text-gray-600 text-xs px-1.5 py-0.5 rounded">
              ⌘ F
            </div>
          </div>

          <div className="flex items-center gap-6">
            <button className="text-gray-500">
              <Mail size={20} />
            </button>
            <button className="text-gray-500">
              <Bell size={20} />
            </button>
            <div className="flex items-center relative profile-dropdown">
              <button
                onClick={() => setProfileMenuOpen(!profileMenuOpen)}
                className="h-10 w-10 rounded-full overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <Image src="/images/mcleary.png" alt="Profile" width={40} height={40} className="object-cover" />
              </button>

              {/* Profile Dropdown Menu */}
              {profileMenuOpen && (
                <div className="absolute right-0 top-12 w-56 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200">
                  <div className="px-4 py-3 border-b border-gray-100">
                    <p className="text-sm font-medium">Hi, Melissa</p>
                    <p className="text-xs text-gray-500 truncate">melissa@yourdentalrecruiter.com</p>
                  </div>

                  <div className="py-1">
                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                      >
                        <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 2 0 0 1-1-1.74v-.5a2 2 2 0 0 1 1-1.74l.15-.09a2 2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                        <circle cx="12" cy="12" r="3" />
                      </svg>
                      Settings
                    </button>

                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                      >
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <path d="M12 17h.01" />
                      </svg>
                      Help
                    </button>
                  </div>

                  <div className="py-1 border-t border-gray-100">
                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                      >
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                        <polyline points="16 17 21 12 16 7" />
                        <line x1="21" x2="9" y1="12" y2="12" />
                      </svg>
                      Logout
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Dashboard Title */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-1 text-black">Patient Management</h1>
          <p className="text-gray-500">Manage patient records, appointments, and treatment plans efficiently.</p>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-4 mb-6">
          <button className="flex items-center gap-2 bg-white hover:bg-gray-50 text-gray-800 px-4 py-2 rounded-md border border-gray-200">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" x2="12" y1="15" y2="3" />
            </svg>
            Export List
          </button>
          <button className="flex items-center gap-2 bg-[#007CD3] hover:bg-[#0065AB] text-white px-4 py-2 rounded-md">
            <Plus size={18} />
            Add Patient
          </button>
        </div>

        {/* Patient Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-[#007CD3] text-white p-6 rounded-lg">
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="text-sm font-medium mb-1">Total Patients</div>
                <div className="text-4xl font-bold">1,248</div>
              </div>
              <button className="h-8 w-8 rounded-full bg-[#0065AB] flex items-center justify-center">
                <ChevronRight size={18} />
              </button>
            </div>
            <div className="flex items-center text-xs">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-blue-300 mr-1"
              >
                <path d="m6 9 6-6 6 6" />
                <path d="M6 12h12" />
                <path d="m6 15 6 6 6-6" />
              </svg>
              <span className="text-blue-300">+12% from last month</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="text-sm font-medium mb-1">New Patients</div>
                <div className="text-4xl font-bold">86</div>
              </div>
              <button className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center">
                <ChevronRight size={18} />
              </button>
            </div>
            <div className="flex items-center text-xs text-gray-500">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-1"
              >
                <path d="m6 9 6-6 6 6" />
                <path d="M6 12h12" />
                <path d="m6 15 6 6 6-6" />
              </svg>
              <span>This month</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="text-sm font-medium mb-1">Appointments</div>
                <div className="text-4xl font-bold">42</div>
              </div>
              <button className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center">
                <ChevronRight size={18} />
              </button>
            </div>
            <div className="flex items-center text-xs text-gray-500">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-1"
              >
                <path d="m6 9 6-6 6 6" />
                <path d="M6 12h12" />
                <path d="m6 15 6 6 6-6" />
              </svg>
              <span>Today</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="text-sm font-medium mb-1">Recall Due</div>
                <div className="text-4xl font-bold">124</div>
              </div>
              <button className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center">
                <ChevronRight size={18} />
              </button>
            </div>
            <div className="flex items-center text-xs text-gray-500">
              <span>Next 30 days</span>
            </div>
          </div>
        </div>

        {/* Main Patient Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
          {/* Patient List */}
          <div className="col-span-1 md:col-span-2 lg:col-span-8 bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold">Recent Patients</h2>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <select className="appearance-none bg-gray-100 border border-gray-200 rounded-md pl-3 pr-8 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option>All Patients</option>
                    <option>New Patients</option>
                    <option>Scheduled Today</option>
                    <option>Recall Due</option>
                  </select>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 pointer-events-none"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </div>
                <button className="text-xs text-[#007CD3]">View All</button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-sm text-gray-500">Patient Name</th>
                    <th className="text-left py-3 px-4 font-medium text-sm text-gray-500">Contact</th>
                    <th className="text-left py-3 px-4 font-medium text-sm text-gray-500">Last Visit</th>
                    <th className="text-left py-3 px-4 font-medium text-sm text-gray-500">Next Appointment</th>
                    <th className="text-left py-3 px-4 font-medium text-sm text-gray-500">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-sm text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-blue-100 overflow-hidden">
                          <Image
                            src="/placeholder.svg?height=40&width=40"
                            alt="Sarah Johnson"
                            width={40}
                            height={40}
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <div className="font-medium">Sarah Johnson</div>
                          <div className="text-xs text-gray-500">ID: P-1024</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-sm">
                      <div>sarah.j@example.com</div>
                      <div className="text-gray-500">(555) 123-4567</div>
                    </td>
                    <td className="py-3 px-4 text-sm">May 15, 2024</td>
                    <td className="py-3 px-4 text-sm">
                      <div className="font-medium">Jun 20, 2024</div>
                      <div className="text-xs text-gray-500">10:30 AM</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">Active</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <button className="p-1 text-gray-500 hover:text-[#007CD3]">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                          </svg>
                        </button>
                        <button className="p-1 text-gray-500 hover:text-[#007CD3]">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                          </svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-green-100 overflow-hidden">
                          <Image
                            src="/placeholder.svg?height=40&width=40"
                            alt="Michael Chen"
                            width={40}
                            height={40}
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <div className="font-medium">Michael Chen</div>
                          <div className="text-xs text-gray-500">ID: P-1025</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-sm">
                      <div>michael.c@example.com</div>
                      <div className="text-gray-500">(555) 987-6543</div>
                    </td>
                    <td className="py-3 px-4 text-sm">May 18, 2024</td>
                    <td className="py-3 px-4 text-sm">
                      <div className="font-medium">Jun 22, 2024</div>
                      <div className="text-xs text-gray-500">2:15 PM</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">Active</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <button className="p-1 text-gray-500 hover:text-[#007CD3]">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                          </svg>
                        </button>
                        <button className="p-1 text-gray-500 hover:text-[#007CD3]">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                          </svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-purple-100 overflow-hidden">
                          <Image
                            src="/placeholder.svg?height=40&width=40"
                            alt="Jessica Rodriguez"
                            width={40}
                            height={40}
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <div className="font-medium">Jessica Rodriguez</div>
                          <div className="text-xs text-gray-500">ID: P-1026</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-sm">
                      <div>jessica.r@example.com</div>
                      <div className="text-gray-500">(555) 456-7890</div>
                    </td>
                    <td className="py-3 px-4 text-sm">May 20, 2024</td>
                    <td className="py-3 px-4 text-sm">
                      <div className="font-medium text-red-600">Overdue</div>
                      <div className="text-xs text-gray-500">Recall needed</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded-full">Follow-up</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <button className="p-1 text-gray-500 hover:text-[#007CD3]">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                          </svg>
                        </button>
                        <button className="p-1 text-gray-500 hover:text-[#007CD3]">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                          </svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-yellow-100 overflow-hidden">
                          <Image
                            src="/placeholder.svg?height=40&width=40"
                            alt="David Kim"
                            width={40}
                            height={40}
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <div className="font-medium">David Kim</div>
                          <div className="text-xs text-gray-500">ID: P-1027</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-sm">
                      <div>david.k@example.com</div>
                      <div className="text-gray-500">(555) 234-5678</div>
                    </td>
                    <td className="py-3 px-4 text-sm">May 22, 2024</td>
                    <td className="py-3 px-4 text-sm">
                      <div className="font-medium">Today</div>
                      <div className="text-xs text-gray-500">3:45 PM</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">Confirmed</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <button className="p-1 text-gray-500 hover:text-[#007CD3]">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                          </svg>
                        </button>
                        <button className="p-1 text-gray-500 hover:text-[#007CD3]">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                          </svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="flex justify-between items-center mt-4">
              <div className="text-sm text-gray-500">Showing 4 of 1,248 patients</div>
              <div className="flex gap-2">
                <button className="px-3 py-1 border border-gray-200 rounded-md text-sm">Previous</button>
                <button className="px-3 py-1 bg-[#007CD3] text-white rounded-md text-sm">Next</button>
              </div>
            </div>
          </div>

          {/* Today's Appointments */}
          <div className="col-span-1 md:col-span-2 lg:col-span-4 bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold">Today's Appointments</h2>
              <button className="text-xs text-[#007CD3]">View All</button>
            </div>
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                <div className="h-10 w-10 rounded-full bg-blue-100 overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=40&width=40"
                    alt="David Kim"
                    width={40}
                    height={40}
                    className="object-cover"
                  />
                </div>
                <div className="flex-1">
                  <div className="font-medium">David Kim</div>
                  <div className="text-xs text-gray-500">Teeth Cleaning</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">3:45 PM</div>
                  <div className="text-xs text-blue-600">Confirmed</div>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-lg border border-gray-100">
                <div className="h-10 w-10 rounded-full bg-green-100 overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=40&width=40"
                    alt="Emily Wilson"
                    width={40}
                    height={40}
                    className="object-cover"
                  />
                </div>
                <div className="flex-1">
                  <div className="font-medium">Emily Wilson</div>
                  <div className="text-xs text-gray-500">Dental Checkup</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">4:30 PM</div>
                  <div className="text-xs text-gray-500">Scheduled</div>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-lg border border-gray-100">
                <div className="h-10 w-10 rounded-full bg-purple-100 overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=40&width=40"
                    alt="Robert Garcia"
                    width={40}
                    height={40}
                    className="object-cover"
                  />
                </div>
                <div className="flex-1">
                  <div className="font-medium">Robert Garcia</div>
                  <div className="text-xs text-gray-500">Filling</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">5:15 PM</div>
                  <div className="text-xs text-gray-500">Scheduled</div>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-lg border border-gray-100">
                <div className="h-10 w-10 rounded-full bg-red-100 overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=40&width=40"
                    alt="Lisa Thompson"
                    width={40}
                    height={40}
                    className="object-cover"
                  />
                </div>
                <div className="flex-1">
                  <div className="font-medium">Lisa Thompson</div>
                  <div className="text-xs text-gray-500">Consultation</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">6:00 PM</div>
                  <div className="text-xs text-gray-500">Scheduled</div>
                </div>
              </div>
            </div>
            <button className="w-full mt-6 bg-[#007CD3] hover:bg-[#0065AB] text-white py-2 rounded-md text-sm font-medium">
              Schedule New Appointment
            </button>
          </div>

          {/* Treatment Plans */}
          <div className="col-span-1 md:col-span-2 lg:col-span-6 bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold">Treatment Plans</h2>
              <button className="flex items-center gap-1 text-xs bg-gray-100 hover:bg-gray-200 px-2 py-1 rounded">
                <Plus size={14} />
                New Plan
              </button>
            </div>
            <div className="space-y-4">
              <div className="p-4 border border-gray-100 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-medium">Sarah Johnson</div>
                    <div className="text-xs text-gray-500">Created: May 15, 2024</div>
                  </div>
                  <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">In Progress</span>
                </div>
                <div className="mt-3">
                  <div className="text-sm font-medium mb-1">Comprehensive Dental Restoration</div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-2 flex-1 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: "60%" }}></div>
                    </div>
                    <span className="text-xs text-gray-500">60%</span>
                  </div>
                  <div className="text-xs text-gray-500">Next appointment: Jun 20, 2024</div>
                </div>
              </div>

              <div className="p-4 border border-gray-100 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-medium">Michael Chen</div>
                    <div className="text-xs text-gray-500">Created: May 18, 2024</div>
                  </div>
                  <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">In Progress</span>
                </div>
                <div className="mt-3">
                  <div className="text-sm font-medium mb-1">Orthodontic Treatment</div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-2 flex-1 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: "25%" }}></div>
                    </div>
                    <span className="text-xs text-gray-500">25%</span>
                  </div>
                  <div className="text-xs text-gray-500">Next appointment: Jun 22, 2024</div>
                </div>
              </div>

              <div className="p-4 border border-gray-100 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-medium">Jessica Rodriguez</div>
                    <div className="text-xs text-gray-500">Created: May 20, 2024</div>
                  </div>
                  <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded-full">Pending</span>
                </div>
                <div className="mt-3">
                  <div className="text-sm font-medium mb-1">Root Canal Treatment</div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-2 flex-1 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 rounded-full" style={{ width: "0%" }}></div>
                    </div>
                    <span className="text-xs text-gray-500">0%</span>
                  </div>
                  <div className="text-xs text-gray-500">Awaiting patient confirmation</div>
                </div>
              </div>
            </div>
          </div>

          {/* Patient Demographics */}
          <div className="col-span-1 md:col-span-2 lg:col-span-6 bg-white p-6 rounded-lg border border-gray-200">
            <h2 className="text-lg font-bold mb-6">Patient Demographics</h2>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Age Groups</div>
                <div className="flex items-end h-32 gap-2">
                  <div className="flex flex-col items-center flex-1">
                    <div className="w-full bg-blue-200 rounded-t-md" style={{ height: "30%" }}></div>
                    <div className="mt-1 text-xs">0-18</div>
                  </div>
                  <div className="flex flex-col items-center flex-1">
                    <div className="w-full bg-blue-400 rounded-t-md" style={{ height: "60%" }}></div>
                    <div className="mt-1 text-xs">19-35</div>
                  </div>
                  <div className="flex flex-col items-center flex-1">
                    <div className="w-full bg-blue-600 rounded-t-md" style={{ height: "80%" }}></div>
                    <div className="mt-1 text-xs">36-50</div>
                  </div>
                  <div className="flex flex-col items-center flex-1">
                    <div className="w-full bg-blue-800 rounded-t-md" style={{ height: "50%" }}></div>
                    <div className="mt-1 text-xs">51-65</div>
                  </div>
                  <div className="flex flex-col items-center flex-1">
                    <div className="w-full bg-blue-900 rounded-t-md" style={{ height: "40%" }}></div>
                    <div className="mt-1 text-xs">65+</div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Gender Distribution</div>
                <div className="relative h-32 flex items-center justify-center">
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    <circle cx="50" cy="50" r="45" fill="none" stroke="#e6e6e6" strokeWidth="10" />
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke="#007CD3"
                      strokeWidth="10"
                      strokeDasharray="282.7"
                      strokeDashoffset="141.35"
                      strokeLinecap="round"
                      transform="rotate(-90 50 50)"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-2xl font-bold">50/50</div>
                      <div className="text-xs text-gray-500">Male/Female</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-sm text-gray-500 mb-3">Insurance Coverage</div>
              <div className="space-y-2">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Private Insurance</span>
                    <span>65%</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full bg-[#007CD3] rounded-full" style={{ width: "65%" }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Medicare/Medicaid</span>
                    <span>20%</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full bg-[#3399E0] rounded-full" style={{ width: "20%" }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Self-Pay</span>
                    <span>15%</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full bg-[#0065AB] rounded-full" style={{ width: "15%" }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Patient Communication */}
          <div className="col-span-1 md:col-span-2 lg:col-span-6 bg-[#007CD3] p-6 rounded-lg text-white">
            <h2 className="text-lg font-bold mb-6">Patient Communication</h2>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-[#0065AB] p-4 rounded-lg">
                <div className="text-sm mb-2">Appointment Reminders</div>
                <div className="text-3xl font-bold mb-1">124</div>
                <div className="text-xs">Sent this week</div>
              </div>
              <div className="bg-[#0065AB] p-4 rounded-lg">
                <div className="text-sm mb-2">Recall Notifications</div>
                <div className="text-3xl font-bold mb-1">86</div>
                <div className="text-xs">Sent this month</div>
              </div>
            </div>
            <div className="bg-[#0065AB] p-4 rounded-lg mb-6">
              <div className="text-sm mb-2">Communication Channels</div>
              <div className="flex items-center gap-4 justify-between">
                <div className="flex flex-col items-center">
                  <div className="text-xl font-bold">65%</div>
                  <div className="text-xs">SMS</div>
                </div>
                <div className="flex flex-col items-center">
                  <div className="text-xl font-bold">25%</div>
                  <div className="text-xs">Email</div>
                </div>
                <div className="flex flex-col items-center">
                  <div className="text-xl font-bold">10%</div>
                  <div className="text-xs">Phone</div>
                </div>
              </div>
            </div>
            <button className="w-full bg-white text-[#007CD3] py-2 rounded-md text-sm font-medium">
              Send Mass Communication
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

