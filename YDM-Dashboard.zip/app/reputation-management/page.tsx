"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ThumbsUp, Bell, Search, Filter, MessageCircle, Share2, Mail, ChevronLeft } from "lucide-react"
import { usePathname } from "next/navigation"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"

import { ReviewsOverview } from "@/components/reviews-overview"
import { ReviewsList } from "@/components/reviews-list"
import { MentionsTracker } from "@/components/mentions-tracker"
import { SocialSentimentChart } from "@/components/social-sentiment-chart"
import { ReputationInsights } from "@/components/reputation-insights"
import { CompetitorComparison } from "@/components/competitor-comparison"

export default function ReputationManagementPage() {
  const [activeTab, setActiveTab] = useState("reviews")
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [profileMenuOpen, setProfileMenuOpen] = useState(false)
  const pathname = usePathname()

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed)
  }

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileMenuOpen && !event.target.closest(".profile-dropdown")) {
        setProfileMenuOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [profileMenuOpen])

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <div
        className={`${isSidebarCollapsed ? "w-20" : "w-56"} bg-white border-r border-gray-200 p-6 flex flex-col transition-all duration-300 ease-in-out`}
      >
        {/* Sidebar Logo */}
        <div className="flex items-center justify-center mb-10">
          {!isSidebarCollapsed ? (
            <div className="flex items-center w-full">
              <div className="flex-1">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Frame%203-r6JD4ntf4G66J4BjdY49D53jAjg40f.png"
                  alt="YDM Logo"
                  width={132}
                  height={42}
                  className="h-11 w-auto"
                />
              </div>
              <button onClick={toggleSidebar} className="text-gray-500 hover:text-[#007CD3] transition-colors">
                <ChevronLeft size={20} />
              </button>
            </div>
          ) : (
            <button
              onClick={toggleSidebar}
              className="flex items-center justify-center hover:opacity-80 transition-opacity"
            >
              <Image src="/images/ydm-icon.png" alt="YDM Icon" width={32} height={32} className="w-8 h-auto" />
            </button>
          )}
        </div>

        <nav className="space-y-2 mb-8">
          <Link
            href="/"
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-layout-grid"
            >
              <rect width="7" height="7" x="3" y="3" rx="1" />
              <rect width="7" height="7" x="14" y="3" rx="1" />
              <rect width="7" height="7" x="14" y="14" rx="1" />
              <rect width="7" height="7" x="3" y="14" rx="1" />
            </svg>
            {!isSidebarCollapsed && <span className="font-medium">Dashboard</span>}
          </Link>

          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-check-circle"
            >
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
            {!isSidebarCollapsed && (
              <>
                <span>Tasks</span>
                <span className="ml-auto bg-[#007CD3] text-white text-xs px-1.5 py-0.5 rounded">09</span>
              </>
            )}
            {isSidebarCollapsed && (
              <span className="absolute right-1 top-1 bg-[#007CD3] text-white text-xs px-1.5 py-0.5 rounded">09</span>
            )}
          </div>

          <div className="relative group">
            <Link
              href="/marketing"
              className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-calendar"
              >
                <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
                <line x1="16" x2="16" y1="2" y2="6" />
                <line x1="8" x2="8" y1="2" y2="6" />
                <line x1="3" x2="21" y1="10" y2="10" />
              </svg>
              {!isSidebarCollapsed && (
                <>
                  <span>Marketing</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-auto"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </>
              )}
            </Link>

            {/* Submenu */}
            {!isSidebarCollapsed && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  href="/marketing"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Overview</span>
                </Link>
                <Link
                  href="/campaigns"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Campaign Manager</span>
                </Link>
                <Link
                  href="/promotions"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Promotions Manager</span>
                </Link>
                <Link
                  href="/competitor-benchmarking"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Competitor Benchmarking</span>
                </Link>
              </div>
            )}
          </div>

          <div className="relative group">
            <Link
              href="/analytics"
              className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="12" x2="12" y1="20" y2="10" />
                <line x1="18" x2="18" y1="20" y2="4" />
                <line x1="6" x2="6" y1="20" y2="16" />
              </svg>
              {!isSidebarCollapsed && (
                <>
                  <span>Analytics</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-auto"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </>
              )}
            </Link>

            {/* Submenu */}
            {!isSidebarCollapsed && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  href="/analytics"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Overview</span>
                </Link>
                <Link
                  href="/seo-ppc-analytics"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>SEO & PPC Analytics</span>
                </Link>
              </div>
            )}
          </div>

          <div className="relative group">
            <Link
              href="/patient"
              className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-users"
              >
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
              {!isSidebarCollapsed && (
                <>
                  <span>Patient</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-auto"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </>
              )}
            </Link>

            {/* Submenu */}
            {!isSidebarCollapsed && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  href="/patient"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Overview</span>
                </Link>
                <Link
                  href="/reputation-management"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm bg-blue-50 text-[#007CD3] rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-[#007CD3] rounded-full"></span>
                  <span>Reputation Management</span>
                </Link>
                <Link
                  href="/patient-loyalty"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Patient Loyalty</span>
                </Link>
              </div>
            )}
          </div>
        </nav>

        <div className="mt-2 border-t border-gray-100 pt-4"></div>

        <nav className="space-y-2 mb-auto">
          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-settings"
            >
              <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
            {!isSidebarCollapsed && <span>Settings</span>}
          </div>

          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-help-circle"
            >
              <circle cx="12" cy="12" r="10" />
              <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
              <path d="M12 17h.01" />
            </svg>
            {!isSidebarCollapsed && <span>Help</span>}
          </div>

          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-log-out"
            >
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" />
              <line x1="21" x2="9" y1="12" y2="12" />
            </svg>
            {!isSidebarCollapsed && <span>Logout</span>}
          </div>
        </nav>

        {!isSidebarCollapsed && (
          <div className="mt-6 bg-[#007CD3] text-white p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-6 w-6 bg-white rounded-full flex items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-[#007CD3]"
                >
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </div>
              <span className="font-bold">Download our Mobile App</span>
            </div>
            <p className="text-xs mb-4">Get easy to access on your phone</p>
            <button className="w-full bg-[#0065AB] hover:bg-[#00589A] py-2 rounded text-sm font-medium">
              Download
            </button>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 p-6">
        {/* Header */}
        <header className="flex items-center justify-between mb-8">
          <div className="relative w-96">
            <input
              type="text"
              placeholder="Search"
              className="w-full pl-10 pr-4 py-2 bg-white rounded-md border border-gray-200"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 bg-gray-200 text-gray-600 text-xs px-1.5 py-0.5 rounded">
              ⌘ F
            </div>
          </div>

          <div className="flex items-center gap-6">
            <button className="text-gray-500">
              <Mail size={20} />
            </button>
            <button className="text-gray-500">
              <Bell size={20} />
            </button>
            <div className="flex items-center relative profile-dropdown">
              <button
                onClick={() => setProfileMenuOpen(!profileMenuOpen)}
                className="h-10 w-10 rounded-full overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <Image src="/images/mcleary.png" alt="Profile" width={40} height={40} className="object-cover" />
              </button>

              {/* Profile Dropdown Menu */}
              {profileMenuOpen && (
                <div className="absolute right-0 top-12 w-56 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200">
                  <div className="px-4 py-3 border-b border-gray-100">
                    <p className="text-sm font-medium">Hi, Melissa</p>
                    <p className="text-xs text-gray-500 truncate">melissa@yourdentalrecruiter.com</p>
                  </div>

                  <div className="py-1">
                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                      >
                        <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                        <circle cx="12" cy="12" r="3" />
                      </svg>
                      Settings
                    </button>

                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                      >
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <path d="M12 17h.01" />
                      </svg>
                      Help
                    </button>
                  </div>

                  <div className="py-1 border-t border-gray-100">
                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                      >
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                        <polyline points="16 17 21 12 16 7" />
                        <line x1="21" x2="9" y1="12" y2="12" />
                      </svg>
                      Logout
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Dashboard Title */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-1 text-black">Reputation Management</h1>
          <p className="text-gray-500">Monitor and manage your practice's online reputation across the web</p>
        </div>

        {/* Main Content */}
        <div className="flex flex-col gap-4 md:flex-row">
          <Card className="flex-1">
            <CardHeader className="pb-2">
              <CardTitle>Reputation Score</CardTitle>
              <CardDescription>Overall online reputation based on reviews, mentions, and sentiment</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center py-4">
                <div className="relative h-40 w-40">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <span className="text-5xl font-bold">87</span>
                      <span className="text-sm text-muted-foreground">/100</span>
                    </div>
                  </div>
                  <svg className="h-full w-full" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="45" fill="none" stroke="#e2e8f0" strokeWidth="10" />
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="10"
                      strokeDasharray="282.7"
                      strokeDashoffset="36.8"
                      strokeLinecap="round"
                      transform="rotate(-90 50 50)"
                    />
                  </svg>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Reviews</p>
                  <p className="text-2xl font-bold">4.7</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Mentions</p>
                  <p className="text-2xl font-bold">92%</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Sentiment</p>
                  <p className="text-2xl font-bold">+78</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <p className="text-xs text-muted-foreground">
                <ThumbsUp className="mr-1 inline h-3 w-3" />
                Your reputation score has increased by 4 points in the last 30 days
              </p>
            </CardFooter>
          </Card>

          <Card className="flex-1">
            <CardHeader className="pb-2">
              <CardTitle>Review Distribution</CardTitle>
              <CardDescription>Reviews across platforms</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center">
                      <Image
                        src="/placeholder.svg?height=20&width=20"
                        alt="Google"
                        width={20}
                        height={20}
                        className="mr-2"
                      />
                      <span>Google</span>
                    </div>
                    <span className="font-medium">4.8 (124)</span>
                  </div>
                  <Progress value={96} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center">
                      <Image
                        src="/placeholder.svg?height=20&width=20"
                        alt="Yelp"
                        width={20}
                        height={20}
                        className="mr-2"
                      />
                      <span>Yelp</span>
                    </div>
                    <span className="font-medium">4.5 (87)</span>
                  </div>
                  <Progress value={90} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center">
                      <Image
                        src="/placeholder.svg?height=20&width=20"
                        alt="Facebook"
                        width={20}
                        height={20}
                        className="mr-2"
                      />
                      <span>Facebook</span>
                    </div>
                    <span className="font-medium">4.7 (56)</span>
                  </div>
                  <Progress value={94} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center">
                      <Image
                        src="/placeholder.svg?height=20&width=20"
                        alt="Healthgrades"
                        width={20}
                        height={20}
                        className="mr-2"
                      />
                      <span>Healthgrades</span>
                    </div>
                    <span className="font-medium">4.6 (42)</span>
                  </div>
                  <Progress value={92} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center">
                      <Image
                        src="/placeholder.svg?height=20&width=20"
                        alt="ZocDoc"
                        width={20}
                        height={20}
                        className="mr-2"
                      />
                      <span>ZocDoc</span>
                    </div>
                    <span className="font-medium">4.9 (38)</span>
                  </div>
                  <Progress value={98} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          <ReputationInsights />
        </div>

        <Tabs defaultValue="reviews" className="w-full mt-6" onValueChange={setActiveTab}>
          <div className="flex items-center justify-between">
            <TabsList>
              <TabsTrigger value="reviews" className="relative">
                Reviews
                <Badge className="ml-2 bg-primary/20 text-primary" variant="secondary">
                  12 new
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="mentions">Mentions</TabsTrigger>
              <TabsTrigger value="social">Social Listening</TabsTrigger>
              <TabsTrigger value="competitors">Competitor Analysis</TabsTrigger>
            </TabsList>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input type="search" placeholder="Search..." className="w-[200px] pl-8 md:w-[260px]" />
              </div>

              <Select defaultValue="30days">
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Select timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7days">Last 7 days</SelectItem>
                  <SelectItem value="30days">Last 30 days</SelectItem>
                  <SelectItem value="90days">Last 90 days</SelectItem>
                  <SelectItem value="year">Last year</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <TabsContent value="reviews" className="mt-6">
            <div className="grid gap-6 md:grid-cols-7">
              <div className="md:col-span-2">
                <ReviewsOverview />
              </div>
              <div className="md:col-span-5">
                <ReviewsList />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="mentions" className="mt-6">
            <MentionsTracker />
          </TabsContent>

          <TabsContent value="social" className="mt-6">
            <div className="grid gap-6 md:grid-cols-3">
              <div className="space-y-6 md:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Social Media Sentiment</CardTitle>
                    <CardDescription>Analysis of sentiment across social media platforms</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[300px]">
                    <SocialSentimentChart />
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Trending Topics</CardTitle>
                    <CardDescription>Popular topics related to your practice</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary" className="text-sm">
                        Invisalign <span className="ml-1 text-xs text-muted-foreground">+24%</span>
                      </Badge>
                      <Badge variant="secondary" className="text-sm">
                        Teeth Whitening <span className="ml-1 text-xs text-muted-foreground">+18%</span>
                      </Badge>
                      <Badge variant="secondary" className="text-sm">
                        Dental Implants <span className="ml-1 text-xs text-muted-foreground">+15%</span>
                      </Badge>
                      <Badge variant="secondary" className="text-sm">
                        Pediatric Dentistry <span className="ml-1 text-xs text-muted-foreground">+12%</span>
                      </Badge>
                      <Badge variant="secondary" className="text-sm">
                        Emergency Dental <span className="ml-1 text-xs text-muted-foreground">+10%</span>
                      </Badge>
                      <Badge variant="secondary" className="text-sm">
                        Dental Insurance <span className="ml-1 text-xs text-muted-foreground">+8%</span>
                      </Badge>
                      <Badge variant="secondary" className="text-sm">
                        Dental Anxiety <span className="ml-1 text-xs text-muted-foreground">+7%</span>
                      </Badge>
                      <Badge variant="secondary" className="text-sm">
                        Cosmetic Dentistry <span className="ml-1 text-xs text-muted-foreground">+6%</span>
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div>
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle>Social Media Mentions</CardTitle>
                    <CardDescription>Recent mentions across platforms</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {socialMentions.map((mention, index) => (
                        <div key={index} className="rounded-lg border p-3">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3">
                              <Avatar>
                                <AvatarImage src={mention.avatar} alt={mention.name} />
                                <AvatarFallback>{mention.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{mention.name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {mention.platform} • {mention.time}
                                </p>
                              </div>
                            </div>
                            <Badge
                              variant={
                                mention.sentiment === "positive"
                                  ? "success"
                                  : mention.sentiment === "negative"
                                    ? "destructive"
                                    : "outline"
                              }
                            >
                              {mention.sentiment}
                            </Badge>
                          </div>
                          <p className="mt-2 text-sm">{mention.content}</p>
                          <div className="mt-2 flex items-center gap-3">
                            <Button variant="ghost" size="sm">
                              <MessageCircle className="mr-1 h-4 w-4" />
                              Reply
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Share2 className="mr-1 h-4 w-4" />
                              Share
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      View All Mentions
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="competitors" className="mt-6">
            <CompetitorComparison />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

// Demo data for social mentions
const socialMentions = [
  {
    name: "Sarah Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    platform: "Twitter",
    time: "2 hours ago",
    content:
      "Just had the best experience at @BrightSmileDental! Dr. Thompson was so gentle and explained everything. Definitely recommend! #DentalCare",
    sentiment: "positive",
  },
  {
    name: "Mike Reynolds",
    avatar: "/placeholder.svg?height=40&width=40",
    platform: "Facebook",
    time: "Yesterday",
    content:
      "Bright Smile Dental's new office is amazing! The staff was friendly and they have TVs on the ceiling to watch during procedures. Great distraction!",
    sentiment: "positive",
  },
  {
    name: "Chris Davis",
    avatar: "/placeholder.svg?height=40&width=40",
    platform: "Instagram",
    time: "3 days ago",
    content:
      "Had to wait 30 minutes past my appointment time at Bright Smile Dental today. Not happy with the scheduling system. Staff was apologetic though.",
    sentiment: "negative",
  },
  {
    name: "Taylor Wilson",
    avatar: "/placeholder.svg?height=40&width=40",
    platform: "Twitter",
    time: "1 week ago",
    content:
      "Looking for recommendations for a good dentist in the downtown area. Has anyone tried Bright Smile Dental? Are they accepting new patients?",
    sentiment: "neutral",
  },
]

