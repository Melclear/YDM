import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"

export default function Loading() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-8 w-[250px]" />
            <Skeleton className="mt-2 h-4 w-[350px]" />
          </div>
          <div className="flex items-center gap-2">
            <Skeleton className="h-9 w-[140px]" />
            <Skeleton className="h-9 w-[140px]" />
          </div>
        </div>

        <div className="flex flex-col gap-4 md:flex-row">
          <Card className="flex-1">
            <CardHeader className="pb-2">
              <Skeleton className="h-6 w-[150px]" />
              <Skeleton className="h-4 w-[250px]" />
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center py-4">
                <Skeleton className="h-40 w-40 rounded-full" />
              </div>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <Skeleton className="mx-auto h-4 w-[80px]" />
                  <Skeleton className="mx-auto mt-2 h-6 w-[40px]" />
                </div>
                <div>
                  <Skeleton className="mx-auto h-4 w-[80px]" />
                  <Skeleton className="mx-auto mt-2 h-6 w-[40px]" />
                </div>
                <div>
                  <Skeleton className="mx-auto h-4 w-[80px]" />
                  <Skeleton className="mx-auto mt-2 h-6 w-[40px]" />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Skeleton className="h-4 w-full" />
            </CardFooter>
          </Card>

          <Card className="flex-1">
            <CardHeader className="pb-2">
              <Skeleton className="h-6 w-[180px]" />
              <Skeleton className="h-4 w-[150px]" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Skeleton className="h-5 w-[120px]" />
                      <Skeleton className="h-5 w-[60px]" />
                    </div>
                    <Skeleton className="h-2 w-full" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="flex-1">
            <CardHeader className="pb-2">
              <Skeleton className="h-6 w-[180px]" />
              <Skeleton className="h-4 w-[220px]" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[...Array(4)].map((_, i) => (
                  <Skeleton key={i} className="h-[72px] w-full rounded-lg" />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Skeleton className="h-10 w-[400px]" />
          <div className="mt-6 grid gap-6 md:grid-cols-7">
            <div className="md:col-span-2">
              <Skeleton className="h-[500px] w-full rounded-lg" />
            </div>
            <div className="md:col-span-5">
              <Skeleton className="h-[500px] w-full rounded-lg" />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

