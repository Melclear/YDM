"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"
import { useInView } from "../hooks/use-in-view"

type TrafficSourcesChartProps = {}

const TrafficSourcesChart: React.FC<TrafficSourcesChartProps> = () => {
  const trafficChartRef = useInView()
  const [animationState, setAnimationState] = useState(trafficChartRef.isInView ? "animate-spin-slow" : "")

  useEffect(() => {
    if (trafficChartRef.isInView) {
      setAnimationState("animate-spin-slow")
    } else {
      setAnimationState("")
    }
  }, [trafficChartRef.isInView])

  const data = [
    { name: "Organic Search", value: 40, color: "#007CD3" },
    { name: "Social Media", value: 25, color: "#3399E0" },
    { name: "Direct", value: 15, color: "#0065AB" },
    { name: "Referral", value: 12, color: "#B4D0E7" },
    { name: "Email", value: 8, color: "#6B7280" },
  ]

  return (
    <div ref={trafficChartRef.ref} className="bg-white p-4 sm:p-6 rounded-lg border border-gray-200">
      <h2 className="text-lg font-bold mb-4">Website Traffic Sources</h2>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={90}
              paddingAngle={2}
              dataKey="value"
              className={animationState}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip formatter={(value) => [`${value}%`, "Percentage"]} labelFormatter={(name) => `Source: ${name}`} />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="flex flex-wrap justify-center gap-4 mt-4">
        {data.map((entry, index) => (
          <div key={`legend-${index}`} className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="text-sm text-gray-700">
              {entry.name}: {entry.value}%
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

export { TrafficSourcesChart }

