"use client"

import type React from "react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

interface PromotionPerformanceChartProps {
  isInView: boolean
}

const PromotionPerformanceChart: React.FC<PromotionPerformanceChartProps> = ({ isInView }) => {
  const data = [
    { month: "Jan", redemptions: 20, revenue: 2000, roi: 250 },
    { month: "Feb", redemptions: 25, revenue: 2500, roi: 270 },
    { month: "Mar", redemptions: 30, revenue: 3000, roi: 290 },
    { month: "Apr", redemptions: 35, revenue: 3500, roi: 310 },
    { month: "May", redemptions: 40, revenue: 4000, roi: 330 },
    { month: "Jun", redemptions: 45, revenue: 4500, roi: 350 },
  ]

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart
        data={data}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line
          type="monotone"
          dataKey="redemptions"
          stroke="#007CD3"
          strokeWidth={2}
          animationBegin={isInView ? 0 : "indefinite"}
          animationDuration={1500}
        />
        <Line
          type="monotone"
          dataKey="revenue"
          stroke="#3399E0"
          strokeWidth={2}
          animationBegin={isInView ? 0 : "indefinite"}
          animationDuration={1500}
          animationDelay={100}
        />
        <Line
          type="monotone"
          dataKey="roi"
          stroke="#0065AB"
          strokeWidth={2}
          animationBegin={isInView ? 0 : "indefinite"}
          animationDuration={1500}
          animationDelay={200}
        />
      </LineChart>
    </ResponsiveContainer>
  )
}

export default PromotionPerformanceChart

