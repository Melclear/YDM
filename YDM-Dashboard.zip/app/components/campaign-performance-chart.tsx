"use client"

import type React from "react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

interface CampaignPerformanceChartProps {
  isInView: boolean
}

const CampaignPerformanceChart: React.FC<CampaignPerformanceChartProps> = ({ isInView }) => {
  const data = [
    { month: "Jan", leads: 40, conversions: 20, roi: 250 },
    { month: "Feb", leads: 42, conversions: 22, roi: 270 },
    { month: "Mar", leads: 45, conversions: 25, roi: 290 },
    { month: "Apr", leads: 47, conversions: 28, roi: 310 },
    { month: "May", leads: 50, conversions: 31, roi: 330 },
    { month: "Jun", leads: 52, conversions: 32, roi: 350 },
  ]

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart
        data={data}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line
          type="monotone"
          dataKey="leads"
          stroke="#007CD3"
          strokeWidth={2}
          animationBegin={isInView ? 0 : "indefinite"}
          animationDuration={1500}
        />
        <Line
          type="monotone"
          dataKey="conversions"
          stroke="#3399E0"
          strokeWidth={2}
          animationBegin={isInView ? 0 : "indefinite"}
          animationDuration={1500}
          animationDelay={100}
        />
        <Line
          type="monotone"
          dataKey="roi"
          stroke="#0065AB"
          strokeWidth={2}
          animationBegin={isInView ? 0 : "indefinite"}
          animationDuration={1500}
          animationDelay={200}
        />
      </LineChart>
    </ResponsiveContainer>
  )
}

export default CampaignPerformanceChart

