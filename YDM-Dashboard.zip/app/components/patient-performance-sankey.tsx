"use client"
import CustomSankeyDiagram from "./custom-sankey-diagram"

const PatientPerformanceSankey = () => {
  const data = {
    nodes: [
      { id: "Preventive Care" },
      { id: "Restorative Treatments" },
      { id: "Cosmetic Dentistry" },
      { id: "Periodontal (Gum) Treatments" },
      { id: "Orthodontics" },
      { id: "Specialty Services" },
      { id: "Advanced Procedures" },
      { id: "Initial" },
      { id: "Consultation" },
      { id: "Treatment Plan" },
      { id: "Scheduled" },
      { id: "Completed" },
    ],
    links: [
      { source: "Preventive Care", target: "Initial", value: 200 },
      { source: "Restorative Treatments", target: "Initial", value: 150 },
      { source: "Cosmetic Dentistry", target: "Initial", value: 100 },
      { source: "Periodontal (Gum) Treatments", target: "Initial", value: 80 },
      { source: "Orthodontics", target: "Initial", value: 70 },
      { source: "Specialty Services", target: "Initial", value: 60 },
      { source: "Advanced Procedures", target: "Initial", value: 50 },
      { source: "Initial", target: "Consultation", value: 710 },
      { source: "Consultation", target: "Treatment Plan", value: 680 },
      { source: "Treatment Plan", target: "Scheduled", value: 650 },
      { source: "Scheduled", target: "Completed", value: 630 },
    ],
  }

  return (
    <CustomSankeyDiagram
      data={data}
      nodeWidth={15}
      nodePadding={10}
      nodeAlign="justify"
      formatValue={(value: number) => `${value}`}
      height={300}
    />
  )
}

export default PatientPerformanceSankey

