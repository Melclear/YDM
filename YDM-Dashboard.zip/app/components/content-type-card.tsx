"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useInView } from "../hooks/use-in-view"

type ContentTypeCardProps = {}

const ContentTypeCard: React.FC<ContentTypeCardProps> = () => {
  const chartRef = useInView();
  const [animationState, setAnimationState] = useState(chartRef.isInView ? 'animate-spin-slow' : '');

  useEffect(() => {
    if (chartRef.isInView) {
      setAnimationState('animate-spin-slow');
    } else {
      setAnimationState('');
    }
  }, [chartRef.isInView]);

  const data = [
    { name: "Video", value: 35, color: "#007CD3" },
    { name: "Image", value: 25, color: "#3399E0" },
    { name: "Blog", value: 20, color: "#0065AB" },
    { name: "Google Business",\

