"use client"

import { useState } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import {
  ChevronLeft,
  Award,
  Gift,
  Calendar,
  CheckCircle,
  Circle,
  DollarSign,
  TrendingUp,
  MessageSquare,
  Share2,
  Users,
  Zap,
  ArrowRight,
  ChevronRight,
  Info,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

// Sample patient data
const patientsData = {
  "1": {
    id: 1,
    name: "Sarah Johnson",
    email: "sarah.j@example.com",
    phone: "(555) 123-4567",
    avatar: "/placeholder.svg?height=128&width=128",
    lifetimeValue: 4850,
    revenue: {
      total: 4850,
      lastVisit: 350,
      avgPerVisit: 320,
    },
    loyaltyPoints: 4200,
    tier: "platinum",
    tierHistory: [
      { tier: "bronze", achievedDate: "2021-06-15" },
      { tier: "silver", achievedDate: "2021-09-22" },
      { tier: "gold", achievedDate: "2022-03-10" },
      { tier: "platinum", achievedDate: "2022-11-05" },
    ],
    pointsToNextTier: 0,
    lastVisit: "2023-11-15",
    nextAppointment: "2023-12-20",
    riskLevel: "low",
    referrals: 5,
    procedures: ["Cleaning", "Whitening", "Implant"],
    pointsHistory: [
      { date: "2023-11-15", points: 350, description: "Dental cleaning and checkup" },
      { date: "2023-09-02", points: 500, description: "Whitening procedure" },
      { date: "2023-07-18", points: 250, description: "Referred Jane Smith" },
      { date: "2023-06-05", points: 350, description: "Dental cleaning and checkup" },
      { date: "2023-04-22", points: 250, description: "Referred Michael Brown" },
      { date: "2023-03-10", points: 1000, description: "Dental implant procedure" },
      { date: "2023-01-20", points: 350, description: "Dental cleaning and checkup" },
      { date: "2022-11-05", points: 250, description: "Referred David Wilson" },
      { date: "2022-09-15", points: 350, description: "Dental cleaning and checkup" },
      { date: "2022-07-22", points: 550, description: "Root canal and crown" },
    ],
    rewardsRedeemed: [
      { date: "2023-08-10", reward: "Free teeth whitening", points: 1500 },
      { date: "2023-02-15", reward: "Electric toothbrush", points: 800 },
      { date: "2022-10-05", reward: "Dental care package", points: 500 },
    ],
    availableRewards: [
      { name: "Free dental cleaning", points: 1000, expires: "2024-06-30" },
      { name: "50% off next cosmetic procedure", points: 2000, expires: "2024-03-15" },
      { name: "Premium electric toothbrush", points: 1500, expires: "2024-12-31" },
    ],
    milestones: [
      { name: "First Visit", achieved: true, date: "2021-06-15", points: 100 },
      { name: "5 Regular Checkups", achieved: true, date: "2022-06-22", points: 500 },
      { name: "First Cosmetic Procedure", achieved: true, date: "2022-09-10", points: 300 },
      { name: "3 Referrals", achieved: true, date: "2023-04-22", points: 750 },
      { name: "Loyalty Anniversary (2 Years)", achieved: true, date: "2023-06-15", points: 500 },
      { name: "5 Referrals", achieved: true, date: "2023-07-18", points: 1000 },
      { name: "10 Regular Checkups", achieved: false, progress: 8, target: 10, points: 1000 },
      { name: "Loyalty Anniversary (3 Years)", achieved: false, date: "2024-06-15", points: 750 },
    ],
  },
  "2": {
    id: 2,
    name: "Michael Chen",
    email: "m.chen@example.com",
    phone: "(555) 987-6543",
    avatar: "/placeholder.svg?height=128&width=128",
    lifetimeValue: 3200,
    revenue: {
      total: 3200,
      lastVisit: 280,
      avgPerVisit: 290,
    },
    loyaltyPoints: 2800,
    tier: "gold",
    tierHistory: [
      { tier: "bronze", achievedDate: "2021-08-20" },
      { tier: "silver", achievedDate: "2022-02-15" },
      { tier: "gold", achievedDate: "2022-10-12" },
    ],
    pointsToNextTier: 1200,
    lastVisit: "2023-10-22",
    nextAppointment: "2023-12-15",
    riskLevel: "low",
    referrals: 2,
    procedures: ["Cleaning", "Filling", "Crown"],
    pointsHistory: [
      { date: "2023-10-22", points: 350, description: "Dental cleaning and checkup" },
      { date: "2023-08-15", points: 450, description: "Crown procedure" },
      { date: "2023-06-10", points: 250, description: "Referred Lisa Thompson" },
      { date: "2023-04-05", points: 350, description: "Dental cleaning and checkup" },
      { date: "2023-02-18", points: 300, description: "Filling procedure" },
      { date: "2022-12-10", points: 350, description: "Dental cleaning and checkup" },
      { date: "2022-10-12", points: 250, description: "Referred Robert Garcia" },
      { date: "2022-08-05", points: 350, description: "Dental cleaning and checkup" },
    ],
    rewardsRedeemed: [
      { date: "2023-09-05", reward: "Dental care package", points: 500 },
      { date: "2023-01-20", reward: "Electric toothbrush", points: 800 },
    ],
    availableRewards: [
      { name: "Free dental cleaning", points: 1000, expires: "2024-06-30" },
      { name: "Premium electric toothbrush", points: 1500, expires: "2024-12-31" },
    ],
    milestones: [
      { name: "First Visit", achieved: true, date: "2021-08-20", points: 100 },
      { name: "5 Regular Checkups", achieved: true, date: "2022-12-10", points: 500 },
      { name: "First Cosmetic Procedure", achieved: true, date: "2022-08-15", points: 300 },
      { name: "Loyalty Anniversary (2 Years)", achieved: true, date: "2023-08-20", points: 500 },
      { name: "3 Referrals", achieved: false, progress: 2, target: 3, points: 750 },
      { name: "10 Regular Checkups", achieved: false, progress: 6, target: 10, points: 1000 },
    ],
  },
}

// Loyalty tier thresholds and benefits
const loyaltyTiers = {
  platinum: {
    min: 4000,
    color: "bg-purple-100 text-purple-800",
    darkColor: "bg-purple-600",
    benefits: [
      "Free annual whitening",
      "Priority scheduling",
      "30% off all cosmetic procedures",
      "Complimentary family member cleaning",
    ],
  },
  gold: {
    min: 2500,
    color: "bg-amber-100 text-amber-800",
    darkColor: "bg-amber-500",
    benefits: ["20% off whitening", "Extended appointment times", "15% off cosmetic procedures"],
  },
  silver: {
    min: 1500,
    color: "bg-slate-100 text-slate-800",
    darkColor: "bg-slate-400",
    benefits: ["10% off whitening", "Preferred appointment booking", "Birthday special offers"],
  },
  bronze: {
    min: 0,
    color: "bg-orange-100 text-orange-800",
    darkColor: "bg-orange-400",
    benefits: ["5% off first procedure", "Loyalty program newsletter"],
  },
}

// Points earning opportunities
const pointsOpportunities = [
  { activity: "Regular checkup", points: 350, frequency: "Every 6 months" },
  { activity: "Teeth whitening", points: 500, frequency: "Per procedure" },
  { activity: "Dental implant", points: 1000, frequency: "Per implant" },
  { activity: "Referral", points: 250, frequency: "Per referral" },
  { activity: "Online review", points: 100, frequency: "Once per year" },
  { activity: "Appointment on time", points: 50, frequency: "Per appointment" },
  { activity: "Birthday visit", points: 200, frequency: "Once per year" },
  { activity: "Loyalty anniversary", points: 500, frequency: "Yearly" },
]

export default function PatientLoyaltyDetail() {
  const params = useParams()
  const patientId = params.id as string
  const patient = patientsData[patientId]

  const [activeTab, setActiveTab] = useState("journey")

  if (!patient) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Patient Not Found</h1>
          <p className="text-muted-foreground mb-4">
            The patient you're looking for doesn't exist or has been removed.
          </p>
          <Button asChild>
            <Link href="/patient-loyalty">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Patient Loyalty
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(amount)
  }

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return "Not scheduled"
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", { month: "long", day: "numeric", year: "numeric" }).format(date)
  }

  // Get tier badge color
  const getTierBadgeClass = (tier) => {
    return loyaltyTiers[tier].color
  }

  // Calculate percentage to next tier
  const calculateNextTierProgress = () => {
    if (patient.tier === "platinum") return 100

    const currentTierMin = loyaltyTiers[patient.tier].min
    const nextTier = getNextTier(patient.tier)
    const nextTierMin = loyaltyTiers[nextTier].min

    const pointsRange = nextTierMin - currentTierMin
    const pointsEarned = patient.loyaltyPoints - currentTierMin

    return Math.min(Math.round((pointsEarned / pointsRange) * 100), 99)
  }

  // Get next tier
  const getNextTier = (currentTier) => {
    const tiers = ["bronze", "silver", "gold", "platinum"]
    const currentIndex = tiers.indexOf(currentTier)
    return currentIndex < tiers.length - 1 ? tiers[currentIndex + 1] : currentTier
  }

  // Get tier display name
  const getTierDisplayName = (tier) => {
    return tier.charAt(0).toUpperCase() + tier.slice(1)
  }

  // Calculate points needed for next tier
  const getPointsNeededForNextTier = () => {
    if (patient.tier === "platinum") return 0

    const nextTier = getNextTier(patient.tier)
    return loyaltyTiers[nextTier].min - patient.loyaltyPoints
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Back button and page title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <Button variant="outline" asChild className="mb-4">
            <Link href="/patient-loyalty">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Patient Loyalty
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">Patient Loyalty Details</h1>
          <p className="text-muted-foreground">View and manage loyalty journey for {patient.name}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <MessageSquare className="h-4 w-4 mr-2" />
            Contact
          </Button>
          <Button>
            <Gift className="h-4 w-4 mr-2" />
            Send Reward
          </Button>
        </div>
      </div>

      {/* Patient Profile and Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Patient Profile Card */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <Avatar className="h-24 w-24 mb-4">
                <AvatarImage src={patient.avatar} alt={patient.name} />
                <AvatarFallback>
                  {patient.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <h2 className="text-xl font-bold">{patient.name}</h2>
              <p className="text-muted-foreground mb-2">{patient.email}</p>
              <p className="text-sm text-muted-foreground mb-4">{patient.phone}</p>

              <Badge className={getTierBadgeClass(patient.tier)}>{getTierDisplayName(patient.tier)} Member</Badge>

              <div className="w-full mt-6 space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Loyalty Points</span>
                    <span className="font-medium">{patient.loyaltyPoints.toLocaleString()}</span>
                  </div>
                  <Progress value={calculateNextTierProgress()} className="h-2" />
                  {patient.tier !== "platinum" && (
                    <p className="text-xs text-muted-foreground text-right">
                      {getPointsNeededForNextTier().toLocaleString()} points to{" "}
                      {getTierDisplayName(getNextTier(patient.tier))}
                    </p>
                  )}
                </div>

                <div className="pt-4 border-t border-border">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <p className="text-sm text-muted-foreground">Lifetime Value</p>
                      <p className="font-bold">{formatCurrency(patient.lifetimeValue)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Referrals</p>
                      <p className="font-bold">{patient.referrals}</p>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-border">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <p className="text-sm text-muted-foreground">Last Visit</p>
                      <p className="font-medium">{formatDate(patient.lastVisit)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Next Appointment</p>
                      <p className="font-medium">{formatDate(patient.nextAppointment)}</p>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-border">
                  <h3 className="font-medium mb-2">Member Since</h3>
                  <p>{formatDate(patient.tierHistory[0].achievedDate)}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content Area */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="pb-2">
              <Tabs defaultValue="journey" className="w-full" onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-4 w-full">
                  <TabsTrigger value="journey">Rewards Journey</TabsTrigger>
                  <TabsTrigger value="history">Points History</TabsTrigger>
                  <TabsTrigger value="rewards">Rewards</TabsTrigger>
                  <TabsTrigger value="milestones">Milestones</TabsTrigger>
                </TabsList>
              </Tabs>
            </CardHeader>

            <CardContent className="pt-6">
              <TabsContent value="journey" className="mt-0 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Loyalty Journey Map</h3>

                  {/* Journey Timeline */}
                  <div className="relative">
                    {/* Progress Bar */}
                    <div className="absolute left-[19px] top-7 h-[calc(100%-56px)] w-1 bg-gray-200"></div>

                    {/* Timeline Items */}
                    <div className="space-y-8">
                      {patient.tierHistory.map((tierChange, index) => {
                        const isCurrentTier = index === patient.tierHistory.length - 1
                        return (
                          <div key={index} className="relative flex items-start">
                            <div
                              className={`h-10 w-10 rounded-full flex items-center justify-center z-10 ${loyaltyTiers[tierChange.tier].color}`}
                            >
                              <Award className="h-5 w-5" />
                            </div>
                            <div className="ml-4">
                              <div className="flex items-center">
                                <h4 className="font-semibold">{getTierDisplayName(tierChange.tier)} Tier Achieved</h4>
                                {isCurrentTier && (
                                  <Badge variant="outline" className="ml-2">
                                    Current
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground">{formatDate(tierChange.achievedDate)}</p>
                              <div className="mt-2">
                                <Badge className={getTierBadgeClass(tierChange.tier)}>
                                  {loyaltyTiers[tierChange.tier].min.toLocaleString()}+ points
                                </Badge>
                              </div>
                            </div>
                          </div>
                        )
                      })}

                      {/* Next Tier (if not platinum) */}
                      {patient.tier !== "platinum" && (
                        <div className="relative flex items-start opacity-50">
                          <div className="h-10 w-10 rounded-full flex items-center justify-center border-2 border-dashed border-gray-300 z-10 bg-white">
                            <Award className="h-5 w-5 text-gray-400" />
                          </div>
                          <div className="ml-4">
                            <h4 className="font-semibold">{getTierDisplayName(getNextTier(patient.tier))} Tier</h4>
                            <p className="text-sm text-muted-foreground">Next milestone</p>
                            <div className="mt-2">
                              <Badge variant="outline">
                                {loyaltyTiers[getNextTier(patient.tier)].min.toLocaleString()}+ points needed
                              </Badge>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Current Tier Benefits */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Current Tier Benefits</h3>
                  <div className={`p-4 rounded-lg ${getTierBadgeClass(patient.tier)}`}>
                    <div className="flex items-center mb-3">
                      <Award className="h-5 w-5 mr-2" />
                      <h4 className="font-semibold">{getTierDisplayName(patient.tier)} Member Benefits</h4>
                    </div>
                    <ul className="space-y-2">
                      {loyaltyTiers[patient.tier].benefits.map((benefit, index) => (
                        <li key={index} className="flex items-center">
                          <CheckCircle className="h-4 w-4 mr-2 flex-shrink-0" />
                          <span>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Recommendations */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Recommendations</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-start">
                          <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                            <TrendingUp className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="font-semibold">Earn Points Faster</h4>
                            <p className="text-sm text-muted-foreground mt-1">
                              Schedule your next cleaning to earn 350 points
                            </p>
                            <Button variant="link" className="px-0 h-auto mt-1">
                              Book Appointment <ArrowRight className="h-3 w-3 ml-1" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-start">
                          <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
                            <Share2 className="h-5 w-5 text-green-600" />
                          </div>
                          <div>
                            <h4 className="font-semibold">Refer Friends</h4>
                            <p className="text-sm text-muted-foreground mt-1">Earn 250 points for each referral</p>
                            <Button variant="link" className="px-0 h-auto mt-1">
                              Send Referral <ArrowRight className="h-3 w-3 ml-1" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="history" className="mt-0 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Points History</h3>
                  <div className="rounded-md border overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Activity</TableHead>
                          <TableHead>Points</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {patient.pointsHistory.map((entry, index) => (
                          <TableRow key={index}>
                            <TableCell>{formatDate(entry.date)}</TableCell>
                            <TableCell>{entry.description}</TableCell>
                            <TableCell className="font-medium">+{entry.points}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">Ways to Earn Points</h3>
                  <div className="rounded-md border overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Activity</TableHead>
                          <TableHead>Points</TableHead>
                          <TableHead>Frequency</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pointsOpportunities.map((opportunity, index) => (
                          <TableRow key={index}>
                            <TableCell>{opportunity.activity}</TableCell>
                            <TableCell>{opportunity.points}</TableCell>
                            <TableCell>{opportunity.frequency}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="rewards" className="mt-0 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Available Rewards</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {patient.availableRewards.map((reward, index) => (
                      <Card key={index}>
                        <CardContent className="pt-6">
                          <div className="flex items-start">
                            <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                              <Gift className="h-5 w-5 text-purple-600" />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-semibold">{reward.name}</h4>
                              <div className="flex justify-between items-center mt-1">
                                <Badge variant="outline">{reward.points} points</Badge>
                                <span className="text-xs text-muted-foreground">
                                  Expires: {formatDate(reward.expires)}
                                </span>
                              </div>
                              <Button size="sm" className="mt-3 w-full">
                                Redeem
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">Redeemed Rewards</h3>
                  <div className="rounded-md border overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Reward</TableHead>
                          <TableHead>Points Used</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {patient.rewardsRedeemed.map((reward, index) => (
                          <TableRow key={index}>
                            <TableCell>{formatDate(reward.date)}</TableCell>
                            <TableCell>{reward.reward}</TableCell>
                            <TableCell>{reward.points}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="milestones" className="mt-0 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Milestones</h3>

                  {/* Milestones Timeline */}
                  <div className="relative">
                    {/* Progress Bar */}
                    <div className="absolute left-[19px] top-7 h-[calc(100%-56px)] w-1 bg-gray-200"></div>

                    {/* Timeline Items */}
                    <div className="space-y-8">
                      {patient.milestones.map((milestone, index) => (
                        <div key={index} className="relative flex items-start">
                          <div
                            className={`h-10 w-10 rounded-full flex items-center justify-center z-10 ${milestone.achieved ? "bg-green-100" : "bg-gray-100"}`}
                          >
                            {milestone.achieved ? (
                              <CheckCircle className="h-5 w-5 text-green-600" />
                            ) : (
                              <Circle className="h-5 w-5 text-gray-400" />
                            )}
                          </div>
                          <div className="ml-4">
                            <div className="flex items-center">
                              <h4 className="font-semibold">{milestone.name}</h4>
                              {milestone.achieved ? (
                                <Badge variant="outline" className="ml-2 bg-green-100 text-green-800 border-green-200">
                                  Achieved
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="ml-2">
                                  Upcoming
                                </Badge>
                              )}
                            </div>
                            {milestone.achieved ? (
                              <p className="text-sm text-muted-foreground">Completed on {formatDate(milestone.date)}</p>
                            ) : milestone.progress ? (
                              <div className="mt-2 space-y-1">
                                <div className="flex justify-between text-xs">
                                  <span>
                                    {milestone.progress} of {milestone.target} completed
                                  </span>
                                  <span>{Math.round((milestone.progress / milestone.target) * 100)}%</span>
                                </div>
                                <Progress value={(milestone.progress / milestone.target) * 100} className="h-1" />
                              </div>
                            ) : (
                              <p className="text-sm text-muted-foreground">Expected {formatDate(milestone.date)}</p>
                            )}
                            <div className="mt-2">
                              <Badge variant="secondary">{milestone.points} points</Badge>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">Next Milestone Recommendations</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-start">
                          <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                            <Calendar className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="font-semibold">Complete 10 Regular Checkups</h4>
                            <p className="text-sm text-muted-foreground mt-1">2 more visits needed</p>
                            <div className="mt-2 space-y-1">
                              <div className="flex justify-between text-xs">
                                <span>8 of 10 completed</span>
                                <span>80%</span>
                              </div>
                              <Progress value={80} className="h-1" />
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-start">
                          <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                            <Users className="h-5 w-5 text-purple-600" />
                          </div>
                          <div>
                            <h4 className="font-semibold">Loyalty Anniversary (3 Years)</h4>
                            <p className="text-sm text-muted-foreground mt-1">
                              Coming up on {formatDate("2024-06-15")}
                            </p>
                            <Button variant="link" className="px-0 h-auto mt-1">
                              View Details <ChevronRight className="h-3 w-3 ml-1" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Additional Information */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tier Progression */}
        <Card>
          <CardHeader>
            <CardTitle>Tier Progression</CardTitle>
            <CardDescription>Patient's journey through loyalty tiers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="relative pt-6">
                {/* Tier Progress Bar */}
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-orange-400 via-slate-400 via-amber-500 to-purple-600 rounded-full"
                    style={{ width: "100%" }}
                  ></div>
                </div>

                {/* Tier Markers */}
                <div className="flex justify-between mt-2">
                  {Object.entries(loyaltyTiers).map(([tier, data], index) => {
                    const isActive = patient.tierHistory.some((t) => t.tier === tier)
                    const isCurrent = patient.tier === tier

                    return (
                      <TooltipProvider key={tier}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="flex flex-col items-center">
                              <div
                                className={`h-6 w-6 rounded-full flex items-center justify-center ${isActive ? loyaltyTiers[tier].darkColor : "bg-gray-200"} ${isCurrent ? "ring-2 ring-offset-2 ring-blue-500" : ""}`}
                              >
                                {isActive && <CheckCircle className="h-3 w-3 text-white" />}
                              </div>
                              <span className="text-xs mt-1">{data.min}</span>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{getTierDisplayName(tier)} Tier</p>
                            {isActive && (
                              <p className="text-xs">
                                Achieved on {formatDate(patient.tierHistory.find((t) => t.tier === tier)?.achievedDate)}
                              </p>
                            )}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    )
                  })}
                </div>
              </div>

              {/* Current Points */}
              <div className="pt-4 text-center">
                <div className="text-sm text-muted-foreground">Current Points</div>
                <div className="text-3xl font-bold">{patient.loyaltyPoints.toLocaleString()}</div>
                {patient.tier !== "platinum" && (
                  <div className="text-sm text-muted-foreground mt-1">
                    {getPointsNeededForNextTier().toLocaleString()} points to{" "}
                    {getTierDisplayName(getNextTier(patient.tier))}
                  </div>
                )}
              </div>

              {/* Points Breakdown */}
              <div className="pt-4 border-t border-border">
                <h4 className="font-medium mb-3">Points Breakdown</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>From procedures</span>
                    <span>{(patient.loyaltyPoints - patient.referrals * 250).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>From referrals</span>
                    <span>{(patient.referrals * 250).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Personalized Recommendations */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Personalized Recommendations</CardTitle>
            <CardDescription>Suggestions to enhance patient loyalty</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start p-4 bg-blue-50 rounded-lg">
                <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                  <Zap className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-semibold">Loyalty Booster</h4>
                  <p className="text-sm mt-1">
                    Sarah is close to her 3-year loyalty anniversary. Consider sending a personalized thank you card and
                    a special offer to celebrate this milestone.
                  </p>
                  <div className="flex items-center mt-2">
                    <Info className="h-4 w-4 text-muted-foreground mr-1" />
                    <span className="text-xs text-muted-foreground">
                      Milestone coming up on {formatDate("2024-06-15")}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-start p-4 bg-green-50 rounded-lg">
                <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
                  <DollarSign className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h4 className="font-semibold">Revenue Opportunity</h4>
                  <p className="text-sm mt-1">
                    Sarah has shown interest in cosmetic procedures. With her Platinum status, she qualifies for 30%
                    off. Consider reaching out about teeth whitening or veneers.
                  </p>
                  <Button size="sm" variant="outline" className="mt-2">
                    Send Offer
                  </Button>
                </div>
              </div>

              <div className="flex items-start p-4 bg-purple-50 rounded-lg">
                <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                  <Users className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h4 className="font-semibold">Referral Champion</h4>
                  <p className="text-sm mt-1">
                    Sarah has referred 5 patients already, making her one of your top referrers. Consider featuring her
                    in your referral program or offering a special bonus for her next referral.
                  </p>
                  <Button size="sm" variant="outline" className="mt-2">
                    Send Referral Bonus
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t bg-muted/50 px-6">
            <Button className="w-full">
              <MessageSquare className="h-4 w-4 mr-2" />
              Send Personalized Message
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

