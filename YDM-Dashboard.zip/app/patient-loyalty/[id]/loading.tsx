import { CardFooter } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardContent, CardHeader } from "@/components/ui/card"

export default function PatientLoyaltyDetailLoading() {
  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Back button and page title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <Skeleton className="h-9 w-40 mb-4" />
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-5 w-80" />
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-9 w-28" />
          <Skeleton className="h-9 w-28" />
        </div>
      </div>

      {/* Patient Profile and Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Patient Profile Card */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <Skeleton className="h-24 w-24 rounded-full mb-4" />
              <Skeleton className="h-6 w-40 mb-2" />
              <Skeleton className="h-4 w-48 mb-2" />
              <Skeleton className="h-4 w-32 mb-4" />

              <Skeleton className="h-6 w-32" />

              <div className="w-full mt-6 space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                  <Skeleton className="h-2 w-full" />
                  <div className="flex justify-end">
                    <Skeleton className="h-3 w-32" />
                  </div>
                </div>

                <div className="pt-4 border-t border-border">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <Skeleton className="h-4 w-24 mx-auto mb-2" />
                      <Skeleton className="h-5 w-16 mx-auto" />
                    </div>
                    <div>
                      <Skeleton className="h-4 w-24 mx-auto mb-2" />
                      <Skeleton className="h-5 w-8 mx-auto" />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-border">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <Skeleton className="h-4 w-24 mx-auto mb-2" />
                      <Skeleton className="h-5 w-20 mx-auto" />
                    </div>
                    <div>
                      <Skeleton className="h-4 w-24 mx-auto mb-2" />
                      <Skeleton className="h-5 w-20 mx-auto" />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-border">
                  <Skeleton className="h-5 w-32 mb-2" />
                  <Skeleton className="h-5 w-40" />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content Area */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="pb-2">
              <Skeleton className="h-10 w-full" />
            </CardHeader>

            <CardContent className="pt-6">
              <div className="space-y-6">
                <div>
                  <Skeleton className="h-6 w-48 mb-4" />

                  {/* Journey Timeline Skeleton */}
                  <div className="space-y-8">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="flex items-start">
                        <Skeleton className="h-10 w-10 rounded-full" />
                        <div className="ml-4 space-y-2 flex-1">
                          <Skeleton className="h-5 w-48" />
                          <Skeleton className="h-4 w-32" />
                          <Skeleton className="h-6 w-24" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Skeleton className="h-6 w-48 mb-4" />
                  <Skeleton className="h-32 w-full rounded-lg" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Additional Information */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-40 mb-2" />
            <Skeleton className="h-4 w-56" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Skeleton className="h-2 w-full mb-2" />
              <div className="flex justify-between">
                {[1, 2, 3, 4].map((i) => (
                  <Skeleton key={i} className="h-6 w-6 rounded-full" />
                ))}
              </div>

              <div className="pt-4 text-center">
                <Skeleton className="h-4 w-32 mx-auto mb-2" />
                <Skeleton className="h-8 w-24 mx-auto mb-1" />
                <Skeleton className="h-4 w-48 mx-auto" />
              </div>

              <div className="pt-4 border-t border-border">
                <Skeleton className="h-5 w-40 mb-3" />
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <Skeleton className="h-6 w-64 mb-2" />
            <Skeleton className="h-4 w-80" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-32 w-full rounded-lg" />
              ))}
            </div>
          </CardContent>
          <CardFooter className="border-t bg-muted/50 px-6">
            <Skeleton className="h-9 w-full" />
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

