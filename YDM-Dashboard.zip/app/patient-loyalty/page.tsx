"use client"

import { useState } from "react"
import {
  Search,
  Filter,
  Gift,
  Award,
  Users,
  DollarSign,
  Calendar,
  ArrowUp,
  ArrowDown,
  Star,
  AlertCircle,
  UserPlus,
  ChevronRight,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import Link from "next/link"

// Sample patient data
const patients = [
  {
    id: 1,
    name: "Sarah Johnson",
    email: "sarah.j@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    lifetimeValue: 4850,
    revenue: 1250,
    loyaltyPoints: 4200,
    tier: "platinum",
    lastVisit: "2023-11-15",
    nextAppointment: "2023-12-20",
    riskLevel: "low",
    referrals: 5,
    pointsToNextTier: 0,
    procedures: ["Cleaning", "Whitening", "Implant"],
  },
  {
    id: 2,
    name: "Michael Chen",
    email: "m.chen@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    lifetimeValue: 3200,
    revenue: 950,
    loyaltyPoints: 2800,
    tier: "gold",
    lastVisit: "2023-10-22",
    nextAppointment: "2023-12-15",
    riskLevel: "low",
    referrals: 2,
    pointsToNextTier: 1200,
    procedures: ["Cleaning", "Filling", "Crown"],
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    email: "e.rodriguez@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    lifetimeValue: 2100,
    revenue: 650,
    loyaltyPoints: 1850,
    tier: "silver",
    lastVisit: "2023-09-05",
    nextAppointment: "2023-12-10",
    riskLevel: "medium",
    referrals: 1,
    pointsToNextTier: 650,
    procedures: ["Cleaning", "X-Ray"],
  },
  {
    id: 4,
    name: "David Williams",
    email: "d.williams@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    lifetimeValue: 1500,
    revenue: 450,
    loyaltyPoints: 1200,
    tier: "bronze",
    lastVisit: "2023-07-18",
    nextAppointment: null,
    riskLevel: "high",
    referrals: 0,
    pointsToNextTier: 800,
    procedures: ["Cleaning", "Consultation"],
  },
  {
    id: 5,
    name: "Jennifer Lee",
    email: "j.lee@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    lifetimeValue: 3800,
    revenue: 1100,
    loyaltyPoints: 3100,
    tier: "gold",
    lastVisit: "2023-11-02",
    nextAppointment: "2023-12-28",
    riskLevel: "low",
    referrals: 3,
    pointsToNextTier: 900,
    procedures: ["Cleaning", "Root Canal", "Crown"],
  },
  {
    id: 6,
    name: "Robert Garcia",
    email: "r.garcia@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    lifetimeValue: 2700,
    revenue: 800,
    loyaltyPoints: 2300,
    tier: "silver",
    lastVisit: "2023-10-10",
    nextAppointment: "2024-01-05",
    riskLevel: "low",
    referrals: 1,
    pointsToNextTier: 200,
    procedures: ["Cleaning", "Filling"],
  },
  {
    id: 7,
    name: "Amanda Thompson",
    email: "a.thompson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    lifetimeValue: 950,
    revenue: 350,
    loyaltyPoints: 750,
    tier: "bronze",
    lastVisit: "2023-08-20",
    nextAppointment: null,
    riskLevel: "high",
    referrals: 0,
    pointsToNextTier: 1250,
    procedures: ["Consultation", "X-Ray"],
  },
  {
    id: 8,
    name: "Thomas Wilson",
    email: "t.wilson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    lifetimeValue: 5200,
    revenue: 1500,
    loyaltyPoints: 4500,
    tier: "platinum",
    lastVisit: "2023-11-25",
    nextAppointment: "2023-12-22",
    riskLevel: "low",
    referrals: 6,
    pointsToNextTier: 0,
    procedures: ["Cleaning", "Whitening", "Veneers", "Implant"],
  },
]

// Loyalty tier thresholds and benefits
const loyaltyTiers = {
  platinum: {
    min: 4000,
    color: "bg-purple-100 text-purple-800",
    benefits: [
      "Free annual whitening",
      "Priority scheduling",
      "30% off all cosmetic procedures",
      "Complimentary family member cleaning",
    ],
  },
  gold: {
    min: 2500,
    color: "bg-amber-100 text-amber-800",
    benefits: ["20% off whitening", "Extended appointment times", "15% off cosmetic procedures"],
  },
  silver: {
    min: 1500,
    color: "bg-slate-100 text-slate-800",
    benefits: ["10% off whitening", "Preferred appointment booking", "Birthday special offers"],
  },
  bronze: {
    min: 0,
    color: "bg-orange-100 text-orange-800",
    benefits: ["5% off first procedure", "Loyalty program newsletter"],
  },
}

// Summary statistics
const summaryStats = {
  totalPatients: patients.length,
  totalLoyaltyPoints: patients.reduce((sum, patient) => sum + patient.loyaltyPoints, 0),
  averageLifetimeValue: Math.round(patients.reduce((sum, patient) => sum + patient.lifetimeValue, 0) / patients.length),
  tierDistribution: {
    platinum: patients.filter((p) => p.tier === "platinum").length,
    gold: patients.filter((p) => p.tier === "gold").length,
    silver: patients.filter((p) => p.tier === "silver").length,
    bronze: patients.filter((p) => p.tier === "bronze").length,
  },
}

export default function PatientLoyalty() {
  const [searchTerm, setSearchTerm] = useState("")
  const [sortConfig, setSortConfig] = useState({ key: "lifetimeValue", direction: "desc" })

  // Filter patients based on search term and active tab
  const filteredPatients = patients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Sort patients based on current sort configuration
  const sortedPatients = [...filteredPatients].sort((a, b) => {
    if (a[sortConfig.key] < b[sortConfig.key]) {
      return sortConfig.direction === "asc" ? -1 : 1
    }
    if (a[sortConfig.key] > b[sortConfig.key]) {
      return sortConfig.direction === "asc" ? 1 : -1
    }
    return 0
  })

  // Handle sorting when a column header is clicked
  const requestSort = (key) => {
    let direction = "asc"
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc"
    }
    setSortConfig({ key, direction })
  }

  // Get the appropriate sort indicator
  const getSortIndicator = (key) => {
    if (sortConfig.key !== key) return null
    return sortConfig.direction === "asc" ? (
      <ArrowUp className="h-4 w-4 ml-1" />
    ) : (
      <ArrowDown className="h-4 w-4 ml-1" />
    )
  }

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(amount)
  }

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return "Not scheduled"
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" }).format(date)
  }

  // Get tier badge color
  const getTierBadgeClass = (tier) => {
    return loyaltyTiers[tier].color
  }

  // Get risk level badge color
  const getRiskBadgeClass = (risk) => {
    switch (risk) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-amber-100 text-amber-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-slate-100 text-slate-800"
    }
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Patient Loyalty Program</h1>
          <p className="text-muted-foreground">
            Manage patient loyalty, track lifetime value, and reward your most valuable patients
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button>
            <Gift className="h-4 w-4 mr-2" />
            Manage Rewards
          </Button>
        </div>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Loyalty Points</p>
                <h3 className="text-2xl font-bold">{summaryStats.totalLoyaltyPoints.toLocaleString()}</h3>
              </div>
              <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                <Gift className="h-5 w-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg. Lifetime Value</p>
                <h3 className="text-2xl font-bold">{formatCurrency(summaryStats.averageLifetimeValue)}</h3>
              </div>
              <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                <DollarSign className="h-5 w-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Members</p>
                <h3 className="text-2xl font-bold">{summaryStats.totalPatients}</h3>
              </div>
              <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                <Users className="h-5 w-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Tier Distribution</p>
                <div className="flex items-center gap-1 mt-1">
                  <div
                    className="h-3 bg-purple-500 rounded-sm"
                    style={{ width: `${(summaryStats.tierDistribution.platinum / summaryStats.totalPatients) * 100}%` }}
                  ></div>
                  <div
                    className="h-3 bg-amber-500 rounded-sm"
                    style={{ width: `${(summaryStats.tierDistribution.gold / summaryStats.totalPatients) * 100}%` }}
                  ></div>
                  <div
                    className="h-3 bg-slate-500 rounded-sm"
                    style={{ width: `${(summaryStats.tierDistribution.silver / summaryStats.totalPatients) * 100}%` }}
                  ></div>
                  <div
                    className="h-3 bg-orange-500 rounded-sm"
                    style={{ width: `${(summaryStats.tierDistribution.bronze / summaryStats.totalPatients) * 100}%` }}
                  ></div>
                </div>
              </div>
              <div className="h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center">
                <Award className="h-5 w-5 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Patient List */}
        <div className="lg:col-span-2">
          <Card className="overflow-hidden">
            <CardHeader className="pb-0">
              <CardTitle>Patient Loyalty</CardTitle>
              <CardDescription>View and manage your patients' loyalty status and rewards</CardDescription>
            </CardHeader>

            <Tabs defaultValue="all" className="w-full">
              <div className="px-6 pt-2">
                <TabsList className="grid grid-cols-5 w-full">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="platinum">Platinum</TabsTrigger>
                  <TabsTrigger value="gold">Gold</TabsTrigger>
                  <TabsTrigger value="silver">Silver</TabsTrigger>
                  <TabsTrigger value="bronze">Bronze</TabsTrigger>
                </TabsList>
              </div>

              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Search className="h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search patients..."
                    className="flex-1"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                <TabsContent value="all" className="m-0">
                  <div className="rounded-md border overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Patient</TableHead>
                          <TableHead className="cursor-pointer" onClick={() => requestSort("lifetimeValue")}>
                            <div className="flex items-center">
                              Lifetime Value
                              {getSortIndicator("lifetimeValue")}
                            </div>
                          </TableHead>
                          <TableHead className="cursor-pointer" onClick={() => requestSort("loyaltyPoints")}>
                            <div className="flex items-center">
                              Loyalty Points
                              {getSortIndicator("loyaltyPoints")}
                            </div>
                          </TableHead>
                          <TableHead>Tier</TableHead>
                          <TableHead>Last Visit</TableHead>
                          <TableHead></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {sortedPatients.map((patient) => (
                          <TableRow key={patient.id}>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                <Avatar>
                                  <AvatarImage src={patient.avatar} alt={patient.name} />
                                  <AvatarFallback>
                                    {patient.name
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("")}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <div className="font-medium">
                                    {patient.id === 8 ? (
                                      <Link
                                        href={`/patient-loyalty/${patient.id}`}
                                        className="hover:underline text-blue-600"
                                      >
                                        {patient.name}
                                      </Link>
                                    ) : (
                                      patient.name
                                    )}
                                  </div>
                                  <div className="text-sm text-muted-foreground">{patient.email}</div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="font-medium">{formatCurrency(patient.lifetimeValue)}</div>
                              <div className="text-sm text-muted-foreground">
                                Revenue: {formatCurrency(patient.revenue)}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="text-sm font-medium">{patient.loyaltyPoints.toLocaleString()}</span>
                                  {patient.pointsToNextTier > 0 && (
                                    <span className="text-xs text-muted-foreground">
                                      {patient.pointsToNextTier} to next tier
                                    </span>
                                  )}
                                </div>
                                <Progress
                                  value={(patient.loyaltyPoints / (loyaltyTiers[patient.tier].min + 2000)) * 100}
                                  className="h-2"
                                />
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={getTierBadgeClass(patient.tier)}>
                                {patient.tier.charAt(0).toUpperCase() + patient.tier.slice(1)}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="font-medium">{formatDate(patient.lastVisit)}</div>
                              {patient.nextAppointment && (
                                <div className="text-sm text-muted-foreground flex items-center">
                                  <Calendar className="h-3 w-3 mr-1" />
                                  Next: {formatDate(patient.nextAppointment)}
                                </div>
                              )}
                            </TableCell>
                            <TableCell>
                              <Button variant="ghost" size="sm">
                                <Gift className="h-4 w-4 mr-1" />
                                Reward
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                {/* Other tabs would filter by tier */}
                <TabsContent value="platinum" className="m-0">
                  {/* Similar table but filtered for platinum tier */}
                </TabsContent>
                <TabsContent value="gold" className="m-0">
                  {/* Similar table but filtered for gold tier */}
                </TabsContent>
                <TabsContent value="silver" className="m-0">
                  {/* Similar table but filtered for silver tier */}
                </TabsContent>
                <TabsContent value="bronze" className="m-0">
                  {/* Similar table but filtered for bronze tier */}
                </TabsContent>
              </CardContent>
            </Tabs>

            <CardFooter className="border-t bg-muted/50 px-6 py-3">
              <div className="flex justify-between items-center w-full">
                <div className="text-sm text-muted-foreground">
                  Showing {sortedPatients.length} of {patients.length} patients
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm">
                    Previous
                  </Button>
                  <Button variant="outline" size="sm">
                    Next
                  </Button>
                </div>
              </div>
            </CardFooter>
          </Card>
        </div>

        {/* Loyalty Program Details */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Loyalty Program Tiers</CardTitle>
              <CardDescription>Benefits and requirements for each loyalty tier</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center mt-1">
                    <Award className="h-4 w-4 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Platinum Tier</h4>
                    <p className="text-sm text-muted-foreground mb-1">4,000+ points</p>
                    <ul className="text-sm space-y-1">
                      {loyaltyTiers.platinum.benefits.map((benefit, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <div className="h-1.5 w-1.5 rounded-full bg-purple-500"></div>
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center mt-1">
                    <Award className="h-4 w-4 text-amber-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Gold Tier</h4>
                    <p className="text-sm text-muted-foreground mb-1">2,500+ points</p>
                    <ul className="text-sm space-y-1">
                      {loyaltyTiers.gold.benefits.map((benefit, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <div className="h-1.5 w-1.5 rounded-full bg-amber-500"></div>
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-slate-100 flex items-center justify-center mt-1">
                    <Award className="h-4 w-4 text-slate-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Silver Tier</h4>
                    <p className="text-sm text-muted-foreground mb-1">1,500+ points</p>
                    <ul className="text-sm space-y-1">
                      {loyaltyTiers.silver.benefits.map((benefit, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <div className="h-1.5 w-1.5 rounded-full bg-slate-500"></div>
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-orange-100 flex items-center justify-center mt-1">
                    <Award className="h-4 w-4 text-orange-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Bronze Tier</h4>
                    <p className="text-sm text-muted-foreground mb-1">0+ points</p>
                    <ul className="text-sm space-y-1">
                      {loyaltyTiers.bronze.benefits.map((benefit, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <div className="h-1.5 w-1.5 rounded-full bg-orange-500"></div>
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Loyalty Insights</CardTitle>
              <CardDescription>Actionable insights to improve patient loyalty</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center mt-1">
                    <ArrowUp className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Upgrade Opportunities</h4>
                    <p className="text-sm text-muted-foreground">3 patients close to next tier</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-red-100 flex items-center justify-center mt-1">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Retention Risks</h4>
                    <p className="text-sm text-muted-foreground">2 high-value patients at risk</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mt-1">
                    <UserPlus className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Referral Potential</h4>
                    <p className="text-sm text-muted-foreground">5 patients with high referral potential</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center mt-1">
                    <Star className="h-4 w-4 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Tier Distribution</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex flex-col items-center">
                        <span className="text-xs font-medium">
                          {Math.round((summaryStats.tierDistribution.platinum / summaryStats.totalPatients) * 100)}%
                        </span>
                        <div className="h-16 w-6 bg-purple-100 rounded-sm relative">
                          <div
                            className="absolute bottom-0 w-full bg-purple-500 rounded-sm"
                            style={{
                              height: `${(summaryStats.tierDistribution.platinum / summaryStats.totalPatients) * 100}%`,
                            }}
                          ></div>
                        </div>
                        <span className="text-xs">Plat</span>
                      </div>
                      <div className="flex flex-col items-center">
                        <span className="text-xs font-medium">
                          {Math.round((summaryStats.tierDistribution.gold / summaryStats.totalPatients) * 100)}%
                        </span>
                        <div className="h-16 w-6 bg-amber-100 rounded-sm relative">
                          <div
                            className="absolute bottom-0 w-full bg-amber-500 rounded-sm"
                            style={{
                              height: `${(summaryStats.tierDistribution.gold / summaryStats.totalPatients) * 100}%`,
                            }}
                          ></div>
                        </div>
                        <span className="text-xs">Gold</span>
                      </div>
                      <div className="flex flex-col items-center">
                        <span className="text-xs font-medium">
                          {Math.round((summaryStats.tierDistribution.silver / summaryStats.totalPatients) * 100)}%
                        </span>
                        <div className="h-16 w-6 bg-slate-100 rounded-sm relative">
                          <div
                            className="absolute bottom-0 w-full bg-slate-500 rounded-sm"
                            style={{
                              height: `${(summaryStats.tierDistribution.silver / summaryStats.totalPatients) * 100}%`,
                            }}
                          ></div>
                        </div>
                        <span className="text-xs">Silver</span>
                      </div>
                      <div className="flex flex-col items-center">
                        <span className="text-xs font-medium">
                          {Math.round((summaryStats.tierDistribution.bronze / summaryStats.totalPatients) * 100)}%
                        </span>
                        <div className="h-16 w-6 bg-orange-100 rounded-sm relative">
                          <div
                            className="absolute bottom-0 w-full bg-orange-500 rounded-sm"
                            style={{
                              height: `${(summaryStats.tierDistribution.bronze / summaryStats.totalPatients) * 100}%`,
                            }}
                          ></div>
                        </div>
                        <span className="text-xs">Bronze</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">
                <ChevronRight className="h-4 w-4 mr-2" />
                View Detailed Analytics
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

