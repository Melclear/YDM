"use client"

import { useState, useEffect } from "react"
import { Search, Mail, Bell, ChevronLeft, BarChart2, Calendar, Users, BarChart, FileText, PieChart } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useInView } from "../hooks/use-in-view"
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts"
import { SeasonalMarketingTips } from "@/components/seasonal-marketing-tips"
import { usePathname } from "next/navigation"
import { HealthTrendAnalyzer } from "@/components/health-trend-analyzer"
import { MobileHealthTrend } from "@/components/mobile-health-trend"
import { SectionSummaryCard } from "@/components/section-summary-card"

export default function Dashboard() {
  const [isTimerRunning, setIsTimerRunning] = useState(false)
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [profileMenuOpen, setProfileMenuOpen] = useState(false)
  const [remindersOpen, setRemindersOpen] = useState(false)
  const analyticsChartRef = useInView()
  const marketingChartRef = useInView()
  const sankeyChartRef = useInView()
  const pathname = usePathname()

  const [seoData, setSeoData] = useState([
    { month: "Jan", Organic: 4000 },
    { month: "Feb", Organic: 3000 },
    { month: "Mar", Organic: 2000 },
    { month: "Apr", Organic: 2780 },
    { month: "May", Organic: 1890 },
    { month: "Jun", Organic: 2390 },
    { month: "Jul", Organic: 3490 },
  ])

  const [ppcData, setPpcData] = useState([
    { month: "Jan", PPC: 2400 },
    { month: "Feb", PPC: 1398 },
    { month: "Mar", PPC: 9800 },
    { month: "Apr", PPC: 3908 },
    { month: "May", PPC: 4800 },
    { month: "Jun", PPC: 3800 },
    { month: "Jul", PPC: 4300 },
  ])

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed)
  }

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileMenuOpen && !event.target.closest(".profile-dropdown")) {
        setProfileMenuOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [profileMenuOpen])

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <div
        className={`${isSidebarCollapsed ? "w-20" : "w-56"} bg-white border-r border-gray-200 p-6 flex flex-col transition-all duration-300 ease-in-out`}
      >
        {/* Sidebar Logo */}
        <div className="flex items-center justify-center mb-10">
          {!isSidebarCollapsed ? (
            <div className="flex items-center w-full">
              <div className="flex-1">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Frame%203-r6JD4ntf4G66J4BjdY49D53jAjg40f.png"
                  alt="YDM Logo"
                  width={132}
                  height={42}
                  className="h-11 w-auto"
                />
              </div>
              <button onClick={toggleSidebar} className="text-gray-500 hover:text-[#007CD3] transition-colors">
                <ChevronLeft size={20} />
              </button>
            </div>
          ) : (
            <button
              onClick={toggleSidebar}
              className="flex items-center justify-center hover:opacity-80 transition-opacity"
            >
              <Image src="/images/ydm-icon.png" alt="YDM Icon" width={32} height={32} className="w-8 h-auto" />
            </button>
          )}
        </div>

        <nav className="space-y-2 mb-8">
          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} bg-blue-50 text-[#007CD3] rounded-md border-l-4 border-[#007CD3]`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-layout-grid"
            >
              <rect width="7" height="7" x="3" y="3" rx="1" />
              <rect width="7" height="7" x="14" y="3" rx="1" />
              <rect width="7" height="7" x="14" y="14" rx="1" />
              <rect width="7" height="7" x="3" y="14" rx="1" />
            </svg>
            {!isSidebarCollapsed && <span className="font-medium">Dashboard</span>}
          </div>

          <Link
            href="/tasks"
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-check-circle"
              stroke="currentColor"
            >
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
            {!isSidebarCollapsed && (
              <>
                <span>Tasks</span>
                <span className="ml-auto bg-[#007CD3] text-white text-xs px-1.5 py-0.5 rounded">09</span>
              </>
            )}
            {isSidebarCollapsed && (
              <span className="absolute right-1 top-1 bg-[#007CD3] text-white text-xs px-1.5 py-0.5 rounded">09</span>
            )}
          </Link>

          <div className="relative group">
            <Link
              href="/marketing"
              className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-calendar"
                stroke="currentColor"
              >
                <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
                <line x1="16" x2="16" y1="2" y2="6" />
                <line x1="8" x2="8" y1="2" y2="6" />
                <line x1="3" x2="21" y1="10" y2="10" />
              </svg>
              {!isSidebarCollapsed && (
                <>
                  <span>Marketing</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-auto"
                    stroke="currentColor"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </>
              )}
            </Link>

            {/* Submenu */}
            {!isSidebarCollapsed && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  href="/marketing"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Overview</span>
                </Link>
                <Link
                  href="/campaigns"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Campaign Manager</span>
                </Link>
                <Link
                  href="/promotions"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Promotions Manager</span>
                </Link>
                <Link
                  href="/competitor-benchmarking"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Competitor Benchmarking</span>
                </Link>
              </div>
            )}
          </div>

          <div className="relative group">
            <Link
              href="/analytics"
              className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                stroke="currentColor"
              >
                <line x1="12" x2="12" y1="20" y2="10" />
                <line x1="18" x2="18" y1="20" y2="4" />
                <line x1="6" x2="6" y1="20" y2="16" />
              </svg>
              {!isSidebarCollapsed && (
                <>
                  <span>Analytics</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-auto"
                    stroke="currentColor"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </>
              )}
            </Link>

            {/* Submenu */}
            {!isSidebarCollapsed && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  href="/analytics"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Overview</span>
                </Link>
                <Link
                  href="/seo-ppc-analytics"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>SEO & PPC Analytics</span>
                </Link>
              </div>
            )}
          </div>

          <div className="relative group">
            <Link
              href="/patient"
              className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-users"
                stroke="currentColor"
              >
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
              {!isSidebarCollapsed && (
                <>
                  <span>Patient</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-auto"
                    stroke="currentColor"
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </>
              )}
            </Link>

            {/* Submenu */}
            {!isSidebarCollapsed && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  href="/patient"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Overview</span>
                </Link>
                <Link
                  href="/reputation-management"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Reputation Management</span>
                </Link>
                <Link
                  href="/patient-loyalty"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Patient Loyalty</span>
                </Link>
                <Link
                  href="/practice-management"
                  className="flex items-center gap-2 py-1.5 px-3 text-sm text-gray-600 hover:bg-gray-50 rounded-md"
                >
                  <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                  <span>Practice Management</span>
                </Link>
              </div>
            )}
          </div>
        </nav>

        <div className="mt-2 border-t border-gray-100 pt-4"></div>

        <nav className="space-y-2 mb-auto">
          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-settings"
              stroke="currentColor"
            >
              <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
            {!isSidebarCollapsed && <span>Settings</span>}
          </div>

          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-help-circle"
              stroke="currentColor"
            >
              <circle cx="12" cy="12" r="10" />
              <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
              <path d="M12 17h.01" />
            </svg>
            {!isSidebarCollapsed && <span>Help</span>}
          </div>

          <div
            className={`flex items-center gap-3 py-2 ${isSidebarCollapsed ? "px-2 justify-center" : "px-3"} text-gray-600 hover:bg-gray-50 rounded-md`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-log-out"
              stroke="currentColor"
            >
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" />
              <line x1="21" x2="9" y1="12" y2="12" />
            </svg>
            {!isSidebarCollapsed && <span>Logout</span>}
          </div>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-6">
        {/* Header */}
        <header className="flex items-center justify-between mb-8">
          <div className="relative w-96">
            <input
              type="text"
              placeholder="Search"
              className="w-full pl-10 pr-4 py-2 bg-white rounded-md border border-gray-200"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 bg-gray-200 text-gray-600 text-xs px-1.5 py-0.5 rounded">
              ⌘ F
            </div>
          </div>

          <div className="flex items-center gap-6">
            <button className="text-gray-500">
              <Mail size={20} />
            </button>
            <button className="text-gray-500">
              <Bell size={20} />
            </button>
            <div className="flex items-center relative profile-dropdown">
              <button
                onClick={() => setProfileMenuOpen(!profileMenuOpen)}
                className="h-10 w-10 rounded-full overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <Image src="/images/mcleary.png" alt="Profile" width={40} height={40} className="object-cover" />
              </button>

              {/* Profile Dropdown Menu */}
              {profileMenuOpen && (
                <div className="absolute right-0 top-12 w-56 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200">
                  <div className="px-4 py-3 border-b border-gray-100">
                    <p className="text-sm font-medium">Hi, Melissa</p>
                    <p className="text-xs text-gray-500 truncate">melissa@yourdentalrecruiter.com</p>
                  </div>

                  <div className="py-1">
                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                        stroke="currentColor"
                      >
                        <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                        <circle cx="12" cy="12" r="3" />
                      </svg>
                      Settings
                    </button>

                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                        stroke="currentColor"
                      >
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <path d="M12 17h.01" />
                      </svg>
                      Help
                    </button>
                  </div>

                  <div className="py-1 border-t border-gray-100">
                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mr-3"
                        stroke="currentColor"
                      >
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                        <polyline points="16 17 21 12 16 7" />
                        <line x1="21" x2="9" y1="12" y2="12" />
                      </svg>
                      Logout
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Dashboard Title */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-1 text-black">Dashboard</h1>
          <p className="text-gray-500">Welcome to your dental practice management dashboard</p>
        </div>

        {/* Mobile Health Trend */}
        <MobileHealthTrend />

        {/* Health Trend Analyzer - Desktop */}
        <div className="hidden md:block">
          <HealthTrendAnalyzer />
        </div>

        {/* Section Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* Marketing Summary Card */}
          <SectionSummaryCard
            title="Marketing"
            description="Campaign and promotion performance"
            metrics={[
              {
                label: "Active Campaigns",
                value: "4",
                change: { value: 25, isPositive: true },
              },
              {
                label: "Conversion Rate",
                value: "3.8%",
                change: { value: 0.5, isPositive: true },
              },
              {
                label: "New Leads",
                value: "127",
                change: { value: 12, isPositive: true },
              },
              {
                label: "ROI",
                value: "215%",
                change: { value: 5, isPositive: true },
              },
            ]}
            icon={<Calendar size={20} className="text-white" />}
            bgColor="bg-blue-600"
            textColor="text-white"
            linkHref="/marketing"
          />

          {/* Analytics Summary Card */}
          <SectionSummaryCard
            title="Analytics"
            description="SEO, PPC, and performance metrics"
            metrics={[
              {
                label: "Website Visitors",
                value: "2,456",
                change: { value: 8, isPositive: true },
              },
              {
                label: "Avg. Session",
                value: "2:45",
                change: { value: 12, isPositive: true },
              },
              {
                label: "Bounce Rate",
                value: "32%",
                change: { value: 3, isPositive: false },
              },
              {
                label: "Conversion",
                value: "4.2%",
                change: { value: 0.8, isPositive: true },
              },
            ]}
            icon={<BarChart size={20} className="text-white" />}
            bgColor="bg-indigo-600"
            textColor="text-white"
            linkHref="/analytics"
          />

          {/* Patient Experience Summary Card */}
          <SectionSummaryCard
            title="Patient Experience"
            description="Patient loyalty and reputation"
            metrics={[
              {
                label: "Satisfaction",
                value: "4.8/5",
                change: { value: 0.2, isPositive: true },
              },
              {
                label: "Reviews",
                value: "142",
                change: { value: 15, isPositive: true },
              },
              {
                label: "Retention",
                value: "87%",
                change: { value: 3, isPositive: true },
              },
              {
                label: "Referrals",
                value: "28",
                change: { value: 40, isPositive: true },
              },
            ]}
            icon={<Users size={20} className="text-white" />}
            bgColor="bg-cyan-600"
            textColor="text-white"
            linkHref="/patient"
          />

          {/* Practice Management Summary Card */}
          <SectionSummaryCard
            title="Practice Management"
            description="Financial and operational metrics"
            metrics={[
              {
                label: "Revenue",
                value: "$42,850",
                change: { value: 8, isPositive: true },
              },
              {
                label: "Expenses",
                value: "$28,320",
                change: { value: 3, isPositive: false },
              },
              {
                label: "Profit Margin",
                value: "34%",
                change: { value: 2, isPositive: true },
              },
              {
                label: "Staff Utilization",
                value: "92%",
                change: { value: 4, isPositive: true },
              },
            ]}
            icon={<BarChart2 size={20} className="text-white" />}
            bgColor="bg-emerald-600"
            textColor="text-white"
            linkHref="/practice-management"
          />

          {/* Tasks Summary Card */}
          <SectionSummaryCard
            title="Tasks"
            description="Pending and completed tasks"
            metrics={[
              {
                label: "Pending",
                value: "9",
                change: { value: 2, isPositive: false },
              },
              {
                label: "Completed",
                value: "24",
                change: { value: 33, isPositive: true },
              },
              {
                label: "Overdue",
                value: "2",
                change: { value: 50, isPositive: false },
              },
              {
                label: "Completion Rate",
                value: "89%",
                change: { value: 5, isPositive: true },
              },
            ]}
            icon={<FileText size={20} className="text-white" />}
            bgColor="bg-amber-600"
            textColor="text-white"
            linkHref="/tasks"
          />

          {/* Content Generator Summary Card */}
          <SectionSummaryCard
            title="Content Generator"
            description="Marketing content creation"
            metrics={[
              {
                label: "Generated",
                value: "18",
                change: { value: 28, isPositive: true },
              },
              {
                label: "Published",
                value: "12",
                change: { value: 20, isPositive: true },
              },
              {
                label: "Engagement",
                value: "3.2K",
                change: { value: 15, isPositive: true },
              },
              {
                label: "Conversion",
                value: "2.8%",
                change: { value: 0.3, isPositive: true },
              },
            ]}
            icon={<PieChart size={20} className="text-white" />}
            bgColor="bg-purple-600"
            textColor="text-white"
            linkHref="/content-generator"
          />
        </div>

        {/* SEO and PPC Charts */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
          {/* SEO Performance */}
          <div className="col-span-1 md:col-span-2 lg:col-span-6 bg-white p-6 rounded-lg border border-gray-200">
            <h2 className="text-lg font-bold mb-4 text-black">SEO Performance</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={seoData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="Organic" stroke="#007CD3" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* PPC Performance */}
          <div className="col-span-1 md:col-span-2 lg:col-span-6 bg-white p-6 rounded-lg border border-gray-200">
            <h2 className="text-lg font-bold mb-4 text-black">PPC Performance</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={ppcData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="PPC" stroke="#3399E0" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Seasonal Marketing Tips */}
        <div className="mt-6">
          <SeasonalMarketingTips />
        </div>
      </div>
    </div>
  )
}

