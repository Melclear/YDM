"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import {
  ChevronDown,
  ChevronRight,
  Home,
  BarChart2,
  Users,
  Calendar,
  Settings,
  Menu,
  X,
  MessageSquare,
  FileText,
  Instagram,
  Facebook,
  Twitter,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export default function ContentGeneratorPage() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeTab, setActiveTab] = useState("blog")
  const [generatedContent, setGeneratedContent] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [contentLength, setContentLength] = useState([500])

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen)
  }

  const handleGenerate = (type: string) => {
    setIsGenerating(true)

    // Simulate content generation
    setTimeout(() => {
      let content = ""

      if (type === "blog") {
        content = `# Improving Dental Health Through Preventative Care

Preventative dental care is the cornerstone of maintaining optimal oral health. Regular check-ups, proper brushing techniques, and daily flossing can significantly reduce the risk of developing serious dental issues.

## The Importance of Regular Check-ups

Dental professionals recommend visiting your dentist every six months for a comprehensive examination and cleaning. These routine visits allow dentists to:

- Detect early signs of decay or disease
- Remove plaque and tartar buildup
- Provide personalized oral hygiene recommendations
- Screen for oral cancer and other conditions

Early detection of dental problems can save patients from discomfort, extensive treatments, and higher costs in the long run.

## Daily Habits for Dental Health

Maintaining good oral hygiene at home is equally important. Here are some essential practices:

1. Brush your teeth twice daily with fluoride toothpaste
2. Floss at least once a day to remove plaque between teeth
3. Use an antimicrobial mouthwash to reduce bacteria
4. Limit sugary foods and beverages
5. Stay hydrated by drinking plenty of water

By incorporating these habits into your daily routine, you can significantly improve your dental health and overall wellbeing.`
      } else if (type === "social") {
        content = `📢 Did you know that regular dental check-ups can prevent 90% of dental diseases? Don't wait until it hurts - schedule your appointment today! #DentalHealth #PreventativeCare

🦷 Brushing is just the beginning! Flossing removes plaque from areas your toothbrush can't reach. Make it part of your daily routine for a healthier smile! #OralHygieneTips

✨ Transform your smile with our professional whitening services! Book a consultation this week and receive 15% off your first treatment. Your confidence boost is just an appointment away! #SmileTransformation`
      } else if (type === "ppc") {
        content = `Headline: Professional Dental Care | Same-Day Appointments
Description: Expert dental team with 20+ years experience. Pain-free treatments, affordable prices. New patients welcome!
CTA: Book Now - Free Consultation

Headline: Transform Your Smile Today | Advanced Cosmetic Dentistry
Description: Achieve the perfect smile with our state-of-the-art cosmetic treatments. Financing available.
CTA: See Our Results - Before & After Gallery

Headline: Emergency Dental Care 24/7 | Immediate Relief
Description: Experiencing dental pain? Our emergency team is available 24/7. No waiting, immediate care.
CTA: Call Now - Relief in Hours`
      }

      setGeneratedContent(content)
      setIsGenerating(false)
    }, 2000)
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-gray-800 transform ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-auto lg:h-screen`}
      >
        <div className="flex items-center justify-between h-16 px-4 border-b dark:border-gray-700">
          <Link href="/" className="flex items-center">
            <Image src="/images/ydm-logo.png" alt="YDM Logo" width={120} height={40} />
          </Link>
          <button onClick={toggleSidebar} className="lg:hidden">
            <X size={24} />
          </button>
        </div>
        <nav className="px-4 py-4">
          <ul className="space-y-2">
            <li>
              <Link
                href="/"
                className="flex items-center px-4 py-2 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Home className="w-5 h-5 mr-3" />
                <span>Dashboard</span>
              </Link>
            </li>
            <li>
              <div className="flex items-center justify-between px-4 py-2 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer">
                <div className="flex items-center">
                  <BarChart2 className="w-5 h-5 mr-3" />
                  <span>Marketing</span>
                </div>
                <ChevronDown className="w-4 h-4" />
              </div>
              <ul className="pl-4 mt-1 space-y-1">
                <li>
                  <Link
                    href="/marketing"
                    className="flex items-center px-4 py-2 text-sm text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <ChevronRight className="w-4 h-4 mr-2" />
                    <span>Overview</span>
                  </Link>
                </li>
                <li>
                  <Link
                    href="/campaigns"
                    className="flex items-center px-4 py-2 text-sm text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <ChevronRight className="w-4 h-4 mr-2" />
                    <span>Campaign Manager</span>
                  </Link>
                </li>
                <li>
                  <Link
                    href="/promotions"
                    className="flex items-center px-4 py-2 text-sm text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <ChevronRight className="w-4 h-4 mr-2" />
                    <span>Promotions Manager</span>
                  </Link>
                </li>
              </ul>
            </li>
            <li>
              <div className="flex items-center justify-between px-4 py-2 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer">
                <div className="flex items-center">
                  <BarChart2 className="w-5 h-5 mr-3" />
                  <span>Analytics</span>
                </div>
                <ChevronDown className="w-4 h-4" />
              </div>
              <ul className="pl-4 mt-1 space-y-1">
                <li>
                  <Link
                    href="/analytics"
                    className="flex items-center px-4 py-2 text-sm text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <ChevronRight className="w-4 h-4 mr-2" />
                    <span>Overview</span>
                  </Link>
                </li>
                <li>
                  <Link
                    href="/seo-ppc-analytics"
                    className="flex items-center px-4 py-2 text-sm text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <ChevronRight className="w-4 h-4 mr-2" />
                    <span>SEO & PPC Analytics</span>
                  </Link>
                </li>
              </ul>
            </li>
            <li>
              <Link
                href="/patient"
                className="flex items-center px-4 py-2 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Users className="w-5 h-5 mr-3" />
                <span>Patient Experience</span>
              </Link>
            </li>
            <li>
              <Link
                href="/content-generator"
                className="flex items-center px-4 py-2 text-gray-900 bg-gray-200 dark:bg-gray-700 dark:text-white rounded-lg"
              >
                <MessageSquare className="w-5 h-5 mr-3" />
                <span>Content Generator</span>
              </Link>
            </li>
            <li>
              <Link
                href="/tasks"
                className="flex items-center px-4 py-2 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Calendar className="w-5 h-5 mr-3" />
                <span>Tasks</span>
              </Link>
            </li>
            <li>
              <Link
                href="/settings"
                className="flex items-center px-4 py-2 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Settings className="w-5 h-5 mr-3" />
                <span>Settings</span>
              </Link>
            </li>
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="flex items-center justify-between h-16 px-6 bg-white dark:bg-gray-800 border-b dark:border-gray-700">
          <button onClick={toggleSidebar} className="lg:hidden">
            <Menu size={24} />
          </button>
          <div className="flex items-center ml-auto space-x-4">
            <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                <path d="M13.73 21a2 2 0 0 1-3.46 0" />
              </svg>
            </button>
            <div className="relative">
              <Image src="/images/mcleary.png" alt="Profile" width={36} height={36} className="rounded-full" />
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Content Generator</h1>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Content Generator Controls */}
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle>Generate Content</CardTitle>
                    <CardDescription>Create content for different marketing channels</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Tabs defaultValue="blog" onValueChange={(value) => setActiveTab(value)}>
                      <TabsList className="grid grid-cols-3 mb-4">
                        <TabsTrigger value="blog">Blog</TabsTrigger>
                        <TabsTrigger value="social">Social</TabsTrigger>
                        <TabsTrigger value="ppc">PPC Ads</TabsTrigger>
                      </TabsList>

                      <TabsContent value="blog">
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="blog-topic">Topic</Label>
                            <Input id="blog-topic" placeholder="e.g., Preventative Dental Care" />
                          </div>
                          <div>
                            <Label htmlFor="blog-keywords">Keywords (comma separated)</Label>
                            <Input id="blog-keywords" placeholder="e.g., dental health, prevention, oral hygiene" />
                          </div>
                          <div>
                            <Label>Content Length</Label>
                            <div className="pt-2">
                              <Slider
                                value={contentLength}
                                min={300}
                                max={2000}
                                step={100}
                                onValueChange={setContentLength}
                              />
                              <div className="flex justify-between mt-1 text-xs text-gray-500">
                                <span>Short</span>
                                <span>{contentLength[0]} words</span>
                                <span>Long</span>
                              </div>
                            </div>
                          </div>
                          <div>
                            <Label htmlFor="blog-tone">Tone</Label>
                            <Select defaultValue="informative">
                              <SelectTrigger>
                                <SelectValue placeholder="Select tone" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="informative">Informative</SelectItem>
                                <SelectItem value="conversational">Conversational</SelectItem>
                                <SelectItem value="professional">Professional</SelectItem>
                                <SelectItem value="friendly">Friendly</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Switch id="include-cta" />
                            <Label htmlFor="include-cta">Include Call-to-Action</Label>
                          </div>
                          <Button className="w-full" onClick={() => handleGenerate("blog")} disabled={isGenerating}>
                            {isGenerating ? "Generating..." : "Generate Blog Post"}
                          </Button>
                        </div>
                      </TabsContent>

                      <TabsContent value="social">
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="social-topic">Topic</Label>
                            <Input id="social-topic" placeholder="e.g., Teeth Whitening Special" />
                          </div>
                          <div>
                            <Label>Platforms</Label>
                            <div className="flex items-center space-x-2 mt-2">
                              <div className="flex items-center space-x-2">
                                <Switch id="facebook" defaultChecked />
                                <Label htmlFor="facebook" className="flex items-center">
                                  <Facebook className="w-4 h-4 mr-1" />
                                  Facebook
                                </Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Switch id="instagram" defaultChecked />
                                <Label htmlFor="instagram" className="flex items-center">
                                  <Instagram className="w-4 h-4 mr-1" />
                                  Instagram
                                </Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Switch id="twitter" defaultChecked />
                                <Label htmlFor="twitter" className="flex items-center">
                                  <Twitter className="w-4 h-4 mr-1" />
                                  Twitter
                                </Label>
                              </div>
                            </div>
                          </div>
                          <div>
                            <Label htmlFor="social-tone">Tone</Label>
                            <Select defaultValue="engaging">
                              <SelectTrigger>
                                <SelectValue placeholder="Select tone" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="engaging">Engaging</SelectItem>
                                <SelectItem value="promotional">Promotional</SelectItem>
                                <SelectItem value="educational">Educational</SelectItem>
                                <SelectItem value="humorous">Humorous</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="social-posts">Number of Posts</Label>
                            <Select defaultValue="3">
                              <SelectTrigger>
                                <SelectValue placeholder="Select number" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="1">1 post</SelectItem>
                                <SelectItem value="3">3 posts</SelectItem>
                                <SelectItem value="5">5 posts</SelectItem>
                                <SelectItem value="10">10 posts</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Switch id="include-hashtags" defaultChecked />
                            <Label htmlFor="include-hashtags">Include Hashtags</Label>
                          </div>
                          <Button className="w-full" onClick={() => handleGenerate("social")} disabled={isGenerating}>
                            {isGenerating ? "Generating..." : "Generate Social Posts"}
                          </Button>
                        </div>
                      </TabsContent>

                      <TabsContent value="ppc">
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="ppc-service">Service/Offering</Label>
                            <Input id="ppc-service" placeholder="e.g., Teeth Whitening, Emergency Care" />
                          </div>
                          <div>
                            <Label htmlFor="ppc-keywords">Keywords (comma separated)</Label>
                            <Input id="ppc-keywords" placeholder="e.g., dentist near me, affordable dentist" />
                          </div>
                          <div>
                            <Label htmlFor="ppc-platform">Ad Platform</Label>
                            <Select defaultValue="google">
                              <SelectTrigger>
                                <SelectValue placeholder="Select platform" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="google">Google Ads</SelectItem>
                                <SelectItem value="facebook">Facebook Ads</SelectItem>
                                <SelectItem value="instagram">Instagram Ads</SelectItem>
                                <SelectItem value="bing">Bing Ads</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="ppc-variations">Ad Variations</Label>
                            <Select defaultValue="3">
                              <SelectTrigger>
                                <SelectValue placeholder="Select number" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="1">1 variation</SelectItem>
                                <SelectItem value="3">3 variations</SelectItem>
                                <SelectItem value="5">5 variations</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Switch id="include-pricing" />
                            <Label htmlFor="include-pricing">Include Pricing</Label>
                          </div>
                          <Button className="w-full" onClick={() => handleGenerate("ppc")} disabled={isGenerating}>
                            {isGenerating ? "Generating..." : "Generate PPC Ads"}
                          </Button>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              </div>

              {/* Content Preview */}
              <div className="lg:col-span-2">
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle>
                      {activeTab === "blog"
                        ? "Blog Post Preview"
                        : activeTab === "social"
                          ? "Social Media Posts"
                          : "PPC Ad Variations"}
                    </CardTitle>
                    <CardDescription>
                      {activeTab === "blog"
                        ? "Preview your generated blog post"
                        : activeTab === "social"
                          ? "Preview your social media content"
                          : "Preview your PPC ad variations"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[500px] overflow-y-auto">
                    {isGenerating ? (
                      <div className="flex items-center justify-center h-full">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                      </div>
                    ) : generatedContent ? (
                      <div
                        className={`prose dark:prose-invert max-w-none ${activeTab === "social" ? "space-y-6" : ""}`}
                      >
                        {activeTab === "blog" ? (
                          <div
                            dangerouslySetInnerHTML={{
                              __html: generatedContent
                                .replace(/\n/g, "<br>")
                                .replace(/^# (.*$)/gm, "<h1>$1</h1>")
                                .replace(/^## (.*$)/gm, "<h2>$1</h2>")
                                .replace(/^- (.*$)/gm, "<li>$1</li>")
                                .replace(/^\d\. (.*$)/gm, "<li>$1</li>"),
                            }}
                          />
                        ) : activeTab === "social" ? (
                          generatedContent.split("\n\n").map((post, index) => (
                            <Card key={index} className="p-4 border border-gray-200 dark:border-gray-700">
                              <div dangerouslySetInnerHTML={{ __html: post.replace(/\n/g, "<br>") }} />
                            </Card>
                          ))
                        ) : (
                          generatedContent.split("\n\n").map((ad, index) => (
                            <Card key={index} className="p-4 mb-4 border border-gray-200 dark:border-gray-700">
                              <div dangerouslySetInnerHTML={{ __html: ad.replace(/\n/g, "<br>") }} />
                            </Card>
                          ))
                        )}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-gray-500 dark:text-gray-400">
                        <FileText className="w-16 h-16 mb-4" />
                        <p>Generated content will appear here</p>
                        <p className="text-sm">Configure your settings and click Generate</p>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" disabled={!generatedContent}>
                      Edit
                    </Button>
                    <div className="flex space-x-2">
                      <Button variant="outline" disabled={!generatedContent}>
                        Copy
                      </Button>
                      <Button disabled={!generatedContent}>Save</Button>
                    </div>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}

