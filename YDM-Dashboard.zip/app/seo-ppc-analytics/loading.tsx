const Loading = () => {
  return (
    <div className="flex items-center justify-center h-full">
      <p className="text-gray-500 animate-pulse">Loading SEO & PPC Analytics...</p>
    </div>
  )
}

export default Loading

