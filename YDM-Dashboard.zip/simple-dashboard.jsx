function SimpleDashboard() {
  return (
    <div style={{ padding: "20px", maxWidth: "800px", margin: "0 auto" }}>
      <h1 style={{ fontSize: "24px", fontWeight: "bold", marginBottom: "16px" }}>Freelancer Dashboard</h1>
      <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "16px" }}>
        <div
          style={{
            padding: "16px",
            backgroundColor: "white",
            borderRadius: "8px",
            boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
            border: "1px solid #eee",
          }}
        >
          <h2 style={{ fontSize: "18px", fontWeight: "bold", marginBottom: "8px" }}>Income Summary</h2>
          <p>Total this month: $2,567</p>
        </div>
      </div>
    </div>
  )
}

export default SimpleDashboard

