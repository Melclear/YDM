// Removed "use client" directive

export default function Dashboard() {
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Freelancer Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded shadow border">
          <h2 className="text-lg font-semibold mb-2">Income Tracker</h2>
          <p className="text-gray-600">$2,567 this week</p>
          <div className="h-20 mt-2 flex items-end space-x-2">
            <div className="w-4 bg-blue-400 h-12 rounded"></div>
            <div className="w-4 bg-blue-400 h-16 rounded"></div>
            <div className="w-4 bg-blue-400 h-10 rounded"></div>
            <div className="w-4 bg-blue-400 h-14 rounded"></div>
            <div className="w-4 bg-blue-400 h-8 rounded"></div>
          </div>
        </div>

        <div className="bg-white p-4 rounded shadow border">
          <h2 className="text-lg font-semibold mb-2">Recent Projects</h2>
          <div className="space-y-2">
            <div className="p-2 border rounded">
              <div className="flex justify-between">
                <span>Web Development</span>
                <span className="bg-gray-800 text-white text-xs px-2 py-1 rounded">Paid</span>
              </div>
            </div>
            <div className="p-2 border rounded">
              <div className="flex justify-between">
                <span>Web Design</span>
                <span className="bg-gray-800 text-white text-xs px-2 py-1 rounded">Paid</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-4 rounded shadow border">
          <h2 className="text-lg font-semibold mb-2">Connections</h2>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-gray-300 mr-2"></div>
                <div>
                  <div className="font-medium">Randy Gouse</div>
                  <div className="text-xs text-gray-500">Cybersecurity</div>
                </div>
              </div>
              <button className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-sm">+</button>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-gray-300 mr-2"></div>
                <div>
                  <div className="font-medium">Giana Schleifer</div>
                  <div className="text-xs text-gray-500">UX/UI Designer</div>
                </div>
              </div>
              <button className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-sm">+</button>
            </div>
          </div>
        </div>

        <div className="bg-blue-50 p-4 rounded shadow border">
          <h2 className="text-lg font-semibold mb-2">Premium Features</h2>
          <p className="text-sm mb-4">Get access to exclusive benefits</p>
          <button className="bg-white px-3 py-1 rounded shadow text-sm">Upgrade now</button>
        </div>
      </div>
    </div>
  )
}

