import { Plus } from "lucide-react"
import Image from "next/image"

export function Connections() {
  return (
    <div className="col-span-12 md:col-span-4 lg:col-span-3 bg-white rounded-xl p-6 shadow-sm border">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Let's Connect</h2>
        <a href="#" className="text-xs text-gray-500">
          See all
        </a>
      </div>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-gray-300 overflow-hidden">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="Randy Gouse"
                width={40}
                height={40}
                className="object-cover"
              />
            </div>
            <div>
              <h3 className="font-medium text-sm">Randy Gouse</h3>
              <p className="text-xs text-gray-500">Cybersecurity specialist</p>
            </div>
          </div>
          <button className="h-6 w-6 rounded-full bg-gray-100 flex items-center justify-center">
            <Plus className="h-3 w-3" />
          </button>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-gray-300 overflow-hidden">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="Giana Schleifer"
                width={40}
                height={40}
                className="object-cover"
              />
            </div>
            <div>
              <h3 className="font-medium text-sm">Giana Schleifer</h3>
              <p className="text-xs text-gray-500">UX/UI Designer</p>
            </div>
          </div>
          <button className="h-6 w-6 rounded-full bg-gray-100 flex items-center justify-center">
            <Plus className="h-3 w-3" />
          </button>
        </div>
      </div>
    </div>
  )
}

