import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Lightbulb, ArrowRight } from "lucide-react"

export function ReputationInsights() {
  return (
    <Card className="flex-1 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-blue-500" />
          Reputation Insights
        </CardTitle>
        <CardDescription>Actionable recommendations to improve your online reputation</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="rounded-lg bg-white p-3 shadow-sm dark:bg-gray-800">
            <h4 className="font-medium text-blue-600 dark:text-blue-400">Respond to Negative Reviews</h4>
            <p className="mt-1 text-sm text-muted-foreground">
              You have 2 negative reviews from the past week that need responses. Addressing these promptly can improve
              patient satisfaction.
            </p>
            <Button variant="link" className="mt-1 h-auto p-0 text-sm text-blue-600 dark:text-blue-400">
              View Reviews <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </div>

          <div className="rounded-lg bg-white p-3 shadow-sm dark:bg-gray-800">
            <h4 className="font-medium text-blue-600 dark:text-blue-400">Update Directory Listings</h4>
            <p className="mt-1 text-sm text-muted-foreground">
              3 of your online directory listings have outdated information. Keeping these updated ensures patients can
              find you easily.
            </p>
            <Button variant="link" className="mt-1 h-auto p-0 text-sm text-blue-600 dark:text-blue-400">
              View Listings <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </div>

          <div className="rounded-lg bg-white p-3 shadow-sm dark:bg-gray-800">
            <h4 className="font-medium text-blue-600 dark:text-blue-400">Highlight Positive Mentions</h4>
            <p className="mt-1 text-sm text-muted-foreground">
              Your practice was mentioned positively in 2 local news articles. Share these on your social media to boost
              visibility.
            </p>
            <Button variant="link" className="mt-1 h-auto p-0 text-sm text-blue-600 dark:text-blue-400">
              View Mentions <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </div>

          <div className="rounded-lg bg-white p-3 shadow-sm dark:bg-gray-800">
            <h4 className="font-medium text-blue-600 dark:text-blue-400">Request More Reviews</h4>
            <p className="mt-1 text-sm text-muted-foreground">
              Your review volume has decreased by 15% this month. Consider sending review requests to recent patients.
            </p>
            <Button variant="link" className="mt-1 h-auto p-0 text-sm text-blue-600 dark:text-blue-400">
              Start Campaign <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

