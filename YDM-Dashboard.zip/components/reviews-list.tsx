"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, MessageSquare, ThumbsUp, Flag, MoreHorizontal, CheckCircle2, Clock } from "lucide-react"

export function ReviewsList() {
  const [selectedTab, setSelectedTab] = useState("all")

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Patient Reviews</CardTitle>
            <CardDescription>Manage and respond to patient reviews</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select defaultValue="recent">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Most Recent</SelectItem>
                <SelectItem value="rating-high">Highest Rating</SelectItem>
                <SelectItem value="rating-low">Lowest Rating</SelectItem>
                <SelectItem value="needs-response">Needs Response</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full" onValueChange={setSelectedTab}>
          <TabsList className="mb-4 w-full justify-start">
            <TabsTrigger value="all" className="relative">
              All
              <Badge className="ml-2" variant="secondary">
                347
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="unresponded" className="relative">
              Unresponded
              <Badge className="ml-2" variant="secondary">
                12
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="positive" className="relative">
              Positive
              <Badge className="ml-2" variant="secondary">
                319
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="negative" className="relative">
              Negative
              <Badge className="ml-2" variant="secondary">
                28
              </Badge>
            </TabsTrigger>
          </TabsList>

          <div className="space-y-4">
            {reviews
              .filter((review) => {
                if (selectedTab === "all") return true
                if (selectedTab === "unresponded") return !review.responded
                if (selectedTab === "positive") return review.rating >= 4
                if (selectedTab === "negative") return review.rating <= 3
                return true
              })
              .slice(0, 5)
              .map((review, index) => (
                <div key={index} className="rounded-lg border p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <Avatar>
                        <AvatarImage src={review.avatar} alt={review.name} />
                        <AvatarFallback>{review.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{review.name}</p>
                        <div className="flex items-center">
                          <div className="flex text-yellow-400">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${i < review.rating ? "fill-current" : "stroke-yellow-400"}`}
                              />
                            ))}
                          </div>
                          <span className="ml-2 text-xs text-muted-foreground">
                            {review.platform} • {review.date}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {review.responded ? (
                        <Badge variant="outline" className="flex items-center gap-1">
                          <CheckCircle2 className="h-3 w-3 text-green-500" />
                          <span>Responded</span>
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="flex items-center gap-1 text-amber-500">
                          <Clock className="h-3 w-3" />
                          <span>Needs Response</span>
                        </Badge>
                      )}
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="mt-3">
                    <p className="text-sm">{review.content}</p>

                    {review.responded && (
                      <div className="mt-3 rounded-lg bg-muted p-3">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src="/placeholder.svg?height=30&width=30" alt="Bright Smile Dental" />
                            <AvatarFallback>BS</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-xs font-medium">Bright Smile Dental</p>
                            <p className="text-xs text-muted-foreground">Practice Manager • {review.responseDate}</p>
                          </div>
                        </div>
                        <p className="mt-2 text-xs">{review.response}</p>
                      </div>
                    )}
                  </div>

                  <div className="mt-3 flex items-center gap-3">
                    <Button variant="ghost" size="sm">
                      <MessageSquare className="mr-1 h-4 w-4" />
                      {review.responded ? "Edit Response" : "Respond"}
                    </Button>
                    <Button variant="ghost" size="sm">
                      <ThumbsUp className="mr-1 h-4 w-4" />
                      Helpful
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Flag className="mr-1 h-4 w-4" />
                      Report
                    </Button>
                  </div>
                </div>
              ))}
          </div>

          <div className="mt-4 flex justify-center">
            <Button variant="outline">Load More Reviews</Button>
          </div>
        </Tabs>
      </CardContent>
    </Card>
  )
}

// Demo data for reviews
const reviews = [
  {
    name: "Jennifer Smith",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 5,
    platform: "Google",
    date: "2 days ago",
    content:
      "Dr. Thompson and his team are amazing! I've been going to Bright Smile Dental for years and have always had a great experience. The office is clean, modern, and the staff is incredibly friendly. They make going to the dentist almost enjoyable!",
    responded: true,
    responseDate: "1 day ago",
    response:
      "Thank you so much for your kind words, Jennifer! We're thrilled to hear that you've had consistently positive experiences with us. Our team works hard to create a comfortable environment for all our patients. We look forward to seeing you at your next appointment!",
  },
  {
    name: "Robert Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 4,
    platform: "Yelp",
    date: "1 week ago",
    content:
      "Good dental practice with professional staff. Dr. Wilson was thorough and explained everything clearly. The hygienist was gentle and made sure I was comfortable throughout the cleaning. Only giving 4 stars because the wait time was a bit longer than expected.",
    responded: true,
    responseDate: "5 days ago",
    response:
      "Hi Robert, thank you for taking the time to leave us a review. We're glad you had a positive experience with Dr. Wilson and our hygienist. We apologize for the wait time during your visit and are actively working to improve our scheduling system. We appreciate your feedback and hope to see you again soon!",
  },
  {
    name: "Michael Davis",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 2,
    platform: "Facebook",
    date: "2 weeks ago",
    content:
      "Had issues with billing and insurance. The dental work was fine, but I spent weeks trying to sort out charges with my insurance company because the office staff didn't file the claim correctly. Very frustrating experience.",
    responded: false,
    responseDate: "",
    response: "",
  },
  {
    name: "Emily Wilson",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 5,
    platform: "Google",
    date: "3 weeks ago",
    content:
      "I was extremely nervous about getting a root canal, but Dr. Thompson made the experience so much better than I expected. He was patient, gentle, and checked in with me throughout the procedure. The front desk staff was also very helpful with scheduling and insurance questions.",
    responded: true,
    responseDate: "2 weeks ago",
    response:
      "Thank you for your wonderful review, Emily! We understand dental procedures can cause anxiety, and we're so pleased that Dr. Thompson was able to make your experience comfortable. Our team strives to provide exceptional care to all our patients. We appreciate your trust in us!",
  },
  {
    name: "David Brown",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 3,
    platform: "Healthgrades",
    date: "1 month ago",
    content:
      "Average dental practice. The dentist seemed knowledgeable, but the appointment felt rushed. The office is nice and clean, and the equipment seems up-to-date. Parking can be difficult during peak hours.",
    responded: false,
    responseDate: "",
    response: "",
  },
  {
    name: "Sarah Miller",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 5,
    platform: "ZocDoc",
    date: "1 month ago",
    content:
      "Brought my 5-year-old daughter for her first dental visit and was impressed with how well the staff handled her anxiety. They were patient, kind, and made the experience fun for her. The kids' waiting area with toys and books was a nice touch!",
    responded: true,
    responseDate: "3 weeks ago",
    response:
      "Hi Sarah, we're delighted to hear about your daughter's positive first dental experience! Making children comfortable is a priority for us, and we're glad our team and kid-friendly environment helped ease her anxiety. Thank you for trusting us with your daughter's dental care!",
  },
]

