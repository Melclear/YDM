import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ExternalLink, MessageCircle, Share2, Globe, Newspaper, FileText } from "lucide-react"

export function MentionsTracker() {
  return (
    <div className="grid gap-6 md:grid-cols-3">
      <div className="space-y-6 md:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle>Web Mentions</CardTitle>
            <CardDescription>Mentions of your practice across the web</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all">
              <TabsList className="mb-4">
                <TabsTrigger value="all">All Sources</TabsTrigger>
                <TabsTrigger value="news">News</TabsTrigger>
                <TabsTrigger value="blogs">Blogs</TabsTrigger>
                <TabsTrigger value="directories">Directories</TabsTrigger>
              </TabsList>

              <div className="space-y-4">
                {webMentions.map((mention, index) => (
                  <div key={index} className="rounded-lg border p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          {mention.type === "news" && <Newspaper className="h-4 w-4 text-blue-500" />}
                          {mention.type === "blog" && <FileText className="h-4 w-4 text-green-500" />}
                          {mention.type === "directory" && <Globe className="h-4 w-4 text-purple-500" />}
                          <span className="font-medium">{mention.source}</span>
                          <Badge variant="outline">{mention.type}</Badge>
                          <span className="text-xs text-muted-foreground">{mention.date}</span>
                        </div>
                        <h4 className="mt-2 font-medium">{mention.title}</h4>
                      </div>
                      <Badge
                        variant={
                          mention.sentiment === "positive"
                            ? "success"
                            : mention.sentiment === "negative"
                              ? "destructive"
                              : "outline"
                        }
                      >
                        {mention.sentiment}
                      </Badge>
                    </div>
                    <p className="mt-2 text-sm">{mention.excerpt}</p>
                    <div className="mt-3 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Button variant="ghost" size="sm">
                          <MessageCircle className="mr-1 h-4 w-4" />
                          Comment
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Share2 className="mr-1 h-4 w-4" />
                          Share
                        </Button>
                      </div>
                      <Button variant="outline" size="sm" className="flex items-center gap-1">
                        <ExternalLink className="h-4 w-4" />
                        View Full Article
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 flex justify-center">
                <Button variant="outline">Load More Mentions</Button>
              </div>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      <div>
        <Card className="h-full">
          <CardHeader>
            <CardTitle>Mention Sources</CardTitle>
            <CardDescription>Distribution of mentions by source type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative mx-auto h-[240px] w-[240px]">
              <svg className="h-full w-full" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="40" fill="none" stroke="#e2e8f0" strokeWidth="20" />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="none"
                  stroke="#3b82f6"
                  strokeWidth="20"
                  strokeDasharray="251.2"
                  strokeDashoffset="188.4"
                  transform="rotate(-90 50 50)"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="20"
                  strokeDasharray="251.2"
                  strokeDashoffset="213.5"
                  transform="rotate(-90 50 50)"
                  strokeDashoffset="188.4"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="none"
                  stroke="#8b5cf6"
                  strokeWidth="20"
                  strokeDasharray="251.2"
                  strokeDashoffset="238.6"
                  transform="rotate(-90 50 50)"
                  strokeDashoffset="213.5"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <span className="text-3xl font-bold">42</span>
                  <span className="block text-sm text-muted-foreground">Total Mentions</span>
                </div>
              </div>
            </div>

            <div className="mt-6 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-blue-500"></div>
                  <span className="ml-2">News Articles</span>
                </div>
                <span className="font-medium">25%</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-green-500"></div>
                  <span className="ml-2">Blogs & Forums</span>
                </div>
                <span className="font-medium">15%</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-purple-500"></div>
                  <span className="ml-2">Directories</span>
                </div>
                <span className="font-medium">10%</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-gray-200"></div>
                  <span className="ml-2">Social Media</span>
                </div>
                <span className="font-medium">50%</span>
              </div>
            </div>

            <div className="mt-6 space-y-2 rounded-lg bg-muted p-4">
              <h4 className="font-medium">Mention Insights</h4>
              <p className="text-sm text-muted-foreground">
                Your practice has seen a 15% increase in online mentions this month, with most coming from social media
                and local news sources.
              </p>
              <Button variant="outline" className="mt-2 w-full text-sm">
                Generate Detailed Report
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Demo data for web mentions
const webMentions = [
  {
    source: "Local Health News",
    type: "news",
    title: "Bright Smile Dental Hosts Free Dental Checkup Day for Children",
    excerpt:
      "Bright Smile Dental Practice organized a community event offering free dental checkups for children from low-income families. Dr. Thompson and his team provided services to over 50 children during the event.",
    date: "3 days ago",
    sentiment: "positive",
  },
  {
    source: "Dental Health Blog",
    type: "blog",
    title: "Top 10 Dental Practices in the Metro Area",
    excerpt:
      "Our annual review of dental practices in the metro area places Bright Smile Dental in the top 3 for patient satisfaction and quality of care. Their recent office renovation and expanded services were highlighted.",
    date: "1 week ago",
    sentiment: "positive",
  },
  {
    source: "City Business Journal",
    type: "news",
    title: "Local Dental Practices Adapting to Post-Pandemic Challenges",
    excerpt:
      "Several dental practices, including Bright Smile Dental, have implemented new safety protocols and telehealth options. Dr. Thompson mentioned the challenges of maintaining high-quality care while ensuring patient safety.",
    date: "2 weeks ago",
    sentiment: "neutral",
  },
  {
    source: "HealthGrade Directory",
    type: "directory",
    title: "Bright Smile Dental Practice Profile Updated",
    excerpt:
      "The practice profile has been updated with new services including Invisalign treatment and cosmetic dentistry options. Patient reviews highlight the friendly staff and modern facilities.",
    date: "3 weeks ago",
    sentiment: "neutral",
  },
  {
    source: "Patient Care Forum",
    type: "blog",
    title: "Discussion: Insurance Coverage at Bright Smile Dental",
    excerpt:
      "Several patients have reported issues with insurance claims processing at Bright Smile Dental. The practice has responded that they are working to resolve these administrative challenges.",
    date: "1 month ago",
    sentiment: "negative",
  },
]

