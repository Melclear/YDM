import { ChevronDown } from "lucide-react"
import { CardIcon } from "./ui-icons"

export function IncomeTracker() {
  return (
    <div className="col-span-12 lg:col-span-8 bg-white rounded-xl p-6 shadow-sm border">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 bg-gray-100 rounded-md flex items-center justify-center">
            <CardIcon />
          </div>
          <h2 className="text-2xl font-bold">Income Tracker</h2>
        </div>
        <div className="relative">
          <button className="flex items-center gap-2 px-4 py-2 bg-white border rounded-lg text-sm">
            Week
            <ChevronDown className="h-4 w-4" />
          </button>
        </div>
      </div>
      <p className="text-gray-500 text-sm mb-8">
        Track changes in income over time and access detailed data on each project and payments received.
      </p>

      <div className="relative h-64">
        {/* Income Chart */}
        <div className="absolute top-4 left-0 text-4xl font-bold flex items-center">
          <span className="text-green-600">+20%</span>
        </div>
        <div className="absolute bottom-0 left-0 right-0 flex justify-between items-end h-48">
          {["S", "M", "T", "W", "T", "F", "S"].map((day, i) => (
            <div key={i} className="flex flex-col items-center">
              <div className="relative w-12">
                <div
                  className={`w-0.5 mx-auto bg-blue-100 rounded-full ${i === 2 ? "h-40" : i === 3 ? "h-24" : i === 4 ? "h-32" : "h-16"}`}
                >
                  <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-blue-400 rounded-full"></div>
                </div>
              </div>
              <div
                className={`h-8 w-8 rounded-full flex items-center justify-center mt-2 text-sm ${i === 2 ? "bg-gray-800 text-white" : "bg-gray-200"}`}
              >
                {day}
              </div>
            </div>
          ))}
        </div>
        <div className="absolute top-4 right-4 px-3 py-1 bg-gray-800 text-white rounded-md text-sm">$2,567</div>
        <div className="absolute bottom-0 left-0 right-0 text-xs text-gray-500 text-center mt-2">
          This week&apos;s income is higher than last week&apos;s
        </div>
      </div>
    </div>
  )
}

