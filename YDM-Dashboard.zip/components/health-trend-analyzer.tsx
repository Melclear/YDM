import type React from "react"
import { ArrowUpRight, ArrowDownRight, TrendingUp, Activity, Users, BarChart3 } from "lucide-react"
import Link from "next/link"

type TrendCardProps = {
  title: string
  value: string
  change: number
  timeframe: string
  icon: React.ReactNode
  color: string
  link: string
}

const TrendCard = ({ title, value, change, timeframe, icon, color, link }: TrendCardProps) => {
  const isPositive = change > 0

  return (
    <Link href={link} className="bg-white rounded-xl p-5 border border-gray-200 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div className={`p-2 rounded-lg ${color}`}>{icon}</div>
        <div className={`flex items-center ${isPositive ? "text-green-500" : "text-red-500"}`}>
          {isPositive ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
          <span className="text-sm font-medium ml-1">{Math.abs(change)}%</span>
        </div>
      </div>
      <h3 className="text-lg font-bold text-gray-800">{title}</h3>
      <div className="mt-1 text-3xl font-bold">{value}</div>
      <p className="mt-2 text-sm text-gray-500">Compared to {timeframe}</p>
    </Link>
  )
}

export function HealthTrendAnalyzer() {
  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-gray-800">Health Trend Analyzer</h2>
          <p className="text-gray-500">Overview of key performance indicators across your practice</p>
        </div>
        <div className="flex items-center gap-2">
          <TrendingUp size={18} className="text-blue-600" />
          <span className="text-sm font-medium text-blue-600">Overall Health: Good</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <TrendCard
          title="Marketing Performance"
          value="87.4%"
          change={12.5}
          timeframe="last month"
          icon={<Activity size={20} className="text-white" />}
          color="bg-blue-600"
          link="/marketing"
        />

        <TrendCard
          title="Analytics Insights"
          value="1,243"
          change={-3.2}
          timeframe="previous quarter"
          icon={<BarChart3 size={20} className="text-white" />}
          color="bg-indigo-600"
          link="/analytics"
        />

        <TrendCard
          title="Patient Engagement"
          value="92.1%"
          change={8.7}
          timeframe="last 30 days"
          icon={<Users size={20} className="text-white" />}
          color="bg-cyan-600"
          link="/patient"
        />
      </div>

      <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-100">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-blue-100 rounded-full">
            <TrendingUp size={16} className="text-blue-600" />
          </div>
          <div>
            <h4 className="font-medium text-blue-800">Recommendation</h4>
            <p className="text-sm text-blue-700">
              Your patient engagement is performing well. Consider leveraging this strength to boost your analytics
              insights, which have shown a slight decline this quarter.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

