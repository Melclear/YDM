"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts"
// Add the import for InsightCard at the top
import { InsightCard } from "./insight-card"

// Content type data
const initialData = [
  { name: "Video", value: 0, color: "#4F46E5" },
  { name: "Image", value: 0, color: "#3B82F6" },
  { name: "Blog", value: 0, color: "#10B981" },
  { name: "Google Business", value: 0, color: "#F59E0B" },
]

const actualData = [
  { name: "Video", value: 35, color: "#4F46E5" },
  { name: "Image", value: 30, color: "#3B82F6" },
  { name: "Blog", value: 25, color: "#10B981" },
  { name: "Google Business", value: 10, color: "#F59E0B" },
]

export function ContentTypeCard() {
  const [data, setData] = useState(initialData)
  const [isAnimating, setIsAnimating] = useState(true)

  // Inside the component, before the return statement, add:
  const contentInsights = [
    "Video content generates 35% more engagement than other formats",
    "Blog posts with dental tips receive 2x more shares than other topics",
    "Images showing before/after results have the highest click-through rate",
  ]

  useEffect(() => {
    // Animate the chart on initial load
    const timer = setTimeout(() => {
      setData(actualData)
      setIsAnimating(false)
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 shadow-md rounded-md">
          <p className="font-medium" style={{ color: payload[0].payload.color }}>
            {payload[0].name}
          </p>
          <p className="text-sm text-gray-700">
            <span className="font-medium">Engagement:</span> {payload[0].value}%
          </p>
        </div>
      )
    }
    return null
  }

  // Update the return statement to include the insight card
  // Replace the existing return statement with:
  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <Card className="w-full bg-white rounded-xl shadow-sm border lg:col-span-7">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-lg font-bold text-headline">Content Type Performance</CardTitle>
              <CardDescription>Engagement by content format</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-48 flex flex-col items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={70}
                  paddingAngle={2}
                  dataKey="value"
                  isAnimationActive={isAnimating}
                  animationDuration={1500}
                  animationEasing="ease-out"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value, name) => [`${value} engagements`, "Engagement"]}
                  labelFormatter={(value) => `Content Type: ${value}`}
                />
                <Legend
                  layout="horizontal"
                  verticalAlign="bottom"
                  align="center"
                  formatter={(value, entry) => <span style={{ color: entry.color }}>{value}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Best performing content type */}
          <div className="mt-4 text-center">
            <p className="text-sm text-gray-500">Best Performing Content</p>
            <p className="text-lg font-bold text-indigo-600">Video</p>
            <p className="text-xs text-gray-500">35% engagement rate</p>
          </div>
        </CardContent>
      </Card>

      <div className="lg:col-span-5">
        <InsightCard
          title="Content Strategy Tips"
          insights={contentInsights}
          actionText="Create Content"
          actionUrl="/content-generator"
          variant="purple"
        />
      </div>
    </div>
  )
}

