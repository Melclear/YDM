import { ChevronRight } from "lucide-react"

export function PremiumFeatures() {
  return (
    <div className="col-span-12 md:col-span-4 lg:col-span-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6 shadow-sm border relative overflow-hidden">
      <div className="relative z-10">
        <h2 className="text-xl font-bold mb-2">Unlock Premium Features</h2>
        <p className="text-sm text-gray-600 mb-6">
          Get access to exclusive benefits and expand your freelancing opportunities
        </p>
        <button className="flex items-center gap-2 bg-white px-4 py-2 rounded-md text-sm font-medium shadow-sm">
          Upgrade now
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>
      <div className="absolute bottom-0 right-0 opacity-10">
        <svg width="180" height="180" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" />
          <path d="M12 5C13.6569 5 15 3.65685 15 2C15 0.343146 13.6569 -1 12 -1C10.3431 -1 9 0.343146 9 2C9 3.65685 10.3431 5 12 5Z" />
          <path d="M12 25C13.6569 25 15 23.6569 15 22C15 20.3431 13.6569 19 12 19C10.3431 19 9 20.3431 9 22C9 23.6569 10.3431 25 12 25Z" />
          <path d="M22 15C23.6569 15 25 13.6569 25 12C25 10.3431 23.6569 9 22 9C20.3431 9 19 10.3431 19 12C19 13.6569 20.3431 15 22 15Z" />
          <path d="M2 15C3.65685 15 5 13.6569 5 12C5 10.3431 3.65685 9 2 9C0.343146 9 -1 10.3431 -1 12C-1 13.6569 0.343146 15 2 15Z" />
        </svg>
      </div>
    </div>
  )
}

