import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CalendarIcon, TrendingUpIcon } from "lucide-react"

export function SeasonalMarketingTips() {
  // Get current month
  const currentMonth = new Date().getMonth()

  // Determine season based on month
  const getSeason = () => {
    if (currentMonth >= 2 && currentMonth <= 4) return "spring"
    if (currentMonth >= 5 && currentMonth <= 7) return "summer"
    if (currentMonth >= 8 && currentMonth <= 10) return "fall"
    return "winter"
  }

  const season = getSeason()

  // Season-specific marketing tips
  const getSeasonalTips = () => {
    switch (season) {
      case "spring":
        return {
          title: "Spring Marketing Opportunities",
          tips: [
            "Promote teeth whitening services for wedding season",
            "Launch a 'Spring Cleaning' dental checkup campaign",
            "Create content about allergies and oral health connections",
          ],
        }
      case "summer":
        return {
          title: "Summer Marketing Opportunities",
          tips: [
            "Target families with back-to-school dental checkups",
            "Promote sports mouth guards for summer activities",
            "Create content about staying hydrated for oral health",
          ],
        }
      case "fall":
        return {
          title: "Fall Marketing Opportunities",
          tips: [
            "Remind patients to use insurance benefits before year-end",
            "Create Halloween content about candy and dental health",
            "Promote cosmetic services before holiday season",
          ],
        }
      case "winter":
        return {
          title: "Winter Marketing Opportunities",
          tips: [
            "Highlight teeth whitening for holiday photos",
            "Promote end-of-year insurance benefit usage",
            "Create content about cold weather and sensitive teeth",
          ],
        }
    }
  }

  const { title, tips } = getSeasonalTips()

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-full bg-blue-100">
            <CalendarIcon className="h-4 w-4 text-blue-600" />
          </div>
          <CardTitle className="text-headline text-lg text-black">Seasonal Marketing</CardTitle>
        </div>
        <CardDescription className="text-black">Timely opportunities for your practice</CardDescription>
      </CardHeader>
      <CardContent>
        <h3 className="font-medium text-headline mb-2 text-black">{title}</h3>
        <ul className="space-y-1 mb-4">
          {tips.map((tip, index) => (
            <li key={index} className="text-sm flex items-start gap-2">
              <TrendingUpIcon className="h-4 w-4 text-blue-600 shrink-0 mt-0.5" />
              <span className="text-black">{tip}</span>
            </li>
          ))}
        </ul>
        <div className="text-xs text-black mt-2">
          <p>Update your marketing calendar to include these seasonal opportunities.</p>
        </div>
      </CardContent>
    </Card>
  )
}

