"use client"

import { useState, useEffect } from "react"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { InsightCard } from "./insight-card"

// Traffic sources data
const initialData = [
  { name: "Organic Search", value: 0, color: "#4F46E5" },
  { name: "Social Media", value: 0, color: "#3B82F6" },
  { name: "Direct", value: 0, color: "#10B981" },
  { name: "Referral", value: 0, color: "#F59E0B" },
  { name: "Email", value: 0, color: "#EC4899" },
  { name: "Paid Search", value: 0, color: "#8B5CF6" },
]

const actualData = [
  { name: "Organic Search", value: 40, color: "#4F46E5" },
  { name: "Social Media", value: 25, color: "#3B82F6" },
  { name: "Direct", value: 15, color: "#10B981" },
  { name: "Referral", value: 10, color: "#F59E0B" },
  { name: "Email", value: 7, color: "#EC4899" },
  { name: "Paid Search", value: 3, color: "#8B5CF6" },
]

export function TrafficSourcesChart() {
  const [data, setData] = useState(initialData)
  const [isAnimating, setIsAnimating] = useState(true)
  const [timeframe, setTimeframe] = useState("month")

  useEffect(() => {
    // Animate the chart on initial load
    const timer = setTimeout(() => {
      setData(actualData)
      setIsAnimating(false)
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 shadow-md rounded-md">
          <p className="font-medium" style={{ color: payload[0].payload.color }}>
            {payload[0].name}
          </p>
          <p className="text-sm text-gray-700">
            <span className="font-medium">Value:</span> {payload[0].value}%
          </p>
        </div>
      )
    }
    return null
  }

  const CustomLegend = (props) => {
    const { payload } = props

    if (!payload || !Array.isArray(payload)) {
      return null
    }

    return (
      <div className="flex flex-wrap justify-center gap-4 mt-4">
        {payload.map((entry, index) => (
          <div key={`legend-${index}`} className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="text-sm text-gray-700">
              {entry.value}: {entry.payload.value}%
            </span>
          </div>
        ))}
      </div>
    )
  }

  const trafficInsights = [
    "Organic search drives 40% of your traffic - focus on dental SEO keywords",
    "Social media traffic has grown 25% - increase posting frequency on Instagram",
    "Direct traffic is high - consider adding UTM parameters to track sources better",
  ]

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-8">
      <Card className="w-full bg-white rounded-xl shadow-sm border lg:col-span-8">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-xl font-bold text-headline">Traffic Sources</CardTitle>
              <CardDescription>Distribution of website traffic by source</CardDescription>
            </div>
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="w-[140px] h-8">
                <SelectValue placeholder="Select timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">Last 7 days</SelectItem>
                <SelectItem value="month">Last 30 days</SelectItem>
                <SelectItem value="quarter">Last 90 days</SelectItem>
                <SelectItem value="year">Last year</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex flex-col items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={2}
                  dataKey="value"
                  isAnimationActive={isAnimating}
                  animationDuration={1500}
                  animationEasing="ease-out"
                  labelLine={false}
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend content={<CustomLegend />} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Key metrics below the chart */}
          <div className="grid grid-cols-3 gap-4 mt-6">
            <div className="text-center">
              <p className="text-sm text-gray-500">Top Source</p>
              <p className="text-lg font-bold text-indigo-600">Organic Search</p>
              <p className="text-xs text-gray-500">40% of traffic</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-500">Fastest Growing</p>
              <p className="text-lg font-bold text-blue-500">Social Media</p>
              <p className="text-xs text-gray-500">+15% this month</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-500">Highest Conversion</p>
              <p className="text-lg font-bold text-green-500">Email</p>
              <p className="text-xs text-gray-500">4.2% conversion rate</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="lg:col-span-4">
        <InsightCard
          title="Traffic Optimization Tips"
          insights={trafficInsights}
          actionText="View Traffic Details"
          actionUrl="/analytics/traffic"
          variant="purple"
        />
      </div>
    </div>
  )
}

