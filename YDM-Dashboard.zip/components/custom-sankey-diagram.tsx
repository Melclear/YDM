"use client"

// Define the node positions manually for the patient experience journey
const nodes = [
  // First column - Starting points (dental services)
  { id: "preventive", x: 50, y: 10, width: 15, height: 15, label: "Preventive Care", value: 300 },
  { id: "restorative", x: 50, y: 30, width: 15, height: 12.5, label: "Restorative Treatments", value: 250 },
  { id: "cosmetic", x: 50, y: 47.5, width: 15, height: 10, label: "Cosmetic Dentistry", value: 200 },
  { id: "periodontal", x: 50, y: 62.5, width: 15, height: 7.5, label: "Periodontal Treatments", value: 150 },
  { id: "orthodontics", x: 50, y: 75, width: 15, height: 6, label: "Orthodontics", value: 120 },
  { id: "specialty", x: 50, y: 86, width: 15, height: 5, label: "Specialty Services", value: 100 },
  { id: "advanced", x: 50, y: 96, width: 15, height: 4, label: "Advanced Procedures", value: 80 },

  // Second column
  { id: "initial", x: 150, y: 30, width: 15, height: 27.5, label: "Initial Contact", value: 1000 },

  // Third column
  { id: "scheduling", x: 250, y: 32.5, width: 15, height: 25, label: "Appointment Scheduling", value: 900 },

  // Fourth column
  { id: "precomm", x: 350, y: 35, width: 15, height: 22.5, label: "Pre-Appointment Communication", value: 850 },

  // Fifth column
  { id: "intake", x: 450, y: 37.5, width: 15, height: 20, label: "New Patient Intake", value: 800 },

  // Sixth column
  { id: "examination", x: 550, y: 40, width: 15, height: 19, label: "Clinical Examination", value: 750 },

  // Seventh column
  { id: "planning", x: 650, y: 42.5, width: 15, height: 17.5, label: "Treatment Planning", value: 700 },

  // Eighth column
  { id: "financial", x: 750, y: 45, width: 15, height: 15, label: "Financial Discussion", value: 650 },

  // Ninth column - Split into two paths
  { id: "followup", x: 850, y: 42.5, width: 15, height: 12.5, label: "Follow-up Scheduling", value: 550 },
  { id: "exit1", x: 850, y: 70, width: 15, height: 5, label: "Exit", value: 100 },

  // Tenth column
  { id: "treatment", x: 950, y: 40, width: 15, height: 11, label: "Treatment Delivery", value: 500 },
  { id: "exit2", x: 950, y: 70, width: 15, height: 4, label: "Exit", value: 50 },

  // Eleventh column
  { id: "postvisit", x: 1050, y: 37.5, width: 15, height: 10, label: "Post-Visit Follow-up", value: 450 },

  // Twelfth column
  { id: "recall", x: 1150, y: 35, width: 15, height: 9, label: "Recall", value: 400 },

  // Thirteenth column - Split into two paths
  { id: "loyalty", x: 1250, y: 30, width: 15, height: 7.5, label: "Loyalty Program", value: 350 },
  { id: "reengagement", x: 1250, y: 50, width: 15, height: 2.5, label: "Re-engagement", value: 50 },
]

// Define the links between nodes
const links = [
  // Starting points to Initial Contact
  { source: "preventive", target: "initial", value: 300, color: "#4F46E5" },
  { source: "restorative", target: "initial", value: 250, color: "#4F46E5" },
  { source: "cosmetic", target: "initial", value: 200, color: "#4F46E5" },
  { source: "periodontal", target: "initial", value: 150, color: "#4F46E5" },
  { source: "orthodontics", target: "initial", value: 120, color: "#4F46E5" },
  { source: "specialty", target: "initial", value: 100, color: "#4F46E5" },
  { source: "advanced", target: "initial", value: 80, color: "#4F46E5" },

  // Patient journey flow
  { source: "initial", target: "scheduling", value: 900, color: "#4F46E5" },
  { source: "scheduling", target: "precomm", value: 850, color: "#4F46E5" },
  { source: "precomm", target: "intake", value: 800, color: "#4F46E5" },
  { source: "intake", target: "examination", value: 750, color: "#4F46E5" },
  { source: "examination", target: "planning", value: 700, color: "#4F46E5" },
  { source: "planning", target: "financial", value: 650, color: "#4F46E5" },

  // Split after financial discussion
  { source: "financial", target: "followup", value: 550, color: "#4F46E5" },
  { source: "financial", target: "exit1", value: 100, color: "#F43F5E" },

  // Continue patient journey
  { source: "followup", target: "treatment", value: 500, color: "#4F46E5" },
  { source: "followup", target: "exit2", value: 50, color: "#F43F5E" },

  // Final stages
  { source: "treatment", target: "postvisit", value: 450, color: "#4F46E5" },
  { source: "postvisit", target: "recall", value: 400, color: "#4F46E5" },

  // Split into loyalty and re-engagement
  { source: "recall", target: "loyalty", value: 350, color: "#10B981" },
  { source: "recall", target: "reengagement", value: 50, color: "#4F46E5" },
]

// Helper function to find a node by id
const findNode = (id) => nodes.find((node) => node.id === id)

// Helper function to create a path between two nodes
const createPath = (sourceNode, targetNode, value) => {
  // Calculate path width based on value
  const pathWidth = value / 20 // Adjust this divisor to control path width

  // Calculate path coordinates
  const startX = sourceNode.x + sourceNode.width
  const startY = sourceNode.y + sourceNode.height / 2
  const endX = targetNode.x
  const endY = targetNode.y + targetNode.height / 2

  // Create a curved path
  return `M ${startX} ${startY} 
          C ${(startX + endX) / 2} ${startY}, 
            ${(startX + endX) / 2} ${endY}, 
            ${endX} ${endY}`
}

export function CustomSankeyDiagram() {
  return (
    <div className="w-full h-[500px] overflow-auto">
      <svg width="1350" height="125" viewBox="0 0 1350 125">
        {/* Render the links first (so they're behind the nodes) */}
        {links.map((link, index) => {
          const sourceNode = findNode(link.source)
          const targetNode = findNode(link.target)

          if (!sourceNode || !targetNode) return null

          return (
            <path
              key={`link-${index}`}
              d={createPath(sourceNode, targetNode, link.value)}
              stroke={link.color}
              strokeWidth={link.value / 20}
              fill="none"
              strokeOpacity={0.3}
            />
          )
        })}

        {/* Render the nodes */}
        {nodes.map((node) => {
          // Determine node color based on position or type
          let nodeColor = "#4F46E5" // Default blue
          if (node.id === "loyalty")
            nodeColor = "#10B981" // Green for loyalty
          else if (node.id.startsWith("exit"))
            nodeColor = "#F43F5E" // Red for exits
          else if (node.x === 50) {
            // First column (service types)
            // Gradient of blues for service types
            const colors = [
              "#4338CA", // Indigo-700
              "#3730A3", // Indigo-800
              "#312E81", // Indigo-900
              "#1E40AF", // Blue-800
              "#1E3A8A", // Blue-900
              "#0369A1", // Sky-700
              "#0C4A6E", // Sky-900
            ]
            const index = nodes.findIndex((n) => n.id === node.id)
            if (index >= 0 && index < colors.length) {
              nodeColor = colors[index]
            }
          }

          return (
            <g key={`node-${node.id}`}>
              <rect
                x={node.x}
                y={node.y}
                width={node.width}
                height={node.height}
                fill={nodeColor}
                fillOpacity={0.8}
                rx={2}
              />

              {/* Node labels */}
              <text
                x={node.x < 100 ? node.x - 5 : node.x + node.width / 2}
                y={node.x < 100 ? node.y + node.height / 2 : node.y - 10}
                fontSize="10"
                textAnchor={node.x < 100 ? "end" : "middle"}
                dominantBaseline="middle"
                fill="#4B5563"
                transform={node.x < 100 ? "" : `rotate(-45, ${node.x + node.width / 2}, ${node.y - 10})`}
              >
                {node.label}
              </text>

              {/* Node values */}
              <text
                x={node.x < 100 ? node.x - 5 : node.x + node.width / 2}
                y={node.x < 100 ? node.y + node.height / 2 + 12 : node.y + node.height + 15}
                fontSize="8"
                textAnchor={node.x < 100 ? "end" : "middle"}
                dominantBaseline="middle"
                fill="#6B7280"
              >
                {node.value}
              </text>
            </g>
          )
        })}
      </svg>
    </div>
  )
}

