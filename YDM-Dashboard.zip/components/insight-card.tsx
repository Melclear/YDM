import { LightbulbIcon } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface InsightCardProps {
  title: string
  description?: string
  insights: string[]
  actionText?: string
  actionUrl?: string
  variant?: "default" | "blue" | "green" | "purple"
}

export function InsightCard({
  title,
  description,
  insights,
  actionText = "Learn More",
  actionUrl = "#",
  variant = "default",
}: InsightCardProps) {
  const getVariantStyles = () => {
    switch (variant) {
      case "blue":
        return {
          bgColor: "bg-blue-50",
          iconBg: "bg-blue-100",
          iconColor: "text-blue-600",
          borderColor: "border-blue-200",
        }
      case "green":
        return {
          bgColor: "bg-green-50",
          iconBg: "bg-green-100",
          iconColor: "text-green-600",
          borderColor: "border-green-200",
        }
      case "purple":
        return {
          bgColor: "bg-purple-50",
          iconBg: "bg-purple-100",
          iconColor: "text-purple-600",
          borderColor: "border-purple-200",
        }
      default:
        return {
          bgColor: "bg-amber-50",
          iconBg: "bg-amber-100",
          iconColor: "text-amber-600",
          borderColor: "border-amber-200",
        }
    }
  }

  const styles = getVariantStyles()

  return (
    <Card className={`${styles.bgColor} border ${styles.borderColor}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <div className={`p-1.5 rounded-full ${styles.iconBg}`}>
            <LightbulbIcon className={`h-4 w-4 ${styles.iconColor}`} />
          </div>
          <CardTitle className="text-headline text-lg">Marketing Insight</CardTitle>
        </div>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        <h3 className="font-medium text-headline mb-2">{title}</h3>
        <ul className="space-y-1 mb-4">
          {insights.map((insight, index) => (
            <li key={index} className="text-sm flex items-start gap-2">
              <span className="text-green-600 font-bold">•</span>
              <span>{insight}</span>
            </li>
          ))}
        </ul>
        <Button variant="outline" size="sm" className="w-full" asChild>
          <a href={actionUrl}>{actionText}</a>
        </Button>
      </CardContent>
    </Card>
  )
}

