"use client"

import { useState, useEffect } from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { InsightCard } from "../components/insight-card"

// Sample data for campaign performance
const data = [
  {
    name: "Spring Dental",
    leads: 124,
    conversions: 42,
    roi: 320,
  },
  {
    name: "Teeth Whitening",
    leads: 156,
    conversions: 58,
    roi: 280,
  },
  {
    name: "Invisalign",
    leads: 210,
    conversions: 68,
    roi: 310,
  },
  {
    name: "Back to School",
    leads: 98,
    conversions: 32,
    roi: 240,
  },
]

export function CampaignPerformanceChart({ isInView = false, showInsights = false }) {
  const [chartData, setChartData] = useState([])

  useEffect(() => {
    if (isInView) {
      // Animate the chart data when in view
      setChartData(data)
    } else {
      setChartData([])
    }
  }, [isInView])

  const campaignInsights = [
    "Invisalign campaign has the highest ROI (310%) - consider expanding this campaign",
    "Spring Dental campaign generates the most leads - optimize for better conversion",
    "Back to School campaign has the lowest ROI - review targeting and messaging",
  ]

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 shadow-md rounded-md">
          <p className="font-medium mb-1">{label}</p>
          <div className="text-sm">
            <p className="text-[#007CD3]">
              <span className="font-medium">Leads:</span> {payload[0].value}
            </p>
            <p className="text-[#3399E0]">
              <span className="font-medium">Conversions:</span> {payload[1].value}
            </p>
            <p className="text-[#0065AB]">
              <span className="font-medium">ROI:</span> {payload[2].value}%
            </p>
          </div>
        </div>
      )
    }
    return null
  }

  if (!showInsights) {
    return (
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={chartData}
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 20,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="name" />
          <YAxis yAxisId="left" orientation="left" stroke="#007CD3" />
          <YAxis yAxisId="right" orientation="right" stroke="#0065AB" />
          <Tooltip content={<CustomTooltip />} />
          <Legend />
          <Bar
            yAxisId="left"
            dataKey="leads"
            name="Leads"
            fill="#007CD3"
            radius={[4, 4, 0, 0]}
            animationDuration={1500}
            animationBegin={0}
          />
          <Bar
            yAxisId="left"
            dataKey="conversions"
            name="Conversions"
            fill="#3399E0"
            radius={[4, 4, 0, 0]}
            animationDuration={1500}
            animationBegin={300}
          />
          <Bar
            yAxisId="right"
            dataKey="roi"
            name="ROI (%)"
            fill="#0065AB"
            radius={[4, 4, 0, 0]}
            animationDuration={1500}
            animationBegin={600}
          />
        </BarChart>
      </ResponsiveContainer>
    )
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <div className="lg:col-span-8 h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={chartData}
            margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 20,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="name" />
            <YAxis yAxisId="left" orientation="left" stroke="#007CD3" />
            <YAxis yAxisId="right" orientation="right" stroke="#0065AB" />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar
              yAxisId="left"
              dataKey="leads"
              name="Leads"
              fill="#007CD3"
              radius={[4, 4, 0, 0]}
              animationDuration={1500}
              animationBegin={0}
            />
            <Bar
              yAxisId="left"
              dataKey="conversions"
              name="Conversions"
              fill="#3399E0"
              radius={[4, 4, 0, 0]}
              animationDuration={1500}
              animationBegin={300}
            />
            <Bar
              yAxisId="right"
              dataKey="roi"
              name="ROI (%)"
              fill="#0065AB"
              radius={[4, 4, 0, 0]}
              animationDuration={1500}
              animationBegin={600}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="lg:col-span-4">
        <InsightCard
          title="Campaign Optimization Tips"
          insights={campaignInsights}
          actionText="View Campaign Details"
          actionUrl="/campaigns"
        />
      </div>
    </div>
  )
}

