import { TrendingUp, ArrowUpRight, ArrowDownRight } from "lucide-react"

export function MobileHealthTrend() {
  return (
    <div className="md:hidden bg-white p-4 rounded-lg border border-gray-200 mb-6">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-bold text-gray-800">Health Trends</h3>
        <div className="flex items-center gap-1">
          <TrendingUp size={14} className="text-blue-600" />
          <span className="text-xs font-medium text-blue-600">Good</span>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Marketing</span>
          <div className="flex items-center gap-1 text-green-500">
            <ArrowUpRight size={14} />
            <span className="text-xs font-medium">12.5%</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Analytics</span>
          <div className="flex items-center gap-1 text-red-500">
            <ArrowDownRight size={14} />
            <span className="text-xs font-medium">3.2%</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Patient</span>
          <div className="flex items-center gap-1 text-green-500">
            <ArrowUpRight size={14} />
            <span className="text-xs font-medium">8.7%</span>
          </div>
        </div>
      </div>
    </div>
  )
}

