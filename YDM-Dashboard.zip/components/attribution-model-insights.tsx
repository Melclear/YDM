import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LightbulbIcon } from "lucide-react"

export function AttributionModelInsights() {
  return (
    <Card className="bg-amber-50 border border-amber-200">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-full bg-amber-100">
            <LightbulbIcon className="h-4 w-4 text-amber-600" />
          </div>
          <CardTitle className="text-headline text-lg">Attribution Model Guide</CardTitle>
        </div>
        <CardDescription>Understanding which model works best for your practice</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="font-medium text-headline mb-1">First-Touch Attribution</h3>
            <p className="text-sm text-gray-600">
              Best for: Understanding which channels are most effective at generating initial awareness.
              <br />
              <span className="text-amber-600 font-medium">Tip:</span> Use for brand awareness campaigns.
            </p>
          </div>

          <div>
            <h3 className="font-medium text-headline mb-1">Last-Touch Attribution</h3>
            <p className="text-sm text-gray-600">
              Best for: Identifying which channels drive final conversions.
              <br />
              <span className="text-amber-600 font-medium">Tip:</span> Use for conversion-focused campaigns.
            </p>
          </div>

          <div>
            <h3 className="font-medium text-headline mb-1">Linear Attribution</h3>
            <p className="text-sm text-gray-600">
              Best for: Getting a balanced view of all touchpoints.
              <br />
              <span className="text-amber-600 font-medium">Tip:</span> Use when patient journey involves multiple equal
              touchpoints.
            </p>
          </div>

          <div>
            <h3 className="font-medium text-headline mb-1">Time-Decay Attribution</h3>
            <p className="text-sm text-gray-600">
              Best for: Emphasizing recent interactions that led to conversion.
              <br />
              <span className="text-amber-600 font-medium">Tip:</span> Use for longer sales cycles with multiple
              touchpoints.
            </p>
          </div>

          <div>
            <h3 className="font-medium text-headline mb-1">Position-Based Attribution</h3>
            <p className="text-sm text-gray-600">
              Best for: Highlighting first interaction and final conversion points.
              <br />
              <span className="text-amber-600 font-medium">Tip:</span> Use when initial awareness and final conversion
              are most important.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

