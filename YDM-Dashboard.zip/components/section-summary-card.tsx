import type React from "react"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

type SectionSummaryCardProps = {
  title: string
  description: string
  metrics: {
    label: string
    value: string
    change?: {
      value: number
      isPositive: boolean
    }
  }[]
  icon: React.ReactNode
  bgColor: string
  textColor: string
  linkHref: string
}

export function SectionSummaryCard({
  title,
  description,
  metrics,
  icon,
  bgColor,
  textColor,
  linkHref,
}: SectionSummaryCardProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className={`${bgColor} ${textColor} p-4 flex justify-between items-center`}>
        <div>
          <h3 className={`font-bold text-lg ${bgColor === "bg-white" ? "text-black" : ""}`}>{title}</h3>
          <p className="text-sm opacity-90">{description}</p>
        </div>
        <div className="p-2 rounded-full bg-white/20">{icon}</div>
      </div>

      <div className="p-4">
        <div className="grid grid-cols-2 gap-4 mb-4">
          {metrics.map((metric, index) => (
            <div key={index} className="space-y-1">
              <p className="text-gray-500 text-xs">{metric.label}</p>
              <div className="flex items-center gap-2">
                <span className="font-bold text-gray-800">{metric.value}</span>
                {metric.change && (
                  <span className={`text-xs ${metric.change.isPositive ? "text-green-500" : "text-red-500"}`}>
                    {metric.change.isPositive ? "+" : ""}
                    {metric.change.value}%
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        <Link
          href={linkHref}
          className="flex items-center text-sm font-medium text-blue-600 hover:text-blue-800 transition-colors"
        >
          View details
          <ArrowRight size={14} className="ml-1" />
        </Link>
      </div>
    </div>
  )
}

