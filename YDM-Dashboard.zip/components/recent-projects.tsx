import { ChevronDown } from "lucide-react"

export function RecentProjects() {
  return (
    <div className="col-span-12 lg:col-span-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Your Recent Projects</h2>
        <a href="#" className="text-xs text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
          See all Project
        </a>
      </div>

      {/* Project Cards */}
      <div className="space-y-4">
        {/* Web Development Project */}
        <div className="bg-white rounded-xl p-4 shadow-sm border relative">
          <div className="flex justify-between">
            <div className="flex gap-3">
              <div className="h-10 w-10 bg-red-500 rounded-md flex items-center justify-center text-white">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M10 13C10.4295 13.5741 10.9774 14.0492 11.6066 14.3929C12.2357 14.7367 12.9315 14.9411 13.6467 14.9923C14.3618 15.0435 15.0796 14.9404 15.7513 14.6898C16.4231 14.4392 17.0331 14.0471 17.54 13.54L20.54 10.54C21.4774 9.59751 22.0074 8.33297 22.0074 7.01499C22.0074 5.69702 21.4774 4.43247 20.54 3.48999C19.5975 2.54751 18.333 2.01758 17.015 2.01758C15.697 2.01758 14.4325 2.54751 13.49 3.48999L12 4.99999"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M14 11C13.5705 10.4259 13.0226 9.95082 12.3935 9.60706C11.7643 9.2633 11.0685 9.05889 10.3534 9.00768C9.63821 8.95646 8.92041 9.05964 8.24866 9.31023C7.5769 9.56082 6.96689 9.95294 6.46 10.46L3.46 13.46C2.52252 14.4025 1.99259 15.667 1.99259 16.985C1.99259 18.303 2.52252 19.5675 3.46 20.51C4.40249 21.4525 5.66703 21.9824 6.98501 21.9824C8.30298 21.9824 9.56752 21.4525 10.51 20.51L12 19"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Web Development Project</h3>
                <p className="text-sm text-gray-500">$10/hour</p>
              </div>
            </div>
            <span className="px-2 py-1 bg-gray-800 text-white text-xs rounded-md">Paid</span>
          </div>
          <div className="flex gap-2 mt-3">
            <span className="px-3 py-1 bg-gray-100 text-xs rounded-md">Remote</span>
            <span className="px-3 py-1 bg-gray-100 text-xs rounded-md">Part-time</span>
          </div>
          <p className="text-sm text-gray-600 mt-3">
            This project involves implementing both frontend and backend functionalities, as well as integrating with
            third-party APIs.
          </p>
          <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
            <div className="flex items-center gap-1">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path d="M2 12H22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <path
                  d="M12 2C14.5013 4.73835 15.9228 8.29203 16 12C15.9228 15.708 14.5013 19.2616 12 22C9.49872 19.2616 8.07725 15.708 8 12C8.07725 8.29203 9.49872 4.73835 12 2Z"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              Germany
            </div>
            <div className="flex items-center gap-1">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M12 8V12L15 15"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M3.05 11C3.27151 8.68261 4.51919 6.56428 6.45867 5.16043C8.39815 3.75659 10.8556 3.18605 13.2035 3.58647C15.5513 3.98689 17.6074 5.32406 18.9531 7.29164C20.2989 9.25921 20.8283 11.6915 20.4182 14.0401C20.0081 16.3888 18.6883 18.4515 16.7372 19.8133C14.786 21.1751 12.3594 21.7634 10.0067 21.3913C7.65396 21.0191 5.58389 19.7159 4.2199 17.7666C2.85591 15.8173 2.30821 13.3917 2.7 11.05"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              2h ago
            </div>
          </div>
          <button className="absolute top-4 right-4">
            <ChevronDown className="h-4 w-4" />
          </button>
        </div>

        {/* Copyright Project */}
        <div className="bg-white rounded-xl p-4 shadow-sm border relative">
          <div className="flex justify-between">
            <div className="flex gap-3">
              <div className="h-10 w-10 bg-gray-800 rounded-md flex items-center justify-center text-white">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M14.31 8L20.05 17.94"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M9.69 8H21.17"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M7.38 12.0001L13.12 2.06006"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M9.69 16.0001L3.95 6.06006"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M14.31 16H2.83"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M16.62 12L10.88 21.94"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Copyright Project</h3>
                <p className="text-sm text-gray-500">$10/hour</p>
              </div>
            </div>
            <span className="px-2 py-1 bg-gray-200 text-gray-700 text-xs rounded-md">Not Paid</span>
          </div>
          <button className="absolute top-4 right-4">
            <ChevronDown className="h-4 w-4" />
          </button>
        </div>

        {/* Web Design Project */}
        <div className="bg-white rounded-xl p-4 shadow-sm border relative">
          <div className="flex justify-between">
            <div className="flex gap-3">
              <div className="h-10 w-10 bg-blue-500 rounded-md flex items-center justify-center text-white">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M2 9.88L11.28 5.12C11.7223 4.89776 12.2777 4.89776 12.72 5.12L22 9.88"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M20 16.5V7.5L12 3L4 7.5V16.5L12 21L20 16.5Z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M12 12L20 7.5"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M12 12V21"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M12 12L4 7.5"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Web Design Project</h3>
                <p className="text-sm text-gray-500">$10/hour</p>
              </div>
            </div>
            <span className="px-2 py-1 bg-gray-800 text-white text-xs rounded-md">Paid</span>
          </div>
          <button className="absolute top-4 right-4">
            <ChevronDown className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  )
}

