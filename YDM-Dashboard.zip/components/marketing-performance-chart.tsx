"use client"

import { useState, useEffect } from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip, Legend } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { InsightCard } from "@/components/ui/insight-card"

// Sample marketing performance data
const initialData = [
  { channel: "Social Media", performance: 0, target: 85 },
  { channel: "Email", performance: 0, target: 75 },
  { channel: "SEO", performance: 0, target: 65 },
  { channel: "PPC", performance: 0, target: 60 },
  { channel: "Content", performance: 0, target: 70 },
  { channel: "Events", performance: 0, target: 50 },
]

const actualData = [
  { channel: "Social Media", performance: 78, target: 85 },
  { channel: "Email", performance: 65, target: 75 },
  { channel: "SEO", performance: 58, target: 65 },
  { channel: "PPC", performance: 52, target: 60 },
  { channel: "Content", performance: 62, target: 70 },
  { channel: "Events", performance: 45, target: 50 },
]

export function MarketingPerformanceChart() {
  const [data, setData] = useState(initialData)
  const [isAnimating, setIsAnimating] = useState(true)
  const [dateRange, setDateRange] = useState("30days")

  const marketingInsights = [
    "Your SEO campaigns are outperforming targets by 15% - consider increasing budget allocation",
    "Content marketing shows the highest ROI at 290% - create more educational dental content",
    "Email campaigns have the highest conversion rate - increase frequency to 2x monthly",
  ]

  const handleDateRangeChange = (value: string) => {
    setDateRange(value)
    // In a real application, you would fetch new data based on the selected date range
    // For this demo, we'll just use the same data
  }

  useEffect(() => {
    // Animate the bars on initial load
    const timer = setTimeout(() => {
      setData(actualData)
      setIsAnimating(false)
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 shadow-md rounded-md">
          <p className="font-medium">{label}</p>
          <p className="text-sm text-[#007CD3]">
            <span className="font-medium">Performance:</span> {payload[0].value}%
          </p>
          <p className="text-sm text-gray-500">
            <span className="font-medium">Target:</span> {payload[1].value}%
          </p>
        </div>
      )
    }
    return null
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-8">
      <Card className="w-full bg-white rounded-xl shadow-sm border lg:col-span-8">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl font-bold text-headline">Marketing Performance</CardTitle>
              <CardDescription>Channel performance vs targets</CardDescription>
            </div>
            <div className="flex items-center gap-4">
              <Select value={dateRange} onValueChange={handleDateRangeChange}>
                <SelectTrigger className="w-[180px] h-8">
                  <SelectValue placeholder="Select date range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7days">Last 7 days</SelectItem>
                  <SelectItem value="30days">Last 30 days</SelectItem>
                  <SelectItem value="90days">Last 90 days</SelectItem>
                  <SelectItem value="year">Last year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={data}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 20,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="channel" axisLine={false} tickLine={false} tick={{ fill: "#6B7280", fontSize: 12 }} />
                <YAxis
                  yAxisId="left"
                  orientation="left"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#6B7280", fontSize: 12 }}
                  domain={[0, 100]}
                  tickFormatter={(value) => `${value}%`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar
                  yAxisId="left"
                  dataKey="performance"
                  name="Performance"
                  fill="#007CD3" // Dark blue - matches project analytics
                  radius={[4, 4, 0, 0]}
                  isAnimationActive={isAnimating}
                  animationDuration={1500}
                  animationEasing="ease-out"
                  barSize={30}
                />
                <Bar
                  yAxisId="left"
                  dataKey="target"
                  name="Target"
                  fill="#E5E7EB" // Light gray for target
                  radius={[4, 4, 0, 0]}
                  isAnimationActive={isAnimating}
                  animationDuration={1500}
                  animationEasing="ease-out"
                  barSize={30}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Legend moved beneath the graph */}
          <div className="flex items-center justify-center gap-8 mt-4">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-[#007CD3]"></div>
              <span className="text-sm text-gray-500">Performance</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-gray-300"></div>
              <span className="text-sm text-gray-500">Target</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="lg:col-span-4">
        <InsightCard
          title="Performance Insights"
          insights={marketingInsights}
          actionText="Optimize Campaigns"
          actionUrl="/campaigns"
          variant="blue"
        />
      </div>
    </div>
  )
}

