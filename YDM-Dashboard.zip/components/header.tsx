import { Search } from "lucide-react"
import Image from "next/image"
import { SettingsIcon, NotificationIcon } from "./ui-icons"

export function Header() {
  return (
    <header className="flex items-center justify-between px-6 py-4 border-b">
      <div className="flex items-center gap-12">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 bg-red-500 rounded-full flex items-center justify-center">
            <span className="text-white font-bold">T</span>
          </div>
          <span className="font-bold">TWISTY</span>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          <a href="#" className="text-gray-900 font-medium">
            Home
          </a>
          <a href="#" className="text-gray-500">
            Messages
          </a>
          <a href="#" className="text-gray-500">
            Discover
          </a>
          <a href="#" className="text-gray-500">
            Wallet
          </a>
          <a href="#" className="text-gray-500">
            Projects
          </a>
        </nav>
      </div>
      <div className="flex items-center gap-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Enter your search request..."
            className="pl-4 pr-10 py-2 bg-gray-100 rounded-full w-64 text-sm"
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
        <button className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center">
          <span className="sr-only">Settings</span>
          <SettingsIcon />
        </button>
        <button className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center">
          <span className="sr-only">Notifications</span>
          <NotificationIcon />
        </button>
        <div className="h-8 w-8 rounded-full bg-gray-300 overflow-hidden">
          <Image
            src="/placeholder.svg?height=32&width=32"
            alt="Profile"
            width={32}
            height={32}
            className="object-cover"
          />
        </div>
      </div>
    </header>
  )
}

