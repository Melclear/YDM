import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

export function CompetitorComparison() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Competitor Reputation Analysis</CardTitle>
          <CardDescription>Compare your online reputation with local competitors</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="overview">
            <TabsList className="mb-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
              <TabsTrigger value="mentions">Mentions</TabsTrigger>
              <TabsTrigger value="social">Social Media</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="rounded-lg border p-4">
                <h3 className="text-lg font-medium">Reputation Score Comparison</h3>
                <div className="mt-4 space-y-6">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge className="bg-blue-500">Your Practice</Badge>
                        <span className="font-medium">Bright Smile Dental</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">87/100</span>
                        <Badge variant="outline" className="flex items-center gap-1 text-green-500">
                          <TrendingUp className="h-3 w-3" />
                          <span>+4</span>
                        </Badge>
                      </div>
                    </div>
                    <Progress value={87} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Competitor</Badge>
                        <span className="font-medium">City Dental Care</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">82/100</span>
                        <Badge variant="outline" className="flex items-center gap-1 text-green-500">
                          <TrendingUp className="h-3 w-3" />
                          <span>+2</span>
                        </Badge>
                      </div>
                    </div>
                    <Progress value={82} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Competitor</Badge>
                        <span className="font-medium">Smile Perfect Dentistry</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">90/100</span>
                        <Badge variant="outline" className="flex items-center gap-1 text-green-500">
                          <TrendingUp className="h-3 w-3" />
                          <span>+5</span>
                        </Badge>
                      </div>
                    </div>
                    <Progress value={90} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Competitor</Badge>
                        <span className="font-medium">Family Dental Associates</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">79/100</span>
                        <Badge variant="outline" className="flex items-center gap-1 text-red-500">
                          <TrendingDown className="h-3 w-3" />
                          <span>-2</span>
                        </Badge>
                      </div>
                    </div>
                    <Progress value={79} className="h-2" />
                  </div>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Review Rating</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold">4.7</div>
                        <p className="text-xs text-muted-foreground">Industry avg: 4.5</p>
                      </div>
                      <Badge variant="outline" className="flex items-center gap-1 text-green-500">
                        <TrendingUp className="h-3 w-3" />
                        <span>Above Avg</span>
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Review Volume</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold">347</div>
                        <p className="text-xs text-muted-foreground">Industry avg: 280</p>
                      </div>
                      <Badge variant="outline" className="flex items-center gap-1 text-green-500">
                        <TrendingUp className="h-3 w-3" />
                        <span>Above Avg</span>
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Response Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold">92%</div>
                        <p className="text-xs text-muted-foreground">Industry avg: 75%</p>
                      </div>
                      <Badge variant="outline" className="flex items-center gap-1 text-green-500">
                        <TrendingUp className="h-3 w-3" />
                        <span>Above Avg</span>
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="rounded-lg border p-4">
                <h3 className="text-lg font-medium">Competitive Strengths & Weaknesses</h3>
                <div className="mt-4 grid gap-4 md:grid-cols-2">
                  <div>
                    <h4 className="font-medium text-green-600">Your Strengths</h4>
                    <ul className="mt-2 space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <TrendingUp className="mt-0.5 h-4 w-4 text-green-500" />
                        <span>Higher patient satisfaction scores for staff friendliness</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <TrendingUp className="mt-0.5 h-4 w-4 text-green-500" />
                        <span>More positive mentions in local news media</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <TrendingUp className="mt-0.5 h-4 w-4 text-green-500" />
                        <span>Better response rate to patient reviews</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <TrendingUp className="mt-0.5 h-4 w-4 text-green-500" />
                        <span>Higher ratings for pediatric dental services</span>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium text-red-600">Areas for Improvement</h4>
                    <ul className="mt-2 space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <TrendingDown className="mt-0.5 h-4 w-4 text-red-500" />
                        <span>Lower ratings for appointment wait times</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <TrendingDown className="mt-0.5 h-4 w-4 text-red-500" />
                        <span>More negative mentions about insurance processing</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <TrendingDown className="mt-0.5 h-4 w-4 text-red-500" />
                        <span>Fewer directory listings than top competitor</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Minus className="mt-0.5 h-4 w-4 text-amber-500" />
                        <span>Similar ratings for cosmetic dentistry services</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="reviews">
              <div className="space-y-4">
                <div className="rounded-lg border p-4">
                  <h3 className="text-lg font-medium">Review Rating Comparison</h3>
                  <div className="mt-4 space-y-4">
                    {/* Review comparison content would go here */}
                    <p className="text-muted-foreground">
                      Detailed review comparison data by platform and service category
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="mentions">
              <div className="space-y-4">
                <div className="rounded-lg border p-4">
                  <h3 className="text-lg font-medium">Mention Comparison</h3>
                  <div className="mt-4 space-y-4">
                    {/* Mentions comparison content would go here */}
                    <p className="text-muted-foreground">
                      Detailed comparison of online mentions across news, blogs, and directories
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="social">
              <div className="space-y-4">
                <div className="rounded-lg border p-4">
                  <h3 className="text-lg font-medium">Social Media Comparison</h3>
                  <div className="mt-4 space-y-4">
                    {/* Social media comparison content would go here */}
                    <p className="text-muted-foreground">
                      Detailed comparison of social media presence, engagement, and sentiment
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Competitive Recommendations</CardTitle>
          <CardDescription>Actionable insights to improve your competitive position</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="rounded-lg border p-3">
              <h4 className="font-medium">Improve Insurance Processing</h4>
              <p className="mt-1 text-sm text-muted-foreground">
                Your practice has 15% more negative mentions about insurance processing than competitors. Consider staff
                training or process improvements.
              </p>
              <Button variant="outline" size="sm" className="mt-2">
                View Action Plan
              </Button>
            </div>

            <div className="rounded-lg border p-3">
              <h4 className="font-medium">Expand Directory Listings</h4>
              <p className="mt-1 text-sm text-muted-foreground">
                Top competitor has presence on 3 more dental directories. Expanding your listings could increase
                visibility.
              </p>
              <Button variant="outline" size="sm" className="mt-2">
                View Directories
              </Button>
            </div>

            <div className="rounded-lg border p-3">
              <h4 className="font-medium">Highlight Pediatric Services</h4>
              <p className="mt-1 text-sm text-muted-foreground">
                Your practice rates 12% higher for pediatric services. Consider featuring this more prominently in
                marketing.
              </p>
              <Button variant="outline" size="sm" className="mt-2">
                Create Campaign
              </Button>
            </div>

            <div className="rounded-lg border p-3">
              <h4 className="font-medium">Address Wait Times</h4>
              <p className="mt-1 text-sm text-muted-foreground">
                Wait times are mentioned negatively 20% more often than competitors. Review scheduling practices.
              </p>
              <Button variant="outline" size="sm" className="mt-2">
                View Recommendations
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

