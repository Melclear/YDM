import { Calendar, ChevronDown } from "lucide-react"

export function ProposalProgress() {
  return (
    <div className="col-span-12 md:col-span-4 lg:col-span-5 bg-white rounded-xl p-6 shadow-sm border">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Proposal Progress</h2>
        <div className="flex items-center gap-1 text-sm text-gray-500">
          <Calendar className="h-4 w-4" />
          <span>April 11, 2024</span>
          <ChevronDown className="h-4 w-4" />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4 mb-4">
        <div className="text-center">
          <h3 className="text-3xl font-bold">64</h3>
          <p className="text-sm text-gray-500">Proposals sent</p>
        </div>
        <div className="text-center">
          <h3 className="text-3xl font-bold">12</h3>
          <p className="text-sm text-gray-500">Interviews</p>
        </div>
        <div className="text-center">
          <h3 className="text-3xl font-bold">10</h3>
          <p className="text-sm text-gray-500">Hires</p>
        </div>
      </div>
      <div className="flex items-end h-20 gap-1">
        {/* Proposals chart */}
        {Array.from({ length: 10 }).map((_, i) => (
          <div
            key={`proposal-${i}`}
            className="flex-1 bg-gray-200 rounded-sm"
            style={{ height: `${Math.floor(Math.random() * 60) + 20}%` }}
          ></div>
        ))}
        {/* Interviews chart */}
        {Array.from({ length: 10 }).map((_, i) => (
          <div
            key={`interview-${i}`}
            className="flex-1 bg-red-400 rounded-sm"
            style={{ height: `${Math.floor(Math.random() * 40) + 10}%` }}
          ></div>
        ))}
        {/* Hires chart */}
        {Array.from({ length: 10 }).map((_, i) => (
          <div
            key={`hire-${i}`}
            className="flex-1 bg-gray-800 rounded-sm"
            style={{ height: `${Math.floor(Math.random() * 30) + 5}%` }}
          ></div>
        ))}
      </div>
    </div>
  )
}

