import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MailIcon, TrendingUpIcon } from "lucide-react"

export function EmailMarketingTips() {
  return (
    <Card className="bg-gradient-to-br from-green-50 to-teal-50 border border-green-200">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-full bg-green-100">
            <MailIcon className="h-4 w-4 text-green-600" />
          </div>
          <CardTitle className="text-headline text-lg">Email Marketing Tips</CardTitle>
        </div>
        <CardDescription>Optimize your dental email campaigns</CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-1 mb-4">
          <li className="text-sm flex items-start gap-2">
            <TrendingUpIcon className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
            <span>Use personalized subject lines to increase open rates by 26%</span>
          </li>
          <li className="text-sm flex items-start gap-2">
            <TrendingUpIcon className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
            <span>Send appointment reminders 48 hours in advance for best results</span>
          </li>
          <li className="text-sm flex items-start gap-2">
            <TrendingUpIcon className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
            <span>Include before/after images to boost click-through rates</span>
          </li>
          <li className="text-sm flex items-start gap-2">
            <TrendingUpIcon className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
            <span>Tuesday and Thursday mornings have the highest open rates</span>
          </li>
        </ul>
        <div className="text-xs text-gray-500 mt-2">
          <p>Based on dental industry email marketing benchmarks for 2024.</p>
        </div>
      </CardContent>
    </Card>
  )
}

