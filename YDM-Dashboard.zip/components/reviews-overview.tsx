import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Star, ThumbsUp, AlertCircle } from "lucide-react"

export function ReviewsOverview() {
  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Reviews Summary</CardTitle>
        <CardDescription>Overview of all reviews across platforms</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
          <div className="flex items-center justify-center">
            <span className="text-5xl font-bold">4.7</span>
            <div className="ml-2 flex flex-col items-start">
              <div className="flex text-yellow-400">
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current stroke-yellow-400" />
              </div>
              <span className="text-sm text-muted-foreground">347 reviews</span>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center">
              <div className="flex text-yellow-400">
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
              </div>
              <span className="ml-2">5 stars</span>
            </div>
            <span className="font-medium">243</span>
          </div>
          <Progress value={70} className="h-2" />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center">
              <div className="flex text-yellow-400">
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
              </div>
              <span className="ml-2">4 stars</span>
            </div>
            <span className="font-medium">76</span>
          </div>
          <Progress value={22} className="h-2" />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center">
              <div className="flex text-yellow-400">
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
              </div>
              <span className="ml-2">3 stars</span>
            </div>
            <span className="font-medium">18</span>
          </div>
          <Progress value={5} className="h-2" />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center">
              <div className="flex text-yellow-400">
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
              </div>
              <span className="ml-2">2 stars</span>
            </div>
            <span className="font-medium">7</span>
          </div>
          <Progress value={2} className="h-2" />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center">
              <div className="flex text-yellow-400">
                <Star className="h-4 w-4 fill-current" />
              </div>
              <span className="ml-2">1 star</span>
            </div>
            <span className="font-medium">3</span>
          </div>
          <Progress value={1} className="h-2" />
        </div>

        <div className="space-y-4 rounded-lg bg-muted p-4">
          <h4 className="font-medium">Common Themes</h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <ThumbsUp className="mr-2 h-4 w-4 text-green-500" />
                <span className="text-sm">Friendly staff</span>
              </div>
              <span className="text-sm font-medium">87%</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <ThumbsUp className="mr-2 h-4 w-4 text-green-500" />
                <span className="text-sm">Clean facility</span>
              </div>
              <span className="text-sm font-medium">82%</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <ThumbsUp className="mr-2 h-4 w-4 text-green-500" />
                <span className="text-sm">Gentle care</span>
              </div>
              <span className="text-sm font-medium">78%</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <AlertCircle className="mr-2 h-4 w-4 text-red-500" />
                <span className="text-sm">Wait times</span>
              </div>
              <span className="text-sm font-medium">12%</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <AlertCircle className="mr-2 h-4 w-4 text-red-500" />
                <span className="text-sm">Insurance issues</span>
              </div>
              <span className="text-sm font-medium">8%</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

