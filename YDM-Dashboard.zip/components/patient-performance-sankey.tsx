"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, CheckCircle, Smile } from "lucide-react"
import { CustomSankeyDiagram } from "./custom-sankey-diagram"
import { InsightCard } from "./insight-card"

// Updated dropoff data to match the dental patient journey with service categories
const dropoffData = [
  { stage: "Service Selection", rate: "0%", count: "(1200)", color: "#4F46E5" },
  { stage: "Initial Contact", rate: "10%", count: "(100)", color: "#F43F5E" },
  { stage: "Scheduling", rate: "5.6%", count: "(50)", color: "#F43F5E" },
  { stage: "Examination", rate: "6.7%", count: "(50)", color: "#F43F5E" },
  { stage: "Financial", rate: "15.4%", count: "(100)", color: "#F43F5E" },
  { stage: "Treatment", rate: "10%", count: "(50)", color: "#F43F5E" },
  { stage: "Loyalty", rate: "87.5%", count: "(350)", isConversion: true, color: "#10B981" },
]

export function PatientPerformanceSankey() {
  const patientJourneyInsights = [
    "87.5% of patients who complete treatment join your loyalty program",
    "The biggest drop-off (15.4%) occurs during financial discussions - consider revising your payment options",
    "Preventive care patients have the highest retention rate - focus on recall scheduling",
  ]

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-8">
      <Card className="w-full bg-white rounded-xl shadow-sm border lg:col-span-8">
        <CardHeader className="pb-0">
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl font-bold text-headline">Patient Experience</CardTitle>
              <CardDescription>Patient journey conversion flow by service type</CardDescription>
            </div>
          </div>

          {/* Metrics at the top */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-indigo-100 rounded-full">
                <Smile className="h-5 w-5 text-indigo-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-indigo-600">TOTAL PATIENTS</p>
                <p className="text-xl font-bold">1200</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="p-2 bg-indigo-100 rounded-full">
                <Users className="h-5 w-5 text-indigo-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-indigo-600">RETENTION</p>
                <p className="text-xl font-bold">87.5%</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="p-2 bg-indigo-100 rounded-full">
                <CheckCircle className="h-5 w-5 text-indigo-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-indigo-600">LOYALTY PROGRAM</p>
                <p className="text-xl font-bold">350</p>
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          <div className="h-[250px] mt-4 overflow-x-auto">
            <CustomSankeyDiagram />
          </div>

          {/* Dropoff rates at the bottom */}
          <div className="grid grid-cols-7 gap-2 mt-4">
            {dropoffData.map((item, index) => (
              <div key={index} className="flex flex-col items-center">
                <div
                  className={`p-2 rounded-full ${item.isConversion ? "bg-green-100" : item.color === "#4F46E5" ? "bg-indigo-100" : "bg-red-100"}`}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke={item.color}
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    {item.isConversion ? (
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                    ) : (
                      <path d="M12 5v14"></path>
                    )}
                    {item.isConversion ? (
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    ) : (
                      <path d="M19 12l-7 7-7-7"></path>
                    )}
                  </svg>
                </div>
                <p className="text-xs font-medium mt-1 text-center">{item.isConversion ? "CONVERSION" : "DROPOFF"}</p>
                <p className={`text-lg font-bold`} style={{ color: item.color }}>
                  {item.rate}
                </p>
                <p className="text-xs text-gray-500">{item.count}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="lg:col-span-4">
        <InsightCard
          title="Patient Journey Insights"
          insights={patientJourneyInsights}
          actionText="Improve Patient Experience"
          actionUrl="/patient/journey"
          variant="green"
        />
      </div>
    </div>
  )
}

