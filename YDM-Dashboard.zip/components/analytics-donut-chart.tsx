"use client"

import { useState, useEffect } from "react"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, Label } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useInView } from "../hooks/use-in-view"

// Sample analytics performance data
const initialData = [
  { name: "Website Traffic", value: 0, color: "#007CD3" },
  { name: "Social Engagement", value: 0, color: "#3399E0" },
  { name: "Email Campaigns", value: 0, color: "#0065AB" },
  { name: "Organic Search", value: 0, color: "#B4D0E7" },
]

const actualData = [
  { name: "Website Traffic", value: 42, color: "#007CD3" },
  { name: "Social Engagement", value: 28, color: "#3399E0" },
  { name: "Email Campaigns", value: 18, color: "#0065AB" },
  { name: "Organic Search", value: 12, color: "#B4D0E7" },
]

export function AnalyticsDonutChart() {
  const [data, setData] = useState(initialData)
  const [isAnimating, setIsAnimating] = useState(true)
  const { ref, isInView } = useInView()
  const [isSpinning, setIsSpinning] = useState(false)

  useEffect(() => {
    // Only start animation when the chart is in view
    if (isInView) {
      // First start the spinning animation
      setIsSpinning(true)

      // After a short delay, start the data animation
      const dataTimer = setTimeout(() => {
        setData(actualData)
        setIsAnimating(false)

        // After data animation completes, stop spinning
        const spinTimer = setTimeout(() => {
          setIsSpinning(false)
        }, 1500)

        return () => clearTimeout(spinTimer)
      }, 1000)

      return () => clearTimeout(dataTimer)
    }
  }, [isInView])

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 shadow-md rounded-md">
          <p className="font-medium" style={{ color: payload[0].payload.color }}>
            {payload[0].name}
          </p>
          <p className="text-sm text-gray-700">
            <span className="font-medium">Value:</span> {payload[0].value}%
          </p>
        </div>
      )
    }
    return null
  }

  // Fixed CustomLegend component to properly handle the payload from Recharts
  const CustomLegend = (props) => {
    const { payload } = props

    if (!payload || !Array.isArray(payload)) {
      return null
    }

    return (
      <div className="flex flex-wrap justify-center gap-4 mt-4">
        {payload.map((entry, index) => (
          <div key={`legend-${index}`} className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="text-sm text-gray-700">
              {entry.value}: {entry.payload.value}%
            </span>
          </div>
        ))}
      </div>
    )
  }

  return (
    <Card className="w-full bg-white rounded-xl shadow-sm border mb-8">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-2xl font-bold">Analytics</CardTitle>
            <CardDescription>Distribution of traffic and engagement sources</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div ref={ref} className="h-80 flex flex-col items-center">
          <div className={`w-full h-full ${isSpinning ? "animate-spin-slow" : ""}`}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={120}
                  paddingAngle={2}
                  dataKey="value"
                  isAnimationActive={isAnimating}
                  animationDuration={1500}
                  animationEasing="ease-out"
                  labelLine={false}
                  label={({ cx, cy, midAngle, innerRadius, outerRadius, percent, index, name }) => {
                    const radius = innerRadius + (outerRadius - innerRadius) * 1.4
                    const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180))
                    const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180))
                    return (
                      <text
                        x={x}
                        y={y}
                        fill={data[index].color}
                        textAnchor={x > cx ? "start" : "end"}
                        dominantBaseline="central"
                        fontWeight="bold"
                      >
                        {`${data[index].name} (${(percent * 100).toFixed(0)}%)`}
                      </text>
                    )
                  }}
                  labelLine={{
                    stroke: "#888",
                    strokeWidth: 1,
                    strokeDasharray: "2,2",
                  }}
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                  <Label
                    position="center"
                    content={({ viewBox }) => {
                      const { cx, cy } = viewBox
                      return (
                        <text x={cx} y={cy} textAnchor="middle" dominantBaseline="middle">
                          <tspan x={cx} y={cy} dy="-0.5em" fontSize="24" fontWeight="bold" fill="#333">
                            100%
                          </tspan>
                          <tspan x={cx} y={cy} dy="1.5em" fontSize="14" fill="#666">
                            Total
                          </tspan>
                        </text>
                      )
                    }}
                  />
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend content={<CustomLegend />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

