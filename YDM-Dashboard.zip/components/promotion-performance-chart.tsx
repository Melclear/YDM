"use client"

import { useEffect, useState } from "react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  type TooltipProps,
} from "recharts"

// Sample data for the chart
const chartData = [
  { name: "Jan", redemptions: 18, revenue: 1800, roi: 220 },
  { name: "Feb", redemptions: 24, revenue: 2400, roi: 240 },
  { name: "Mar", redemptions: 32, revenue: 3200, roi: 260 },
  { name: "Apr", redemptions: 45, revenue: 4500, roi: 280 },
  { name: "May", redemptions: 56, revenue: 5600, roi: 290 },
  { name: "Jun", redemptions: 68, revenue: 6800, roi: 300 },
]

// Custom tooltip component
const CustomTooltip = ({ active, payload, label }: TooltipProps<number, string>) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-3 border border-gray-200 shadow-md rounded-md">
        <p className="font-medium text-sm">{label}</p>
        <p className="text-sm text-blue-600">
          <span className="font-medium">Redemptions:</span> {payload[0].value}
        </p>
        <p className="text-sm text-green-600">
          <span className="font-medium">Revenue:</span> ${payload[1].value}
        </p>
        <p className="text-sm text-orange-600">
          <span className="font-medium">ROI:</span> {payload[2].value}%
        </p>
      </div>
    )
  }

  return null
}

interface PromotionPerformanceChartProps {
  isInView?: boolean
}

export function PromotionPerformanceChart({ isInView = true }: PromotionPerformanceChartProps) {
  const [data, setData] = useState<typeof chartData>([])

  useEffect(() => {
    if (isInView) {
      setData(chartData)
    }
  }, [isInView])

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis yAxisId="left" orientation="left" stroke="#3B82F6" />
        <YAxis yAxisId="right" orientation="right" stroke="#10B981" />
        <Tooltip content={<CustomTooltip />} />
        <Legend />
        <Bar
          yAxisId="left"
          dataKey="redemptions"
          name="Redemptions"
          fill="#3B82F6"
          radius={[4, 4, 0, 0]}
          animationBegin={isInView ? 0 : "indefinite"}
          animationDuration={1500}
        />
        <Bar
          yAxisId="right"
          dataKey="revenue"
          name="Revenue ($)"
          fill="#10B981"
          radius={[4, 4, 0, 0]}
          animationBegin={isInView ? 0 : "indefinite"}
          animationDuration={1500}
          animationDelay={300}
        />
        <Bar
          yAxisId="left"
          dataKey="roi"
          name="ROI (%)"
          fill="#F59E0B"
          radius={[4, 4, 0, 0]}
          animationBegin={isInView ? 0 : "indefinite"}
          animationDuration={1500}
          animationDelay={600}
        />
      </BarChart>
    </ResponsiveContainer>
  )
}

